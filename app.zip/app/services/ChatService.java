package com.schoolbus.app.services;

import android.content.Context;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.models.Chat;
import com.schoolbus.app.models.Chat.Message;
import com.schoolbus.app.utils.Constants;
import com.schoolbus.app.utils.PreferenceManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatService {
    private final DatabaseReference chatsRef;
    private final DatabaseReference usersRef;
    private Context context;

    public interface ChatCallback {
        void onSuccess(Chat chat);

        void onError(String error);
    }

    public interface MessageCallback {
        void onSuccess(Message message);

        void onError(String error);
    }

    public interface ChatsCallback {
        void onSuccess(List<Chat> chats);

        void onError(String error);
    }

    public ChatService(DatabaseReference database) {
        this.chatsRef = database.child(Constants.CHATS_PATH);
        this.usersRef = database.child(Constants.USERS_PATH);
        this.context = null; // No context provided
    }

    public ChatService(DatabaseReference database, Context context) {
        this.chatsRef = database.child(Constants.CHATS_PATH);
        this.usersRef = database.child(Constants.USERS_PATH);
        this.context = context;
    }

    /**
     * Simplified method to create a chat with just the child information
     * 
     * @param childId   The ID of the child
     * @param childName The name of the child
     * @param callback  Callback to handle the result
     */
    public void createSimpleChat(String childId, String childName, ChatCallback callback) {
        // Use a predictable ID format
        String chatId = childId + "_chat";

        // Check if the chat already exists
        chatsRef.child(chatId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // The chat already exists, retrieve it
                    Chat existingChat = snapshot.getValue(Chat.class);
                    if (existingChat != null) {
                        // Make sure the ID is set (Firebase doesn't store the key in the value)
                        existingChat.setId(chatId);
                        android.util.Log.d("ChatService", "Chat already exists with ID: " + chatId);
                        callback.onSuccess(existingChat);
                    } else {
                        callback.onError("Failed to parse existing chat data");
                    }
                } else {
                    // Create a new chat with a predictable ID
                    Chat chat = new Chat(childId, childName);
                    chat.setId(chatId);

                    // Now save it with the specific ID
                    chatsRef.child(chatId).setValue(chat)
                            .addOnSuccessListener(aVoid -> {
                                android.util.Log.d("ChatService", "Successfully created chat with ID: " + chatId);
                                callback.onSuccess(chat);
                            })
                            .addOnFailureListener(e -> {
                                android.util.Log.e("ChatService", "Error creating chat: " + e.getMessage());
                                callback.onError("Failed to create chat: " + e.getMessage());
                            });
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                callback.onError(error.getMessage());
            }
        });
    }

    // Send a message in a chat
    public void sendMessage(String chatId, String senderId, String senderName, String messageText,
            MessageCallback callback) {
        android.util.Log.d("ChatService", "Attempting to send message to chat: " + chatId);
        android.util.Log.d("ChatService", "Sender: " + senderId + " (" + senderName + ")");

        // Verify chat exists first
        chatsRef.child(chatId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    android.util.Log.e("ChatService", "Error: Chat with ID " + chatId + " does not exist");
                    callback.onError("Chat does not exist. Please try again later.");
                    return;
                }

                // Chat exists, proceed with sending message
                Message message = new Message(senderId, senderName, messageText);
                chatsRef.child(chatId).child("messages").child(message.getId()).setValue(message)
                        .addOnSuccessListener(aVoid -> {
                            // Update last message timestamp
                            chatsRef.child(chatId).child("lastMessageTimestamp").setValue(System.currentTimeMillis());
                            android.util.Log.d("ChatService", "Message sent successfully");
                            callback.onSuccess(message);
                        })
                        .addOnFailureListener(e -> {
                            android.util.Log.e("ChatService", "Error sending message: " + e.getMessage());
                            callback.onError(e.getMessage());
                        });
            }

            @Override
            public void onCancelled(DatabaseError error) {
                android.util.Log.e("ChatService", "Error checking chat: " + error.getMessage());
                callback.onError("Failed to check chat: " + error.getMessage());
            }
        });
    }

    // Get all chats for a user (parent, driver, or admin)
    public void getUserChats(String userId, String userType, ChatsCallback callback) {
        chatsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                List<Chat> userChats = new ArrayList<>();
                for (DataSnapshot chatSnapshot : snapshot.getChildren()) {
                    Chat chat = chatSnapshot.getValue(Chat.class);
                    if (chat != null && chat.getChildId() != null && chat.getChildName() != null) {
                        // Include all chats that have valid child information
                        userChats.add(chat);
                    }
                }
                callback.onSuccess(userChats);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                callback.onError(error.getMessage());
            }
        });
    }

    // Get a specific chat by ID
    public void getChat(String chatId, ChatCallback callback) {
        chatsRef.child(chatId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                Chat chat = snapshot.getValue(Chat.class);
                if (chat != null) {
                    callback.onSuccess(chat);
                } else {
                    callback.onError("Chat not found");
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                callback.onError(error.getMessage());
            }
        });
    }

    // Update message status (sent, delivered, read)
    public void updateMessageStatus(String chatId, String messageId, String status) {
        chatsRef.child(chatId).child("messages").child(messageId).child("status").setValue(status);
    }

    /**
     * Simplified method to get or create a chat with just the child ID
     * 
     * @param childId   The ID of the child
     * @param childName The name of the child
     * @param callback  Callback to handle the result
     */
    public void getOrCreateChatForChild(String childId, String childName, ChatCallback callback) {
        // Just use our improved createSimpleChat method which already checks if the
        // chat exists
        createSimpleChat(childId, childName, callback);
    }

    /**
     * Create a new chat with just the child ID
     * 
     * @param childId   The ID of the child
     * @param childName The name of the child
     * @param callback  Callback to handle the result
     */
    private void createChatForChild(String childId, String childName, ChatCallback callback) {
        // Create a new chat with the simplified constructor
        Chat chat = new Chat(childId, childName);

        chatsRef.child(chat.getId()).setValue(chat)
                .addOnSuccessListener(aVoid -> {
                    // Update chat with current user info if needed
                    FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                    if (currentUser != null) {
                        // User is logged in with Firebase
                        String currentUserId = currentUser.getUid();
                        updateChatWithCurrentUser(chat.getId(), currentUserId, callback);
                    } else if (context != null) {
                        // Check if this is the admin user (not authenticated with Firebase)
                        PreferenceManager prefManager = new PreferenceManager(context);
                        String userId = prefManager.getUserId();
                        String userType = prefManager.getUserType();

                        if (userId != null && "admin".equals(userType)) {
                            // It's the admin user, update the adminId field
                            Map<String, Object> updates = new HashMap<>();
                            updates.put("adminId", userId);

                            // Update the chat
                            chatsRef.child(chat.getId()).updateChildren(updates)
                                    .addOnSuccessListener(aVoid2 -> {
                                        getChat(chat.getId(), callback);
                                    })
                                    .addOnFailureListener(e -> {
                                        callback.onError("Failed to update admin ID: " + e.getMessage());
                                    });
                        } else {
                            // Not logged in with Firebase and not admin, just return the chat as is
                            getChat(chat.getId(), callback);
                        }
                    } else {
                        // No context available, just return the chat as is
                        getChat(chat.getId(), callback);
                    }
                })
                .addOnFailureListener(e -> callback.onError(e.getMessage()));
    }

    private void updateChatWithCurrentUser(String chatId, String userId, ChatCallback callback) {
        // Just retrieve the chat with its current state and call the callback
        // We no longer need to store all user IDs in the chat
        getChat(chatId, callback);
    }

    /**
     * Special method to update a chat with admin information
     * This is necessary because admin users are hardcoded and don't use Firebase
     * authentication
     * 
     * @param chatId   The ID of the chat to update
     * @param userId   The admin user ID
     * @param callback Callback to handle the result
     */
    public void updateChatWithAdminUser(String chatId, String userId, ChatCallback callback) {
        android.util.Log.d("ChatService", "Updating chat " + chatId + " with admin user ID: " + userId);

        Map<String, Object> updates = new HashMap<>();
        updates.put("adminId", userId);

        chatsRef.child(chatId).updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    android.util.Log.d("ChatService", "Successfully updated chat with admin ID");
                    getChat(chatId, callback);
                })
                .addOnFailureListener(e -> {
                    android.util.Log.e("ChatService", "Failed to update chat with admin ID: " + e.getMessage());
                    callback.onError("Failed to update chat with admin info: " + e.getMessage());
                });
    }
}