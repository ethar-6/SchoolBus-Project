package com.schoolbus.app.services;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.util.Log;

import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.schoolbus.app.utils.Constants;

/**
 * Utility class to handle saving driver location when they log in
 */
public class LocationService {
    private static final String TAG = "LocationService";

    /**
     * Saves the driver's location only once (when logging in)
     * @param driverId The ID of the driver
     * @param busId The ID of the bus assigned to the driver
     * @param context The context needed for location services
     */
    public static void saveDriverLocation(String driverId, String busId, Context context) {
        if (driverId == null || busId == null || context == null) {
            Log.e(TAG, "Cannot save location: missing driverId, busId, or context");
            return;
        }
        
        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "Location permission not granted");
            return;
        }
        
        // Get the location client
        FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(context);
        
        // Get the last known location
        Task<Location> lastLocationTask = client.getLastLocation();
        lastLocationTask.addOnSuccessListener(location -> {
            if (location != null) {
                com.schoolbus.app.models.Location locationModel = new com.schoolbus.app.models.Location(
                        location.getLatitude(),
                        location.getLongitude(),
                        System.currentTimeMillis()
                );
                
                // Save location to Firebase
                DatabaseReference driverLocationRef = FirebaseDatabase.getInstance()
                        .getReference("driver_locations")
                        .child(driverId);
                
                DatabaseReference busLocationRef = FirebaseDatabase.getInstance()
                        .getReference("bus_locations")
                        .child(busId);
                
                // Update both driver and bus location references
                driverLocationRef.setValue(locationModel);
                busLocationRef.setValue(locationModel);
                
                Log.d(TAG, "Location saved for driver " + driverId + 
                        " at " + locationModel.getLatitude() + ", " + locationModel.getLongitude());
            } else {
                Log.d(TAG, "Location is null, could not save driver location");
            }
        }).addOnFailureListener(e -> {
            Log.e(TAG, "Error getting location: " + e.getMessage());
        });
    }
} 