package com.schoolbus.app.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.adapters.ChildrenBusAdapter;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.Bus;
import com.schoolbus.app.models.User;
import com.schoolbus.app.utils.Constants;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BusesFragment extends Fragment {
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private TextView emptyView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private List<Bus> busList;
    private ChildrenBusAdapter adapter;
    private FirebaseManager firebaseManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_buses, container, false);
        
        // Initialize Firebase
        firebaseManager = FirebaseManager.getInstance();
        
        // Initialize views
        recyclerView = view.findViewById(R.id.busesRecyclerView);
        progressBar = view.findViewById(R.id.progressBar);
        emptyView = view.findViewById(R.id.emptyView);
        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);
        
        // Initialize bus list
        busList = new ArrayList<>();
        
        // Setup adapter
        adapter = new ChildrenBusAdapter(busList, bus -> {
            // No action needed for simple display
        });
        recyclerView.setAdapter(adapter);
        
        // Setup refresh listener
        swipeRefreshLayout.setOnRefreshListener(this::loadChildrenBuses);
        
        // Load buses data
        loadChildrenBuses();
        
        return view;
    }
    
    private void loadChildrenBuses() {
        showLoading();
        
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            showEmpty("Please login to view buses");
            return;
        }
        
        // Get user profile to access children data
        DatabaseReference userRef = firebaseManager.getDatabaseReference(Constants.USERS_PATH).child(currentUser.getUid());
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()) {
                    showEmpty("User profile not found");
                    return;
                }
                
                User user = dataSnapshot.getValue(User.class);
                if (user == null || user.getChildren() == null || user.getChildren().isEmpty()) {
                    showEmpty("No children found");
                    return;
                }
                
                // Get all bus IDs from children
                Set<String> busIds = new HashSet<>();
                boolean hasChildrenWithoutBus = false;
                
                for (User.Child child : user.getChildren().values()) {
                    if (child.getBusId() != null && !child.getBusId().isEmpty()) {
                        busIds.add(child.getBusId());
                        Log.d("BusesFragment", "Child " + child.getName() + " has bus ID: " + child.getBusId());
                    } else {
                        hasChildrenWithoutBus = true;
                        Log.d("BusesFragment", "Child " + child.getName() + " has no bus ID assigned");
                    }
                }
                
                if (busIds.isEmpty()) {
                    if (hasChildrenWithoutBus) {
                        showEmpty("Your children don't have buses assigned yet");
                    } else {
                        showEmpty("No buses assigned to children");
                    }
                    return;
                }
                
                // Load bus data
                loadBuses(busIds);
            }
            
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                showError("Error loading user data");
            }
        });
    }
    
    private void loadBuses(Set<String> busIds) {
        busList.clear();
        final int[] pendingRequests = {busIds.size()};
        
        Log.d("BusesFragment", "Loading " + busIds.size() + " buses: " + busIds);
        
        for (String busId : busIds) {
            DatabaseReference busRef = firebaseManager.getDatabaseReference(Constants.BUSES_PATH).child(busId);
            busRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    pendingRequests[0]--;
                    
                    Bus bus = dataSnapshot.getValue(Bus.class);
                    if (bus != null) {
                        bus.setId(dataSnapshot.getKey());
                        busList.add(bus);
                        Log.d("BusesFragment", "Successfully loaded bus: " + bus.getBusNumber());
                    } else {
                        Log.d("BusesFragment", "Bus data not found for ID: " + busId);
                        
                        // Try to check if there's a location for this bus in bus_locations
                        checkBusLocation(busId);
                    }
                    
                    if (pendingRequests[0] <= 0) {
                        updateUI();
                    }
                }
                
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    pendingRequests[0]--;
                    Log.e("BusesFragment", "Error loading bus ID " + busId + ": " + databaseError.getMessage());
                    
                    if (pendingRequests[0] <= 0) {
                        updateUI();
                    }
                }
            });
        }
    }
    
    private void checkBusLocation(String busId) {
        DatabaseReference locationRef = firebaseManager.getDatabaseReference("bus_locations").child(busId);
        locationRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Found a location but no bus object, create a minimal bus object
                    Log.d("BusesFragment", "Found location data for bus ID: " + busId);
                    
                    Bus bus = new Bus();
                    bus.setId(busId);
                    bus.setBusNumber("Bus #" + busId);
                    bus.setStatus("active");
                    
                    // Try to create a location object from the data
                    try {
                        Double latitude = null;
                        Double longitude = null;
                        Long timestamp = null;
                        
                        if (dataSnapshot.hasChild("latitude")) {
                            latitude = dataSnapshot.child("latitude").getValue(Double.class);
                        } else if (dataSnapshot.hasChild("lat")) {
                            latitude = dataSnapshot.child("lat").getValue(Double.class);
                        }
                        
                        if (dataSnapshot.hasChild("longitude")) {
                            longitude = dataSnapshot.child("longitude").getValue(Double.class);
                        } else if (dataSnapshot.hasChild("lng")) {
                            longitude = dataSnapshot.child("lng").getValue(Double.class);
                        }
                        
                        if (dataSnapshot.hasChild("timestamp")) {
                            timestamp = dataSnapshot.child("timestamp").getValue(Long.class);
                        } else if (dataSnapshot.hasChild("lastUpdated")) {
                            timestamp = dataSnapshot.child("lastUpdated").getValue(Long.class);
                        }
                        
                        if (latitude != null && longitude != null) {
                            Bus.Location location = new Bus.Location();
                            location.setLatitude(latitude);
                            location.setLongitude(longitude);
                            if (timestamp != null) {
                                location.setLastUpdated(timestamp);
                            } else {
                                location.setLastUpdated(System.currentTimeMillis());
                            }
                            bus.setCurrentLocation(location);
                        }
                    } catch (Exception e) {
                        Log.e("BusesFragment", "Error parsing location data: " + e.getMessage());
                    }
                    
                    busList.add(bus);
                    updateUI();
                }
            }
            
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("BusesFragment", "Error checking bus location: " + databaseError.getMessage());
            }
        });
    }
    
    private void updateUI() {
        if (busList.isEmpty()) {
            showEmpty("No buses found");
        } else {
            showContent();
        }
        adapter.notifyDataSetChanged();
        swipeRefreshLayout.setRefreshing(false);
    }
    
    private void showLoading() {
        progressBar.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
    }
    
    private void showContent() {
        progressBar.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);
        emptyView.setVisibility(View.GONE);
    }
    
    private void showEmpty(String message) {
        progressBar.setVisibility(View.GONE);
        recyclerView.setVisibility(View.GONE);
        emptyView.setVisibility(View.VISIBLE);
        emptyView.setText(message);
        swipeRefreshLayout.setRefreshing(false);
    }
    
    private void showError(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
        showEmpty("Error loading buses");
        swipeRefreshLayout.setRefreshing(false);
    }
} 