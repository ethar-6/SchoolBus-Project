package com.schoolbus.app.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.tabs.TabLayout;
import com.schoolbus.app.R;
import com.schoolbus.app.adapters.AttendanceNotificationAdapter;
import com.schoolbus.app.adapters.NotificationAdapter;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.AttendanceNotification;
import com.schoolbus.app.models.Notification;
import com.schoolbus.app.utils.Constants;
import com.schoolbus.app.utils.PreferenceManager;

import java.util.ArrayList;
import java.util.List;

public class NotificationsFragment extends Fragment {
    private static final String TAG = "NotificationsFragment";

    private static final int TAB_GENERAL = 0;
    private static final int TAB_ATTENDANCE = 1;

    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private TextView emptyView;
    private TabLayout tabLayout;
    
    private NotificationAdapter notificationAdapter;
    private AttendanceNotificationAdapter attendanceAdapter;
    
    private List<Notification> notifications;
    private List<AttendanceNotification> attendanceNotifications;
    
    private FirebaseManager firebaseManager;
    private PreferenceManager preferenceManager;
    
    private int currentTab = TAB_GENERAL;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notifications, container, false);
        
        Log.d(TAG, "onCreateView: Initializing NotificationsFragment");
        
        // Initialize views
        initViews(view);
        
        // Initialize Firebase and Preferences
        firebaseManager = FirebaseManager.getInstance();
        preferenceManager = new PreferenceManager(requireContext());
        
        // Initialize notifications lists
        notifications = new ArrayList<>();
        attendanceNotifications = new ArrayList<>();
        
        // Set up tabs
        setupTabs();
        
        // Set up RecyclerView with appropriate adapter based on selected tab
        setupRecyclerView();
        
        // Set up SwipeRefreshLayout
        swipeRefreshLayout.setOnRefreshListener(this::loadNotifications);
        
        // Load notifications
        loadNotifications();
        
        return view;
    }
    
    private void initViews(View view) {
        recyclerView = view.findViewById(R.id.notificationsRecyclerView);
        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);
        emptyView = view.findViewById(R.id.emptyView);
        tabLayout = view.findViewById(R.id.tabLayout);
    }
    
    private void setupTabs() {
        // Only show tabs for parent users
        String userType = preferenceManager.getUserType();
        Log.d(TAG, "setupTabs: User type is " + userType);
        
        if (Constants.USER_TYPE_PARENT.equals(userType)) {
            Log.d(TAG, "setupTabs: User is parent, showing tabs");
            tabLayout.setVisibility(View.VISIBLE);
            
            // Add tabs
            if (tabLayout.getTabCount() == 0) {
                tabLayout.addTab(tabLayout.newTab().setText("General"));
                tabLayout.addTab(tabLayout.newTab().setText("Attendance"));
            }
            
            // Set up tab selection listener
            tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
                @Override
                public void onTabSelected(TabLayout.Tab tab) {
                    currentTab = tab.getPosition();
                    Log.d(TAG, "onTabSelected: Selected tab " + currentTab + 
                          (currentTab == TAB_GENERAL ? " (General)" : " (Attendance)"));
                    
                    if (currentTab == TAB_ATTENDANCE) {
                        Log.d(TAG, "onTabSelected: ATTENDANCE TAB - We have " + attendanceNotifications.size() + " attendance notifications");
                        // Log details of each attendance notification
                        for (int i = 0; i < attendanceNotifications.size(); i++) {
                            AttendanceNotification notification = attendanceNotifications.get(i);
                            Log.d(TAG, "Attendance #" + (i+1) + ": childId=" + notification.getChildId() + 
                                  ", childName=" + notification.getChildName() + 
                                  ", status=" + notification.getStatus() + 
                                  ", date=" + notification.getDate());
                        }
                    }
                    
                    updateAdapter();
                }
                
                @Override
                public void onTabUnselected(TabLayout.Tab tab) {
                    // Not needed
                }
                
                @Override
                public void onTabReselected(TabLayout.Tab tab) {
                    // Not needed
                }
            });
        } else {
            Log.d(TAG, "setupTabs: User is not parent, hiding tabs");
            tabLayout.setVisibility(View.GONE);
        }
    }

    private void setupRecyclerView() {
        // Set up general notifications adapter
        notificationAdapter = new NotificationAdapter(requireContext(), notifications, notification -> {
            // Handle notification click
            if (!notification.isRead()) {
                notification.setRead(true);
                firebaseManager.updateNotificationReadStatus(notification.getId(), true, task -> {
                    if (!task.isSuccessful() && getContext() != null) {
                        // Handle error
                    }
                });
                notificationAdapter.notifyDataSetChanged();
            }
        });
        
        // Set up attendance notifications adapter
        attendanceAdapter = new AttendanceNotificationAdapter(requireContext(), attendanceNotifications, notification -> {
            // Handle attendance notification click
            if (!notification.isRead()) {
                notification.setRead(true);
                firebaseManager.updateAttendanceNotificationReadStatus(notification.getId(), true, task -> {
                    if (!task.isSuccessful() && getContext() != null) {
                        // Handle error
                        Log.e(TAG, "Error updating attendance notification read status");
                    }
                });
                attendanceAdapter.notifyDataSetChanged();
            }
        });
        
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        updateAdapter();
    }
    
    private void updateAdapter() {
        if (currentTab == TAB_GENERAL) {
            Log.d(TAG, "updateAdapter: Setting general notifications adapter with " + notifications.size() + " items");
            recyclerView.setAdapter(notificationAdapter);
            emptyView.setText(notifications.isEmpty() ? getString(R.string.msg_no_notifications) : "");
            emptyView.setVisibility(notifications.isEmpty() ? View.VISIBLE : View.GONE);
        } else {
            Log.d(TAG, "updateAdapter: Setting attendance notifications adapter with " + attendanceNotifications.size() + " items");
            recyclerView.setAdapter(attendanceAdapter);
            emptyView.setText(attendanceNotifications.isEmpty() ? getString(R.string.msg_no_attendance_records) : "");
            emptyView.setVisibility(attendanceNotifications.isEmpty() ? View.VISIBLE : View.GONE);
        }
    }

    private void loadNotifications() {
        swipeRefreshLayout.setRefreshing(true);
        
        String userId = preferenceManager.getUserId();
        Log.d(TAG, "loadNotifications: Loading notifications for userId: " + userId);
        
        if (userId != null && !userId.isEmpty()) {
            // Load general notifications
            firebaseManager.getNotifications(userId, new FirebaseManager.DataCallback<List<Notification>>() {
                @Override
                public void onSuccess(List<Notification> data) {
                    notifications.clear();
                    if (data != null && !data.isEmpty()) {
                        notifications.addAll(data);
                        Log.d(TAG, "loadNotifications: Loaded " + data.size() + " general notifications");
                    } else {
                        Log.d(TAG, "loadNotifications: No general notifications found");
                    }
                    
                    // If we're on the general tab, update UI
                    if (currentTab == TAB_GENERAL) {
                        updateAdapter();
                    }
                    
                    // For parent users, also load attendance notifications
                    if (Constants.USER_TYPE_PARENT.equals(preferenceManager.getUserType())) {
                        Log.d(TAG, "loadNotifications: User is parent, loading attendance notifications");
                        loadAttendanceNotifications(userId);
                    } else {
                        swipeRefreshLayout.setRefreshing(false);
                    }
                }

                @Override
                public void onError(String errorMessage) {
                    Log.e(TAG, "loadNotifications: Error loading general notifications: " + errorMessage);
                    if (getContext() != null) {
                        emptyView.setText(R.string.msg_no_data);
                        emptyView.setVisibility(View.VISIBLE);
                    }
                    
                    // Still try to load attendance notifications for parent users
                    if (Constants.USER_TYPE_PARENT.equals(preferenceManager.getUserType())) {
                        loadAttendanceNotifications(userId);
                    } else {
                        swipeRefreshLayout.setRefreshing(false);
                    }
                }
            });
        } else {
            Log.e(TAG, "loadNotifications: User ID is null or empty");
            emptyView.setText(R.string.msg_no_data);
            emptyView.setVisibility(View.VISIBLE);
            swipeRefreshLayout.setRefreshing(false);
        }
    }
    
    private void loadAttendanceNotifications(String parentId) {
        Log.d(TAG, "loadAttendanceNotifications: Loading attendance notifications for parentId: " + parentId);
        
        firebaseManager.getAttendanceForParent(parentId, new FirebaseManager.DataCallback<List<AttendanceNotification>>() {
            @Override
            public void onSuccess(List<AttendanceNotification> data) {
                attendanceNotifications.clear();
                if (data != null && !data.isEmpty()) {
                    Log.d(TAG, "loadAttendanceNotifications: Received " + data.size() + " attendance notifications");
                    attendanceNotifications.addAll(data);
                    
                    // Log the first attendance notification for debugging
                    if (data.size() > 0) {
                        AttendanceNotification firstNotification = data.get(0);
                        Log.d(TAG, "loadAttendanceNotifications: First notification - " +
                              "childId: " + firstNotification.getChildId() + 
                              ", status: " + firstNotification.getStatus() + 
                              ", date: " + firstNotification.getDate());
                    }
                } else {
                    Log.d(TAG, "loadAttendanceNotifications: No attendance notifications found");
                }
                
                // If we're on the attendance tab, update UI
                if (currentTab == TAB_ATTENDANCE) {
                    updateAdapter();
                }
                
                swipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onError(String errorMessage) {
                Log.e(TAG, "loadAttendanceNotifications: Error: " + errorMessage);
                if (getContext() != null && currentTab == TAB_ATTENDANCE) {
                    emptyView.setText(R.string.msg_no_data);
                    emptyView.setVisibility(View.VISIBLE);
                }
                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }
} 