package com.schoolbus.app.fragments;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.Bus;
import com.schoolbus.app.models.Route;
import com.schoolbus.app.models.Stop;
import com.schoolbus.app.utils.Constants;
import com.schoolbus.app.utils.PreferenceManager;

import java.util.ArrayList;
import java.util.List;

public class TrackingFragment extends Fragment implements OnMapReadyCallback {
    private GoogleMap mMap;
    private ProgressBar mapProgressBar;
    private CardView busInfoCard;
    private TextView busNumberText;
    private TextView routeNameText;
    private TextView statusText;
    private TextView driverNameText;
    private TextView nextStopText;
    private TextView estimatedArrivalText;
    private TextView lastUpdatedText;
    private TextView distanceText;
    
    private FirebaseManager firebaseManager;
    private PreferenceManager preferenceManager;
    
    private String busId;
    private Bus currentBus;
    
    private ValueEventListener busListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tracking, container, false);
        
        // Initialize Firebase and Preferences
        firebaseManager = FirebaseManager.getInstance();
        preferenceManager = PreferenceManager.getInstance(requireContext());
        
        // Get bus ID from arguments
        if (getArguments() != null) {
            busId = getArguments().getString(Constants.EXTRA_BUS_ID);
            Log.d("TrackingFragment", "Received bus ID from arguments: " + busId);
        } else {
            Log.e("TrackingFragment", "No arguments provided to fragment");
        }
        
        // Initialize views
        initViews(view);
        
        // Set up map
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.mapFragment);
        if (mapFragment != null) {
            Log.d("TrackingFragment", "Getting map async");
            mapFragment.getMapAsync(this);
        } else {
            Log.e("TrackingFragment", "Map fragment not found");
            showError("Map not available");
        }
        
        // Set up click listeners
        setupClickListeners();
        
        // Load bus data
        if (busId != null && !busId.isEmpty()) {
            loadBusData();
        }
        
        return view;
    }

    private void initViews(View view) {
        mapProgressBar = view.findViewById(R.id.progressBar);
        busInfoCard = view.findViewById(R.id.infoCardView);
        busNumberText = view.findViewById(R.id.busNumberTextView);
        routeNameText = view.findViewById(R.id.routeNameTextView);
        statusText = view.findViewById(R.id.statusTextView);
        driverNameText = null;
        nextStopText = view.findViewById(R.id.nextStopTextView);
        estimatedArrivalText = view.findViewById(R.id.estimatedArrivalTextView);
        lastUpdatedText = view.findViewById(R.id.lastUpdatedTextView);
        distanceText = view.findViewById(R.id.distanceTextView);
        
        // Get map fragment
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.mapFragment);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    private void setupClickListeners() {
        // Set up click listeners for buttons
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        
        // Configure map settings for better user experience
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);
        mMap.getUiSettings().setZoomGesturesEnabled(true);
        mMap.getUiSettings().setRotateGesturesEnabled(true);
        mMap.getUiSettings().setTiltGesturesEnabled(true);
        
        // Set default map type to normal
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        
        // Enable my location if permission is granted
        if (ActivityCompat.checkSelfPermission(requireContext(), 
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
        }
        
        // Load bus data only if we have a valid bus ID
        if (busId != null && !busId.isEmpty()) {
            loadBusData();
        } else {
            showError("Bus ID not provided");
        }
    }

    private void loadBusData() {
        showLoading(true);
        
        // Debug log to check bus ID
        Log.d("TrackingFragment", "Loading bus data for ID: " + busId);
        
        busListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d("TrackingFragment", "Bus data snapshot exists: " + dataSnapshot.exists());
                
                if (dataSnapshot.exists()) {
                    try {
                        currentBus = dataSnapshot.getValue(Bus.class);
                        Log.d("TrackingFragment", "Bus data parsed: " + (currentBus != null));
                        
                        if (currentBus != null) {
                            currentBus.setId(dataSnapshot.getKey());
                            
                            // Update UI with basic bus info
                            updateBusInfo();
                            
                            // Now fetch location data from the proper location
                            fetchBusLocation();
                        } else {
                            Log.e("TrackingFragment", "Failed to parse bus data");
                            showError("Failed to load bus data");
                            showLoading(false);
                        }
                    } catch (Exception e) {
                        Log.e("TrackingFragment", "Error parsing bus data: " + e.getMessage(), e);
                        showError("Error parsing bus data: " + e.getMessage());
                        showLoading(false);
                    }
                } else {
                    Log.e("TrackingFragment", "Bus not found with ID: " + busId);
                    showError("Bus not found");
                    showLoading(false);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("TrackingFragment", "Database error: " + databaseError.getMessage());
                showLoading(false);
                showError("Failed to load bus data: " + databaseError.getMessage());
            }
        };
        
        // Check if bus ID is valid
        if (busId != null && !busId.isEmpty()) {
            firebaseManager.getBusDetails(busId, busListener);
        } else {
            Log.e("TrackingFragment", "Invalid bus ID: " + busId);
            showError("Invalid bus ID");
            showLoading(false);
        }
    }

    private void updateBusInfo() {
        if (currentBus == null) {
            Log.e("TrackingFragment", "Cannot update bus info: bus object is null");
            return;
        }
        
        // Set bus number
        if (currentBus.getBusNumber() != null && !currentBus.getBusNumber().isEmpty()) {
            busNumberText.setText(currentBus.getBusNumber());
            Log.d("TrackingFragment", "Setting bus number: " + currentBus.getBusNumber());
        } else {
            busNumberText.setText("Unknown Bus");
            Log.e("TrackingFragment", "Bus number is null or empty");
        }
        
        // Set route name
        if (currentBus.getRouteName() != null && !currentBus.getRouteName().isEmpty()) {
            routeNameText.setText(currentBus.getRouteName());
            Log.d("TrackingFragment", "Setting route name: " + currentBus.getRouteName());
        } else {
            routeNameText.setText("No route assigned");
            Log.d("TrackingFragment", "No route name available");
        }
        
        // Set status
        if (currentBus.getStatus() != null && !currentBus.getStatus().isEmpty()) {
            statusText.setText(currentBus.getStatus());
            Log.d("TrackingFragment", "Setting status: " + currentBus.getStatus());
            
            // Set status text color based on status
            int statusColor;
            switch (currentBus.getStatus()) {
                case Constants.BUS_STATUS_ACTIVE:
                    statusColor = requireContext().getResources().getColor(R.color.status_active);
                    break;
                case Constants.BUS_STATUS_INACTIVE:
                    statusColor = requireContext().getResources().getColor(R.color.status_inactive);
                    break;
                case Constants.BUS_STATUS_MAINTENANCE:
                    statusColor = requireContext().getResources().getColor(R.color.status_warning);
                    break;
                default:
                    statusColor = requireContext().getResources().getColor(R.color.text_secondary);
                    break;
            }
            statusText.setTextColor(statusColor);
        } else {
            statusText.setText("Unknown");
            Log.e("TrackingFragment", "Bus status is null or empty");
        }
        
        // Set driver name
        if (driverNameText != null) {
            if (currentBus.getDriverName() != null && !currentBus.getDriverName().isEmpty()) {
                driverNameText.setText(currentBus.getDriverName());
                Log.d("TrackingFragment", "Setting driver name: " + currentBus.getDriverName());
            } else {
                driverNameText.setText("No driver assigned");
                Log.d("TrackingFragment", "No driver name available");
            }
        }
        
        // Format last updated time
        if (currentBus.getLastUpdated() > 0) {
            CharSequence relativeTime = DateUtils.getRelativeTimeSpanString(
                    currentBus.getLastUpdated(),
                    System.currentTimeMillis(),
                    DateUtils.MINUTE_IN_MILLIS);
            lastUpdatedText.setText(relativeTime);
            Log.d("TrackingFragment", "Setting last updated: " + relativeTime);
        } else {
            lastUpdatedText.setText("Unknown");
            Log.e("TrackingFragment", "Last updated timestamp is invalid: " + currentBus.getLastUpdated());
        }
        
        // Hide next stop and estimated arrival info since we're not using route data
        if (nextStopText != null) nextStopText.setText("N/A");
        if (estimatedArrivalText != null) estimatedArrivalText.setText("N/A");
    }

    private void updateMap() {
        if (mMap == null) {
            Log.e("TrackingFragment", "Google Map is null");
            return;
        }
        
        mMap.clear();
        
        if (currentBus != null && currentBus.getCurrentLocation() != null) {
            // Add bus marker
            LatLng busLocation = new LatLng(
                    currentBus.getCurrentLocation().getLatitude(),
                    currentBus.getCurrentLocation().getLongitude());
            
            Log.d("TrackingFragment", "Setting bus marker at: " + busLocation.latitude + ", " + busLocation.longitude);
            
            // Check for valid coordinates (0,0 is in the ocean, likely invalid)
            if (busLocation.latitude == 0 && busLocation.longitude == 0) {
                Log.e("TrackingFragment", "Invalid bus location (0,0), showing default view");
                showError("Invalid bus location data");
                return;
            }
            
            mMap.addMarker(new MarkerOptions()
                    .position(busLocation)
                    .title(currentBus.getBusNumber())
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
            
            // Zoom directly to bus location with a detailed zoom level
            Log.d("TrackingFragment", "Zooming to bus location with zoom level 17.0");
            
            try {
                // Use moveCamera first to ensure position, then animate for smoothness
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(busLocation, 17.0f));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(busLocation, 17.0f), 
                        1200, null); // 1.2 second animation for smooth effect
            } catch (Exception e) {
                Log.e("TrackingFragment", "Error zooming to bus location: " + e.getMessage(), e);
                // Try a simpler camera move without animation as fallback
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(busLocation, 15.0f));
            }
        } else {
            Log.e("TrackingFragment", "No valid bus location data available");
            showError("Bus location not available");
        }
    }

    private void showLoading(boolean isLoading) {
        mapProgressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
    }

    private void showError(String message) {
        if (getContext() != null) {
            Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        
        // Remove bus listener
        if (busListener != null) {
            // The removeBusListener method doesn't exist, so we'll just null it out
            busListener = null;
        }
        
        // Clear references
        mMap = null;
    }

    // New method to fetch location from the bus_locations node
    private void fetchBusLocation() {
        Log.d("TrackingFragment", "Fetching location from bus_locations/" + busId);
        
        DatabaseReference locationRef = FirebaseDatabase.getInstance().getReference("bus_locations").child(busId);
        locationRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                showLoading(false);
                
                if (dataSnapshot.exists()) {
                    Log.d("TrackingFragment", "Location data found in bus_locations");
                    
                    try {
                        // Try all possible field names for latitude
                        Double latitude = null;
                        if (dataSnapshot.hasChild("latitude")) {
                            latitude = dataSnapshot.child("latitude").getValue(Double.class);
                        } else if (dataSnapshot.hasChild("lat")) {
                            latitude = dataSnapshot.child("lat").getValue(Double.class);
                        }
                        
                        // Try all possible field names for longitude
                        Double longitude = null;
                        if (dataSnapshot.hasChild("longitude")) {
                            longitude = dataSnapshot.child("longitude").getValue(Double.class);
                        } else if (dataSnapshot.hasChild("lng")) {
                            longitude = dataSnapshot.child("lng").getValue(Double.class);
                        }
                        
                        // Try all possible field names for timestamp
                        Long timestamp = null;
                        if (dataSnapshot.hasChild("timestamp")) {
                            timestamp = dataSnapshot.child("timestamp").getValue(Long.class);
                        } else if (dataSnapshot.hasChild("lastUpdated")) {
                            timestamp = dataSnapshot.child("lastUpdated").getValue(Long.class);
                        } else if (dataSnapshot.hasChild("time")) {
                            timestamp = dataSnapshot.child("time").getValue(Long.class);
                        }
                        
                        Log.d("TrackingFragment", "Location data: lat=" + latitude + ", lng=" + longitude + ", time=" + timestamp);
                        
                        if (latitude != null && longitude != null) {
                            // Create a Bus.Location object (this is the key change)
                            Bus.Location location = new Bus.Location();
                            location.setLatitude(latitude);
                            location.setLongitude(longitude);
                            if (timestamp != null) {
                                location.setLastUpdated(timestamp);
                            } else {
                                location.setLastUpdated(System.currentTimeMillis());
                            }
                            
                            // Update the bus with this location
                            if (currentBus != null) {
                                currentBus.setCurrentLocation(location);
                                
                                // Now update the map with this location
                                updateMap();
                            }
                        } else {
                            Log.e("TrackingFragment", "Invalid location coordinates");
                            showError("Invalid location data found");
                        }
                    } catch (Exception e) {
                        Log.e("TrackingFragment", "Error parsing location data: " + e.getMessage(), e);
                        showError("Error reading location data");
                    }
                } else {
                    Log.e("TrackingFragment", "No location data found for this bus");
                    showError("No location data found for this bus");
                    
                    // Check driver_locations as a fallback
                    fetchDriverLocation();
                }
            }
            
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                showLoading(false);
                Log.e("TrackingFragment", "Error fetching location: " + databaseError.getMessage());
                showError("Error loading location data");
            }
        });
    }

    // Fallback to check driver_locations if bus_locations doesn't have data
    private void fetchDriverLocation() {
        if (currentBus == null || currentBus.getDriverId() == null || currentBus.getDriverId().isEmpty()) {
            Log.e("TrackingFragment", "No driver ID available for fallback");
            return;
        }
        
        String driverId = currentBus.getDriverId();
        Log.d("TrackingFragment", "Trying fallback - fetching from driver_locations/" + driverId);
        
        DatabaseReference driverLocationRef = FirebaseDatabase.getInstance().getReference("driver_locations").child(driverId);
        driverLocationRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Log.d("TrackingFragment", "Location data found in driver_locations");
                    
                    try {
                        // Try all possible field names for latitude
                        Double latitude = null;
                        if (dataSnapshot.hasChild("latitude")) {
                            latitude = dataSnapshot.child("latitude").getValue(Double.class);
                        } else if (dataSnapshot.hasChild("lat")) {
                            latitude = dataSnapshot.child("lat").getValue(Double.class);
                        }
                        
                        // Try all possible field names for longitude
                        Double longitude = null;
                        if (dataSnapshot.hasChild("longitude")) {
                            longitude = dataSnapshot.child("longitude").getValue(Double.class);
                        } else if (dataSnapshot.hasChild("lng")) {
                            longitude = dataSnapshot.child("lng").getValue(Double.class);
                        }
                        
                        // Try all possible field names for timestamp
                        Long timestamp = null;
                        if (dataSnapshot.hasChild("timestamp")) {
                            timestamp = dataSnapshot.child("timestamp").getValue(Long.class);
                        } else if (dataSnapshot.hasChild("lastUpdated")) {
                            timestamp = dataSnapshot.child("lastUpdated").getValue(Long.class);
                        } else if (dataSnapshot.hasChild("time")) {
                            timestamp = dataSnapshot.child("time").getValue(Long.class);
                        }
                        
                        Log.d("TrackingFragment", "Driver location data: lat=" + latitude + ", lng=" + longitude);
                        
                        if (latitude != null && longitude != null) {
                            // Create a Bus.Location object
                            Bus.Location location = new Bus.Location();
                            location.setLatitude(latitude);
                            location.setLongitude(longitude);
                            if (timestamp != null) {
                                location.setLastUpdated(timestamp);
                            } else {
                                location.setLastUpdated(System.currentTimeMillis());
                            }
                            
                            // Update the bus with this location
                            if (currentBus != null) {
                                currentBus.setCurrentLocation(location);
                                
                                // Update the map with this location
                                updateMap();
                                
                                // Show message that we're using driver location
                                showError("Showing driver's last known location");
                            }
                        } else {
                            Log.e("TrackingFragment", "Invalid driver location coordinates");
                        }
                    } catch (Exception e) {
                        Log.e("TrackingFragment", "Error parsing driver location: " + e.getMessage(), e);
                    }
                } else {
                    Log.e("TrackingFragment", "No driver location data found either");
                }
            }
            
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("TrackingFragment", "Error fetching driver location: " + databaseError.getMessage());
            }
        });
    }
} 