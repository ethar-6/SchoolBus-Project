package com.schoolbus.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.activities.EditProfileActivity;
import com.schoolbus.app.activities.LoginActivity;
import com.schoolbus.app.activities.ChildrenListActivity;
import com.schoolbus.app.activities.MainActivity;
import com.schoolbus.app.activities.HelpActivity;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.User;
import com.schoolbus.app.utils.DummyDataGenerator;
import com.schoolbus.app.utils.PreferenceManager;
import com.schoolbus.app.utils.Constants;

public class ProfileFragment extends Fragment {

    private TextView nameTextView;
    private TextView emailTextView;
    private TextView phoneTextView;
    private Button logoutButton;
    private Button editProfileButton;
    private Button generateDummyDataButton;
    private Button addChildButton;
    private View progressBar;
    private TextView notificationSettingsTextView;
    private TextView darkModeTextView;
    private TextView helpTextView;

    private FirebaseManager firebaseManager;
    private PreferenceManager preferenceManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize Firebase and Preferences
        firebaseManager = FirebaseManager.getInstance();
        preferenceManager = PreferenceManager.getInstance(requireContext());

        // Initialize views
        initViews(view);

        // Set up button listeners
        setupClickListeners();

        // Load user profile
        loadUserProfile();

        return view;
    }

    private void initViews(View view) {
        nameTextView = view.findViewById(R.id.nameTextView);
        emailTextView = view.findViewById(R.id.emailTextView);
        phoneTextView = view.findViewById(R.id.phoneTextView);
        editProfileButton = view.findViewById(R.id.editProfileButton);
        logoutButton = view.findViewById(R.id.logoutButton);
        generateDummyDataButton = view.findViewById(R.id.generateDummyDataButton);
        addChildButton = view.findViewById(R.id.addChildButton);
        progressBar = view.findViewById(R.id.progressBar);
        notificationSettingsTextView = view.findViewById(R.id.notificationSettingsTextView);
        darkModeTextView = view.findViewById(R.id.darkModeTextView);
        helpTextView = view.findViewById(R.id.helpTextView);

        // Hide generate dummy data button for parent users
        String userType = preferenceManager.getUserType();
        if (userType != null && userType.equals(Constants.USER_TYPE_PARENT)) {
            generateDummyDataButton.setVisibility(View.GONE);
        }
    }

    private void setupClickListeners() {
        editProfileButton.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), EditProfileActivity.class);
            startActivity(intent);
        });
        logoutButton.setOnClickListener(v -> {
            logout();
        });
        generateDummyDataButton.setOnClickListener(v -> {
            generateDummyData();
        });
        addChildButton.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), ChildrenListActivity.class);
            startActivity(intent);
        });
        // Add click listener for notifications
        notificationSettingsTextView.setOnClickListener(v -> {
            // Navigate to the NotificationsFragment
            if (getActivity() instanceof MainActivity) {
                MainActivity mainActivity = (MainActivity) getActivity();
                NotificationsFragment notificationsFragment = new NotificationsFragment();
                mainActivity.getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.nav_host_fragment, notificationsFragment)
                    .addToBackStack(null)
                    .commit();
            }
        });
        
        // Add click listener for help
        helpTextView.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), HelpActivity.class);
            startActivity(intent);
        });
    }

    private void loadUserProfile() {
        String userId = preferenceManager.getUserId();
        if (userId == null || userId.isEmpty()) {
            return;
        }
        firebaseManager.getUserProfile(userId, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    User user = dataSnapshot.getValue(User.class);
                    if (user != null) {
                        updateUI(user);
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle error
            }
        });
    }
    private void updateUI(User user) {
        nameTextView.setText(user.getName());
        emailTextView.setText(user.getEmail());
        phoneTextView.setText(user.getPhone());
    }

    private void logout() {
        firebaseManager.signOut();
        preferenceManager.clearAll();

        Intent intent = new Intent(requireContext(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    private void generateDummyData() {
        String userId = preferenceManager.getUserId();
        if (userId == null || userId.isEmpty()) {
            Toast.makeText(requireContext(), "Please login first", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show progress
        progressBar.setVisibility(View.VISIBLE);
        generateDummyDataButton.setEnabled(false);

        // Create dummy data generator
        DummyDataGenerator dummyDataGenerator = new DummyDataGenerator(userId);

        // Generate and add dummy data
        dummyDataGenerator.generateAllData(new DummyDataGenerator.DataGenerationCallback() {
            @Override
            public void onSuccess() {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        generateDummyDataButton.setEnabled(true);
                        Toast.makeText(requireContext(), "Dummy data generated successfully", Toast.LENGTH_SHORT)
                                .show();
                    });
                }
            }

            @Override
            public void onError(String errorMessage) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        generateDummyDataButton.setEnabled(true);
                        Toast.makeText(requireContext(), "Error generating dummy data: " + errorMessage,
                                Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }
}