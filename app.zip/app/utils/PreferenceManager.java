package com.schoolbus.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.schoolbus.app.models.User;
import com.schoolbus.app.models.User.Child;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class PreferenceManager {
    private static final String PREF_NAME = "SchoolBusPrefs";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_USER_EMAIL = "user_email";
    private static final String KEY_USER_PHONE = "user_phone";
    private static final String KEY_USER_TYPE = "user_type";
    private static final String KEY_USER_ADDRESS = "user_address";
    private static final String KEY_CHILDREN_IDS = "children_ids";
    private static final String KEY_CHILD_PREFIX = "child_";
    private static PreferenceManager instance;
    private SharedPreferences prefs;

    public static synchronized PreferenceManager getInstance(Context context) {
        if (instance == null) {
            instance = new PreferenceManager(context.getApplicationContext());
        }
        return instance;
    }

    public PreferenceManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    // User ID
    public void setUserId(String userId) {
        prefs.edit().putString(KEY_USER_ID, userId).apply();
    }

    public String getUserId() {
        return prefs.getString(KEY_USER_ID, null);
    }

    // User Name
    public void setUserName(String userName) {
        prefs.edit().putString(KEY_USER_NAME, userName).apply();
    }

    public String getUserName() {
        return prefs.getString(KEY_USER_NAME, null);
    }

    // User Type
    public void setUserType(String userType) {
        prefs.edit().putString(Constants.KEY_USER_TYPE, userType).apply();
    }

    public String getUserType() {
        return prefs.getString(Constants.KEY_USER_TYPE, null);
    }

    // Notification Enabled
    public void setNotificationEnabled(boolean enabled) {
        prefs.edit().putBoolean(Constants.KEY_NOTIFICATION_ENABLED, enabled).apply();
    }

    public boolean isNotificationEnabled() {
        return prefs.getBoolean(Constants.KEY_NOTIFICATION_ENABLED, true);
    }

    // Location Tracking Enabled
    public void setLocationTrackingEnabled(boolean enabled) {
        prefs.edit().putBoolean(Constants.KEY_LOCATION_TRACKING_ENABLED, enabled).apply();
    }

    public boolean isLocationTrackingEnabled() {
        return prefs.getBoolean(Constants.KEY_LOCATION_TRACKING_ENABLED, true);
    }

    // Last Sync
    public void setLastSync(long timestamp) {
        prefs.edit().putLong(Constants.KEY_LAST_SYNC, timestamp).apply();
    }

    public long getLastSync() {
        return prefs.getLong(Constants.KEY_LAST_SYNC, 0);
    }

    // Selected Language
    public void setSelectedLanguage(String language) {
        prefs.edit().putString(Constants.KEY_SELECTED_LANGUAGE, language).apply();
    }

    public String getSelectedLanguage() {
        return prefs.getString(Constants.KEY_SELECTED_LANGUAGE, "en");
    }

    // Dark Mode
    public void setDarkMode(boolean enabled) {
        prefs.edit().putBoolean(Constants.KEY_DARK_MODE, enabled).apply();
    }

    public boolean isDarkMode() {
        return prefs.getBoolean(Constants.KEY_DARK_MODE, false);
    }

    // User
    public void saveUser(User user) {
        if (user == null) {
            clearUser();
            return;
        }

        SharedPreferences.Editor editor = prefs.edit();

        // Save basic user info
        editor.putString(KEY_USER_ID, user.getId());
        editor.putString(KEY_USER_NAME, user.getName());
        editor.putString(KEY_USER_EMAIL, user.getEmail());
        editor.putString(KEY_USER_PHONE, user.getPhone());
        editor.putString(KEY_USER_TYPE, user.getType());
        editor.putString(KEY_USER_ADDRESS, user.getAddress());

        // Save children
        Map<String, Child> children = user.getChildren();
        if (children != null) {
            // Save children IDs set
            editor.putStringSet(KEY_CHILDREN_IDS, children.keySet());

            // Save each child's data
            for (Map.Entry<String, Child> entry : children.entrySet()) {
                String childId = entry.getKey();
                Child child = entry.getValue();

                String childPrefix = KEY_CHILD_PREFIX + childId + "_";
                editor.putString(childPrefix + "id", child.getId());
                editor.putString(childPrefix + "name", child.getName());
                editor.putString(childPrefix + "grade", child.getGrade());
                editor.putString(childPrefix + "busId", child.getBusId());
            }
        }

        editor.apply();
    }

    public User getUser() {
        String userId = prefs.getString(KEY_USER_ID, null);
        if (userId == null) {
            return null;
        }

        User user = new User();
        user.setId(userId);
        user.setName(prefs.getString(KEY_USER_NAME, null));
        user.setEmail(prefs.getString(KEY_USER_EMAIL, null));
        user.setPhone(prefs.getString(KEY_USER_PHONE, null));
        user.setType(prefs.getString(KEY_USER_TYPE, null));
        user.setAddress(prefs.getString(KEY_USER_ADDRESS, null));

        // Load children
        Set<String> childrenIds = prefs.getStringSet(KEY_CHILDREN_IDS, null);
        if (childrenIds != null) {
            Map<String, Child> children = new HashMap<>();
            for (String childId : childrenIds) {
                String childPrefix = KEY_CHILD_PREFIX + childId + "_";
                Child child = new Child();
                child.setId(prefs.getString(childPrefix + "id", null));
                child.setName(prefs.getString(childPrefix + "name", null));
                child.setGrade(prefs.getString(childPrefix + "grade", null));
                child.setBusId(prefs.getString(childPrefix + "busId", null));
                children.put(childId, child);
            }
            user.setChildren(children);
        }

        return user;
    }

    // Clear all preferences
    public void clearAll() {
        prefs.edit().clear().apply();
    }

    public void clearUser() {
        prefs.edit().remove(KEY_USER_ID).remove(KEY_USER_NAME).remove(KEY_USER_EMAIL).remove(KEY_USER_PHONE)
                .remove(KEY_USER_TYPE).remove(KEY_USER_ADDRESS).remove(KEY_CHILDREN_IDS).apply();
    }
}