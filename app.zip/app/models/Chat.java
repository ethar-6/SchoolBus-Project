package com.schoolbus.app.models;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;

@IgnoreExtraProperties
public class Chat {
    private String id;
    private String childId;
    private String childName;
    // Optional fields - not required for chat functionality
    private String busId;
    private String driverId;
    private String parentId;
    private String adminId;
    private Map<String, Message> messages;
    private long lastMessageTimestamp;

    // Required empty constructor for Firebase
    public Chat() {
        messages = new HashMap<>();
    }

    // Simplified constructor that only requires childId and childName
    public Chat(String childId, String childName) {
        this.id = childId + "_chat"; // Unique chat ID based on child ID
        this.childId = childId;
        this.childName = childName;
        this.messages = new HashMap<>();
        this.lastMessageTimestamp = System.currentTimeMillis();

        // Log chat creation for debugging
        android.util.Log.d("Chat", "Created new chat with ID: " + this.id + " for child: " + childName);
    }

    // Full constructor for backward compatibility
    public Chat(String childId, String childName, String busId, String driverId, String parentId, String adminId) {
        this.id = childId + "_chat"; // Unique chat ID based on child ID
        this.childId = childId;
        this.childName = childName;
        this.busId = busId;
        this.driverId = driverId;
        this.parentId = parentId;
        this.adminId = adminId;
        this.messages = new HashMap<>();
        this.lastMessageTimestamp = System.currentTimeMillis();
    }

    @Exclude
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChildId() {
        return childId;
    }

    public void setChildId(String childId) {
        this.childId = childId;
    }

    public String getChildName() {
        return childName;
    }

    public void setChildName(String childName) {
        this.childName = childName;
    }

    public String getBusId() {
        return busId;
    }

    public void setBusId(String busId) {
        this.busId = busId;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public Map<String, Message> getMessages() {
        return messages;
    }

    public void setMessages(Map<String, Message> messages) {
        this.messages = messages;
    }

    public long getLastMessageTimestamp() {
        return lastMessageTimestamp;
    }

    public void setLastMessageTimestamp(long lastMessageTimestamp) {
        this.lastMessageTimestamp = lastMessageTimestamp;
    }

    // Inner class for chat messages
    public static class Message {
        private String id;
        private String senderId;
        private String senderName;
        private String text;
        private long timestamp;
        private String status; // sent, delivered, read

        // Required empty constructor for Firebase
        public Message() {
        }

        public Message(String senderId, String senderName, String text) {
            this.id = java.util.UUID.randomUUID().toString();
            this.senderId = senderId;
            this.senderName = senderName;
            this.text = text;
            this.timestamp = System.currentTimeMillis();
            this.status = "sent";
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getSenderId() {
            return senderId;
        }

        public void setSenderId(String senderId) {
            this.senderId = senderId;
        }

        public String getSenderName() {
            return senderName;
        }

        public void setSenderName(String senderName) {
            this.senderName = senderName;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }
}