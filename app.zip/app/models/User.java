package com.schoolbus.app.models;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@IgnoreExtraProperties
public class User {
    private String id;
    private String name;
    private String email;
    private String phone;
    private String type; // parent, driver, admin
    private String address;
    private Map<String, Child> children;
    private String busId; // Used for driver users
    private String busNumber; // Used for driver users

    // Required empty constructor for Firebase
    public User() {
    }

    public User(String id, String name, String email, String phone, String type) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.type = type;
        this.children = new HashMap<>();
    }

    @Exclude
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Map<String, Child> getChildren() {
        return children;
    }

    public void setChildren(Map<String, Child> children) {
        this.children = children;
    }
    
    public String getBusId() {
        return busId;
    }

    public void setBusId(String busId) {
        this.busId = busId;
    }

    public String getBusNumber() {
        return busNumber;
    }

    public void setBusNumber(String busNumber) {
        this.busNumber = busNumber;
    }

    /**
     * Checks if the user is a driver and has a bus assigned
     * @return true if the user is a driver and has a bus assigned, false otherwise
     */
    @Exclude
    public boolean hasAssignedBus() {
        return "driver".equals(type) && busId != null && !busId.isEmpty();
    }

    // Inner class for child information (for parent users)
    public static class Child {
        @Exclude
        private String id;
        private String name;
        private String grade;
        private String busId;

        // Required empty constructor for Firebase
        public Child() {
        }

        public Child(String name, String grade, String busId) {
            this.id = UUID.randomUUID().toString();
            this.name = name;
            this.grade = grade;
            this.busId = busId;
        }

        public Child(String id, String name, String grade, String busId) {
            this.id = id;
            this.name = name;
            this.grade = grade;
            this.busId = busId;
        }

        @Exclude
        public String getId() {
            return id;
        }

        @Exclude
        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getGrade() {
            return grade;
        }

        public void setGrade(String grade) {
            this.grade = grade;
        }

        public String getBusId() {
            return busId;
        }

        public void setBusId(String busId) {
            this.busId = busId;
        }
    }
}