package com.schoolbus.app.models;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Attendance {
    private String id;
    private String studentId;
    private String studentName;
    private String busId;
    private String driverId;
    private String status;
    private long timestamp;
    private String date; // Formatted date for display
    private String time; // Formatted time for display

    // Required empty constructor for Firebase
    public Attendance() {
    }

    public Attendance(String studentId, String studentName, String busId, String driverId, String status,
            long timestamp, String date, String time) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.busId = busId;
        this.driverId = driverId;
        this.status = status;
        this.timestamp = timestamp;
        this.date = date;
        this.time = time;
    }

    @Exclude
    public String getId() {
        return id;
    }

    @Exclude
    public void setId(String id) {
        this.id = id;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getBusId() {
        return busId;
    }

    public void setBusId(String busId) {
        this.busId = busId;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}