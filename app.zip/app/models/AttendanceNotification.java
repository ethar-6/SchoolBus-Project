package com.schoolbus.app.models;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class AttendanceNotification {
    private String id;
    private String childId;
    private String childName;
    private String parentId;
    private String status; // "present" or "absent"
    private String busId;
    private String busNumber;
    private String driverId;
    private String driverName;
    private long timestamp;
    private String date;
    private String time;
    private boolean read;
    
    // Required empty constructor for Firebase
    public AttendanceNotification() {
    }
    
    public AttendanceNotification(String childId, String childName, String parentId, 
                               String status, String busId, String busNumber,
                               String driverId, String driverName, 
                               long timestamp, String date, String time) {
        this.childId = childId;
        this.childName = childName;
        this.parentId = parentId;
        this.status = status;
        this.busId = busId;
        this.busNumber = busNumber;
        this.driverId = driverId;
        this.driverName = driverName;
        this.timestamp = timestamp;
        this.date = date;
        this.time = time;
        this.read = false;
    }
    
    @Exclude
    public String getId() {
        return id;
    }
    
    @Exclude
    public void setId(String id) {
        this.id = id;
    }
    
    public String getChildId() {
        return childId;
    }
    
    public void setChildId(String childId) {
        this.childId = childId;
    }
    
    public String getChildName() {
        return childName;
    }
    
    public void setChildName(String childName) {
        this.childName = childName;
    }
    
    public String getParentId() {
        return parentId;
    }
    
    public void setParentId(String parentId) {
        this.parentId = parentId;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getBusId() {
        return busId;
    }
    
    public void setBusId(String busId) {
        this.busId = busId;
    }
    
    public String getBusNumber() {
        return busNumber;
    }
    
    public void setBusNumber(String busNumber) {
        this.busNumber = busNumber;
    }
    
    public String getDriverId() {
        return driverId;
    }
    
    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }
    
    public String getDriverName() {
        return driverName;
    }
    
    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    public String getDate() {
        return date;
    }
    
    public void setDate(String date) {
        this.date = date;
    }
    
    public String getTime() {
        return time;
    }
    
    public void setTime(String time) {
        this.time = time;
    }
    
    public boolean isRead() {
        return read;
    }
    
    public void setRead(boolean read) {
        this.read = read;
    }
} 