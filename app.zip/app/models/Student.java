package com.schoolbus.app.models;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Student {
    private String id;
    private String name;
    private String grade;
    private String busId;

    // Additional fields for display
    @Exclude
    private String parentId;
    @Exclude
    private String parentName;
    @Exclude
    private boolean present;

    // Required empty constructor for Firebase
    public Student() {
    }

    public Student(String id, String name, String grade, String busId) {
        this.id = id;
        this.name = name;
        this.grade = grade;
        this.busId = busId;
    }

    @Exclude
    public String getId() {
        return id;
    }

    @Exclude
    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getBusId() {
        return busId;
    }

    public void setBusId(String busId) {
        this.busId = busId;
    }

    @Exclude
    public String getParentId() {
        return parentId;
    }

    @Exclude
    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    @Exclude
    public String getParentName() {
        return parentName;
    }

    @Exclude
    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    @Exclude
    public boolean isPresent() {
        return present;
    }

    @Exclude
    public void setPresent(boolean present) {
        this.present = present;
    }
}