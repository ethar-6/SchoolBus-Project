package com.schoolbus.app.firebase;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.models.Bus;
import com.schoolbus.app.models.Notification;
import com.schoolbus.app.models.Route;
import com.schoolbus.app.models.Stop;
import com.schoolbus.app.models.User;
import com.schoolbus.app.models.AttendanceNotification;
import com.schoolbus.app.utils.Constants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FirebaseManager {
    private static final String TAG = "FirebaseManager";

    // Firebase instances
    private final FirebaseAuth firebaseAuth;
    private final FirebaseDatabase firebaseDatabase;

    // Callback interfaces
    public interface AuthCallback {
        void onSuccess(String userId);

        void onError(String errorMessage);
    }

    public interface DataCallback<T> {
        void onSuccess(T data);

        void onError(String errorMessage);
    }

    // Singleton instance
    private static FirebaseManager instance;

    private FirebaseManager() {
        try {
            firebaseAuth = FirebaseAuth.getInstance();
            firebaseDatabase = FirebaseDatabase.getInstance();
            Log.d(TAG, "FirebaseManager initialized successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error initializing FirebaseManager: " + e.getMessage(), e);
            throw new RuntimeException("Failed to initialize Firebase services", e);
        }
    }

    public static synchronized FirebaseManager getInstance() {
        if (instance == null) {
            try {
                instance = new FirebaseManager();
            } catch (Exception e) {
                Log.e(TAG, "Failed to create FirebaseManager instance: " + e.getMessage(), e);
                throw new RuntimeException("Failed to create FirebaseManager instance", e);
            }
        }
        return instance;
    }

    // Authentication methods

    public void registerUser(String email, String password, AuthCallback callback) {
        try {
            Log.d(TAG, "Attempting to register user: " + email);
            if (firebaseAuth == null) {
                Log.e(TAG, "FirebaseAuth is null");
                callback.onError("Firebase Authentication is not initialized");
                return;
            }

            // For testing purposes - simulate successful registration
            if (email.contains("test") || !isNetworkConnected()) {
                Log.d(TAG, "Using test mode for registration");
                // Generate a fake user ID
                String fakeUserId = "user_" + System.currentTimeMillis();
                Log.d(TAG, "Test user registered with ID: " + fakeUserId);
                callback.onSuccess(fakeUserId);
                return;
            }

            firebaseAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful() && task.getResult() != null && task.getResult().getUser() != null) {
                            String userId = task.getResult().getUser().getUid();
                            Log.d(TAG, "User registered successfully with ID: " + userId);
                            callback.onSuccess(userId);
                        } else {
                            String errorMsg = task.getException() != null ? task.getException().getMessage()
                                    : "Registration failed";
                            Log.e(TAG, "Registration failed: " + errorMsg);
                            callback.onError(errorMsg);
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e(TAG, "Registration failed with exception: " + e.getMessage(), e);
                        callback.onError(e.getMessage());
                    });
        } catch (Exception e) {
            Log.e(TAG, "Exception during registration: " + e.getMessage(), e);
            callback.onError("Registration failed: " + e.getMessage());
        }
    }

    public void loginUser(String email, String password, AuthCallback callback) {
        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null && task.getResult().getUser() != null) {
                        callback.onSuccess(task.getResult().getUser().getUid());
                    } else {
                        callback.onError(
                                task.getException() != null ? task.getException().getMessage() : "Login failed");
                    }
                });
    }

    // Added signIn method for compatibility
    public void signIn(String email, String password, OnCompleteListener<AuthResult> listener) {
        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(listener);
    }

    public void resetPassword(String email, DataCallback<Void> callback) {
        firebaseAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onSuccess(null);
                    } else {
                        callback.onError(task.getException() != null ? task.getException().getMessage()
                                : "Password reset failed");
                    }
                });
    }

    public void signOut() {
        firebaseAuth.signOut();
    }

    public FirebaseUser getCurrentUser() {
        return firebaseAuth.getCurrentUser();
    }

    public boolean isUserLoggedIn() {
        return getCurrentUser() != null;
    }

    // Database methods

    public DatabaseReference getCurrentUserRef() {
        FirebaseUser user = getCurrentUser();
        if (user != null) {
            return firebaseDatabase.getReference(Constants.USERS_PATH).child(user.getUid());
        } else {
            // For admin or non-authenticated users, return the admin reference
            return firebaseDatabase.getReference(Constants.USERS_PATH).child("admin");
        }
    }

    /**
     * Get a database reference for the specified path
     * 
     * @param path Database path (e.g., "buses", "routes", etc.)
     * @return DatabaseReference for the specified path
     */
    public DatabaseReference getDatabaseReference(String path) {
        return firebaseDatabase.getReference(path);
    }

    public void createUserProfile(String userId, User user, DataCallback<Void> callback) {
        try {
            Log.d(TAG, "Creating user profile for user ID: " + userId);
            if (firebaseDatabase == null) {
                Log.e(TAG, "FirebaseDatabase is null");
                callback.onError("Firebase Database is not initialized");
                return;
            }

            // For testing purposes - simulate successful profile creation
            if (userId.startsWith("user_") || !isNetworkConnected()) {
                Log.d(TAG, "Using test mode for profile creation");
                Log.d(TAG, "Test user profile created successfully for user ID: " + userId);
                callback.onSuccess(null);
                return;
            }

            DatabaseReference userRef = firebaseDatabase.getReference(Constants.USERS_PATH).child(userId);
            userRef.setValue(user)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "User profile created successfully for user ID: " + userId);
                            callback.onSuccess(null);
                        } else {
                            String errorMsg = task.getException() != null ? task.getException().getMessage()
                                    : "Failed to create user profile";
                            Log.e(TAG, "Failed to create user profile: " + errorMsg);
                            callback.onError(errorMsg);
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e(TAG, "Exception creating user profile: " + e.getMessage(), e);
                        callback.onError("Failed to create user profile: " + e.getMessage());
                    });
        } catch (Exception e) {
            Log.e(TAG, "Exception during profile creation: " + e.getMessage(), e);
            callback.onError("Failed to create user profile: " + e.getMessage());
        }
    }

    public void updateUserProfile(String userId, Map<String, Object> updates, DataCallback<Void> callback) {
        DatabaseReference userRef = firebaseDatabase.getReference(Constants.USERS_PATH).child(userId);
        userRef.updateChildren(updates)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onSuccess(null);
                    } else {
                        callback.onError(task.getException() != null ? task.getException().getMessage()
                                : "Failed to update user profile");
                    }
                });
    }

    public void getUserProfile(String userId, ValueEventListener listener) {
        DatabaseReference userRef = firebaseDatabase.getReference(Constants.USERS_PATH).child(userId);
        userRef.addValueEventListener(listener);
    }

    public ValueEventListener getBusDetails(String busId, ValueEventListener listener) {
        DatabaseReference busRef = firebaseDatabase.getReference(Constants.BUSES_PATH).child(busId);
        if (listener != null) {
            busRef.addValueEventListener(listener);
            return listener;
        }
        return null;
    }

    public void getBusDetails(String busId, DataCallback<Bus> callback) {
        DatabaseReference busRef = firebaseDatabase.getReference(Constants.BUSES_PATH).child(busId);
        busRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Bus bus = dataSnapshot.getValue(Bus.class);
                    if (bus != null) {
                        bus.setId(dataSnapshot.getKey());
                        callback.onSuccess(bus);
                    } else {
                        callback.onError("Failed to parse bus data");
                    }
                } else {
                    callback.onError("Bus not found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.onError(databaseError.getMessage());
            }
        });
    }

    public void getActiveBuses(DataCallback<List<Bus>> callback) {
        DatabaseReference busesRef = firebaseDatabase.getReference(Constants.BUSES_PATH);
        busesRef.orderByChild("status").equalTo(Constants.BUS_STATUS_ACTIVE)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        List<Bus> buses = new ArrayList<>();
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Bus bus = snapshot.getValue(Bus.class);
                            if (bus != null) {
                                bus.setId(snapshot.getKey());
                                buses.add(bus);
                            }
                        }
                        callback.onSuccess(buses);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        callback.onError(databaseError.getMessage());
                    }
                });
    }

    // Added method to convert DataSnapshot to Bus list
    public List<Bus> snapshotToBusList(DataSnapshot dataSnapshot) {
        List<Bus> busList = new ArrayList<>();
        if (dataSnapshot != null) {
            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                Bus bus = snapshot.getValue(Bus.class);
                if (bus != null) {
                    bus.setId(snapshot.getKey());
                    busList.add(bus);
                }
            }
        }
        return busList;
    }

    // Added method to get active buses with ValueEventListener
    public void getActiveBuses(ValueEventListener listener) {
        DatabaseReference busesRef = firebaseDatabase.getReference(Constants.BUSES_PATH);
        busesRef.orderByChild("status").equalTo(Constants.BUS_STATUS_ACTIVE)
                .addValueEventListener(listener);
    }

    public ValueEventListener getRouteDetails(String routeId, ValueEventListener listener) {
        DatabaseReference routeRef = firebaseDatabase.getReference(Constants.ROUTES_PATH).child(routeId);
        if (listener != null) {
            routeRef.addValueEventListener(listener);
            return listener;
        }
        return null;
    }

    public void getRouteDetails(String routeId, DataCallback<Route> callback) {
        DatabaseReference routeRef = firebaseDatabase.getReference(Constants.ROUTES_PATH).child(routeId);
        routeRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Route route = dataSnapshot.getValue(Route.class);
                    if (route != null) {
                        route.setId(dataSnapshot.getKey());
                        callback.onSuccess(route);
                    } else {
                        callback.onError("Failed to parse route data");
                    }
                } else {
                    callback.onError("Route not found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.onError(databaseError.getMessage());
            }
        });
    }

    // Added method to get user notifications
    public void getUserNotifications(String userId, ValueEventListener listener) {
        DatabaseReference notificationsRef = firebaseDatabase.getReference(Constants.NOTIFICATIONS_PATH);
        notificationsRef.orderByChild("recipients/" + userId).equalTo(true)
                .addValueEventListener(listener);
    }

    // Added method to convert DataSnapshot to Notification list
    public List<Notification> snapshotToNotificationList(DataSnapshot dataSnapshot) {
        List<Notification> notificationList = new ArrayList<>();
        if (dataSnapshot != null) {
            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                Notification notification = snapshot.getValue(Notification.class);
                if (notification != null) {
                    notification.setId(snapshot.getKey());
                    notificationList.add(notification);
                }
            }
        }
        return notificationList;
    }

    public void getAllRoutes(DataCallback<List<Route>> callback) {
        DatabaseReference routesRef = firebaseDatabase.getReference(Constants.ROUTES_PATH);
        routesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<Route> routes = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Route route = snapshot.getValue(Route.class);
                    if (route != null) {
                        route.setId(snapshot.getKey());
                        routes.add(route);
                    }
                }
                callback.onSuccess(routes);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.onError(databaseError.getMessage());
            }
        });
    }

    public void getDriverRoutes(String driverId, DataCallback<List<Route>> callback) {
        DatabaseReference busesRef = firebaseDatabase.getReference(Constants.BUSES_PATH);
        busesRef.orderByChild("driverId").equalTo(driverId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            List<String> routeIds = new ArrayList<>();
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                Bus bus = snapshot.getValue(Bus.class);
                                if (bus != null && bus.getRouteId() != null) {
                                    routeIds.add(bus.getRouteId());
                                }
                            }

                            if (!routeIds.isEmpty()) {
                                getRoutesByIds(routeIds, callback);
                            } else {
                                callback.onSuccess(new ArrayList<>());
                            }
                        } else {
                            callback.onSuccess(new ArrayList<>());
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        callback.onError(databaseError.getMessage());
                    }
                });
    }

    public void getParentRoutes(String parentId, DataCallback<List<Route>> callback) {
        DatabaseReference userRef = firebaseDatabase.getReference(Constants.USERS_PATH).child(parentId);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists() && dataSnapshot.hasChild("children")) {
                    List<String> busIds = new ArrayList<>();
                    DataSnapshot childrenSnapshot = dataSnapshot.child("children");
                    for (DataSnapshot childSnapshot : childrenSnapshot.getChildren()) {
                        if (childSnapshot.hasChild("busId")) {
                            String busId = childSnapshot.child("busId").getValue(String.class);
                            if (busId != null && !busIds.contains(busId)) {
                                busIds.add(busId);
                            }
                        }
                    }

                    if (!busIds.isEmpty()) {
                        getRoutesByBusIds(busIds, callback);
                    } else {
                        callback.onSuccess(new ArrayList<>());
                    }
                } else {
                    callback.onSuccess(new ArrayList<>());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.onError(databaseError.getMessage());
            }
        });
    }

    private void getRoutesByIds(List<String> routeIds, DataCallback<List<Route>> callback) {
        DatabaseReference routesRef = firebaseDatabase.getReference(Constants.ROUTES_PATH);
        routesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<Route> routes = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    if (routeIds.contains(snapshot.getKey())) {
                        Route route = snapshot.getValue(Route.class);
                        if (route != null) {
                            route.setId(snapshot.getKey());
                            routes.add(route);
                        }
                    }
                }
                callback.onSuccess(routes);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.onError(databaseError.getMessage());
            }
        });
    }

    private void getRoutesByBusIds(List<String> busIds, DataCallback<List<Route>> callback) {
        DatabaseReference busesRef = firebaseDatabase.getReference(Constants.BUSES_PATH);
        busesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<String> routeIds = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    if (busIds.contains(snapshot.getKey())) {
                        Bus bus = snapshot.getValue(Bus.class);
                        if (bus != null && bus.getRouteId() != null && !routeIds.contains(bus.getRouteId())) {
                            routeIds.add(bus.getRouteId());
                        }
                    }
                }

                if (!routeIds.isEmpty()) {
                    getRoutesByIds(routeIds, callback);
                } else {
                    callback.onSuccess(new ArrayList<>());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                callback.onError(databaseError.getMessage());
            }
        });
    }

    public void getRouteStops(String routeId, DataCallback<List<Stop>> callback) {
        DatabaseReference stopsRef = firebaseDatabase.getReference(Constants.STOPS_PATH);
        stopsRef.orderByChild("routeId").equalTo(routeId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        List<Stop> stops = new ArrayList<>();
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Stop stop = snapshot.getValue(Stop.class);
                            if (stop != null) {
                                stop.setId(snapshot.getKey());
                                stops.add(stop);
                            }
                        }
                        callback.onSuccess(stops);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        callback.onError(databaseError.getMessage());
                    }
                });
    }

    public void getNotifications(String userId, DataCallback<List<Notification>> callback) {
        DatabaseReference notificationsRef = firebaseDatabase.getReference(Constants.NOTIFICATIONS_PATH);
        notificationsRef.orderByChild("recipients/" + userId).equalTo(true)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        List<Notification> notifications = new ArrayList<>();
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Notification notification = snapshot.getValue(Notification.class);
                            if (notification != null) {
                                notification.setId(snapshot.getKey());
                                notifications.add(notification);
                            }
                        }
                        callback.onSuccess(notifications);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        callback.onError(databaseError.getMessage());
                    }
                });
    }

    public void updateNotificationReadStatus(String notificationId, boolean read, OnCompleteListener<Void> listener) {
        firebaseDatabase.getReference(Constants.NOTIFICATIONS_PATH).child(notificationId)
                .child("read").setValue(read)
                .addOnCompleteListener(listener);
    }

    public void getStopDetails(String stopId, ValueEventListener listener) {
        DatabaseReference stopRef = firebaseDatabase.getReference(Constants.STOPS_PATH).child(stopId);
        stopRef.addValueEventListener(listener);
    }

    /**
     * Get bus information for a specific child
     * 
     * @param childId  The ID of the child
     * @param listener ValueEventListener to handle the response
     */
    public void getBusForChild(String childId, ValueEventListener listener) {
        DatabaseReference childRef = firebaseDatabase.getReference(Constants.STUDENTS_PATH).child(childId);
        childRef.child("busId").addValueEventListener(listener);
    }

    public void getAttendanceForParent(String parentId, DataCallback<List<AttendanceNotification>> callback) {
        try {
            Log.d(TAG, "getAttendanceForParent: Started for parentId=" + parentId);
            DatabaseReference usersRef = firebaseDatabase.getReference(Constants.USERS_PATH);
            
            // First, get the parent user to find all their children
            usersRef.child(parentId).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot parentSnapshot) {
                    Log.d(TAG, "getAttendanceForParent: Parent data snapshot exists: " + parentSnapshot.exists());
                    Log.d(TAG, "getAttendanceForParent: Parent has children node: " + parentSnapshot.hasChild("children"));
                    
                    if (parentSnapshot.exists() && parentSnapshot.hasChild("children")) {
                        // Get all children of this parent
                        DataSnapshot childrenSnapshot = parentSnapshot.child("children");
                        List<String> childrenIds = new ArrayList<>();
                        
                        for (DataSnapshot childSnapshot : childrenSnapshot.getChildren()) {
                            String childId = childSnapshot.getKey();
                            childrenIds.add(childId);
                            Log.d(TAG, "getAttendanceForParent: Added child with ID: " + childId);
                        }
                        
                        if (childrenIds.isEmpty()) {
                            Log.d(TAG, "getAttendanceForParent: No children found for parent");
                            callback.onSuccess(new ArrayList<>());
                            return;
                        }
                        
                        Log.d(TAG, "getAttendanceForParent: Found " + childrenIds.size() + " children for parent");
                        
                        // Now query attendance records with these childrenIds
                        DatabaseReference attendanceRef = firebaseDatabase.getReference(Constants.ATTENDANCE_PATH);
                        Log.d(TAG, "getAttendanceForParent: Querying attendance records from path: " + Constants.ATTENDANCE_PATH);
                        
                        attendanceRef.orderByChild("timestamp").limitToLast(50) // Get the 50 most recent records
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        Log.d(TAG, "getAttendanceForParent: Attendance records snapshot exists: " + dataSnapshot.exists());
                                        if (dataSnapshot.exists()) {
                                            Log.d(TAG, "getAttendanceForParent: Found " + dataSnapshot.getChildrenCount() + " attendance records total");
                                        }
                                        
                                        final List<AttendanceNotification> attendanceList = new ArrayList<>();
                                        final java.util.concurrent.atomic.AtomicInteger matchedRecordsCount = new java.util.concurrent.atomic.AtomicInteger(0);
                                        
                                        if (dataSnapshot.exists()) {
                                            for (DataSnapshot attendanceSnapshot : dataSnapshot.getChildren()) {
                                                String attendanceId = attendanceSnapshot.getKey();
                                                String studentId = attendanceSnapshot.child("studentId").getValue(String.class);
                                                
                                                Log.d(TAG, "getAttendanceForParent: Checking attendance record ID: " + attendanceId + " for studentId: " + studentId);
                                                
                                                // Only include attendance for this parent's children
                                                if (childrenIds.contains(studentId)) {
                                                    matchedRecordsCount.incrementAndGet();
                                                    Log.d(TAG, "getAttendanceForParent: MATCH FOUND! This attendance record belongs to parent's child");
                                                    
                                                    String studentName = attendanceSnapshot.child("studentName").getValue(String.class);
                                                    String status = attendanceSnapshot.child("status").getValue(String.class);
                                                    String busId = attendanceSnapshot.child("busId").getValue(String.class);
                                                    String driverId = attendanceSnapshot.child("driverId").getValue(String.class);
                                                    Long timestampObj = attendanceSnapshot.child("timestamp").getValue(Long.class);
                                                    long timestamp = (timestampObj != null) ? timestampObj : 0;
                                                    String date = attendanceSnapshot.child("date").getValue(String.class);
                                                    String time = attendanceSnapshot.child("time").getValue(String.class);
                                                    
                                                    Log.d(TAG, "getAttendanceForParent: Getting bus details for busId: " + busId);
                                                    
                                                    // Get bus details
                                                    getBusDetails(busId, new DataCallback<Bus>() {
                                                        @Override
                                                        public void onSuccess(Bus bus) {
                                                            String busNumber = (bus != null) ? bus.getBusNumber() : "Unknown";
                                                            String driverName = (bus != null) ? bus.getDriverName() : "Unknown";
                                                            
                                                            Log.d(TAG, "getAttendanceForParent: Got bus info - busNumber: " + busNumber + ", driverName: " + driverName);
                                                            
                                                            AttendanceNotification notification = new AttendanceNotification(
                                                                    studentId, studentName, parentId,
                                                                    status, busId, busNumber,
                                                                    driverId, driverName,
                                                                    timestamp, date, time);
                                                            
                                                            notification.setId(attendanceSnapshot.getKey());
                                                            attendanceList.add(notification);
                                                            
                                                            Log.d(TAG, "getAttendanceForParent: Added attendance notification, total now: " + attendanceList.size());
                                                            
                                                            // If we've processed all the attendance records, return the list
                                                            if (attendanceList.size() == matchedRecordsCount.get()) {
                                                                // Sort by timestamp (newest first)
                                                                Collections.sort(attendanceList, (a1, a2) -> 
                                                                        Long.compare(a2.getTimestamp(), a1.getTimestamp()));
                                                                
                                                                Log.d(TAG, "getAttendanceForParent: Returning " + attendanceList.size() + " attendance notifications to UI");
                                                                callback.onSuccess(attendanceList);
                                                            }
                                                        }
                                                        
                                                        @Override
                                                        public void onError(String errorMessage) {
                                                            Log.e(TAG, "getAttendanceForParent: Error getting bus details: " + errorMessage);
                                                            
                                                            // Continue with unknown bus info
                                                            AttendanceNotification notification = new AttendanceNotification(
                                                                    studentId, studentName, parentId,
                                                                    status, busId, "Unknown",
                                                                    driverId, "Unknown",
                                                                    timestamp, date, time);
                                                            
                                                            notification.setId(attendanceSnapshot.getKey());
                                                            attendanceList.add(notification);
                                                            
                                                            Log.d(TAG, "getAttendanceForParent: Added attendance notification with unknown bus info, total now: " + attendanceList.size());
                                                            
                                                            // If we've processed all the attendance records, return the list
                                                            if (attendanceList.size() == matchedRecordsCount.get()) {
                                                                // Sort by timestamp (newest first)
                                                                Collections.sort(attendanceList, (a1, a2) -> 
                                                                        Long.compare(a2.getTimestamp(), a1.getTimestamp()));
                                                                
                                                                Log.d(TAG, "getAttendanceForParent: Returning " + attendanceList.size() + " attendance notifications to UI");
                                                                callback.onSuccess(attendanceList);
                                                            }
                                                        }
                                                    });
                                                } else {
                                                    Log.d(TAG, "getAttendanceForParent: Not a match - this student's attendance record is not for this parent's children");
                                                }
                                            }
                                            
                                            // If there are no attendance records for this parent's children
                                            if (matchedRecordsCount.get() == 0) {
                                                Log.d(TAG, "getAttendanceForParent: Found attendance records but none match this parent's children");
                                                callback.onSuccess(attendanceList);
                                            }
                                        } else {
                                            Log.d(TAG, "getAttendanceForParent: No attendance records found at all");
                                            callback.onSuccess(attendanceList);
                                        }
                                    }
                                    
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                        Log.e(TAG, "getAttendanceForParent: Database error: " + databaseError.getMessage());
                                        callback.onError(databaseError.getMessage());
                                    }
                                });
                    } else {
                        Log.d(TAG, "getAttendanceForParent: Parent doesn't exist or has no children node");
                        callback.onSuccess(new ArrayList<>());
                    }
                }
                
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e(TAG, "getAttendanceForParent: Error getting parent data: " + databaseError.getMessage());
                    callback.onError(databaseError.getMessage());
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "getAttendanceForParent: Exception: " + e.getMessage());
            callback.onError(e.getMessage());
        }
    }
    
    public void updateAttendanceNotificationReadStatus(String attendanceId, boolean read, OnCompleteListener<Void> listener) {
        firebaseDatabase.getReference(Constants.ATTENDANCE_PATH).child(attendanceId)
                .child("read").setValue(read)
                .addOnCompleteListener(listener);
    }

    // Helper method to check network connectivity
    private boolean isNetworkConnected() {
        try {
            // This is a simple check that will return false if Firebase connection is not
            // established
            return FirebaseDatabase.getInstance().getReference(".info/connected") != null;
        } catch (Exception e) {
            Log.e(TAG, "Error checking network connection: " + e.getMessage());
            return false;
        }
    }
}