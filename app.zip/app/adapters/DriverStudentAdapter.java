package com.schoolbus.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolbus.app.R;
import com.schoolbus.app.models.Student;

import java.util.List;

public class DriverStudentAdapter extends RecyclerView.Adapter<DriverStudentAdapter.StudentViewHolder> {
    private List<Student> studentList;

    public DriverStudentAdapter(List<Student> studentList) {
        this.studentList = studentList;
    }

    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_driver_student, parent, false);
        return new StudentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        Student student = studentList.get(position);
        holder.textViewStudentName.setText(student.getName());
        holder.textViewStudentGrade.setText("Grade: " + student.getGrade());

        // Set initial checkbox state
        holder.checkBoxPresent.setChecked(student.isPresent());

        // Add attendance tracking functionality
        holder.checkBoxPresent.setOnCheckedChangeListener((buttonView, isChecked) -> {
            student.setPresent(isChecked);
        });
    }

    @Override
    public int getItemCount() {
        return studentList.size();
    }

    public List<Student> getStudentList() {
        return studentList;
    }

    public static class StudentViewHolder extends RecyclerView.ViewHolder {
        ImageView imageViewStudent;
        TextView textViewStudentName;
        TextView textViewStudentGrade;
        CheckBox checkBoxPresent;

        public StudentViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewStudent = itemView.findViewById(R.id.imageViewStudent);
            textViewStudentName = itemView.findViewById(R.id.textViewStudentName);
            textViewStudentGrade = itemView.findViewById(R.id.textViewStudentGrade);
            checkBoxPresent = itemView.findViewById(R.id.checkBoxPresent);
        }
    }
}