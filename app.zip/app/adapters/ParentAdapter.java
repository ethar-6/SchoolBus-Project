package com.schoolbus.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolbus.app.R;
import com.schoolbus.app.models.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ParentAdapter extends RecyclerView.Adapter<ParentAdapter.ParentViewHolder> {

    private Context context;
    private List<User> parentsList;
    private OnParentClickListener listener;
    private List<Integer> expandedPositions = new ArrayList<>();
    private Map<String, Map<String, User.Child>> childrenCache = new HashMap<>();

    public interface OnParentClickListener {
        void onParentClick(User parent);

        void onEditClick(User parent);

        void onViewChildrenClick(User parent, int position);

        void onDeleteClick(User parent, int position);
    }

    public ParentAdapter(Context context, List<User> parentsList, OnParentClickListener listener) {
        this.context = context;
        this.parentsList = parentsList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ParentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_parent, parent, false);
        return new ParentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ParentViewHolder holder, int position) {
        User parent = parentsList.get(position);

        holder.textParentName.setText(parent.getName());
        holder.textParentPhone.setText("Phone: " + parent.getPhone());
        holder.textParentEmail.setText("Email: " + parent.getEmail());

        // Set children count
        int childrenCount = 0;
        if (parent.getChildren() != null) {
            childrenCount = parent.getChildren().size();
        }

        holder.textChildrenCount.setText("Children: " + childrenCount);

        // Check if this item is expanded
        boolean isExpanded = expandedPositions.contains(position);
        holder.childrenContainer.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
        holder.textViewChildren.setText(isExpanded ? "Hide Children" : "View Children");

        // If expanded and we have children in cache, show them
        if (isExpanded && childrenCache.containsKey(parent.getId())) {
            displayChildrenInContainer(holder.childrenContainer, childrenCache.get(parent.getId()));
        }

        // Set click listeners
        holder.itemView.setOnClickListener(v -> listener.onParentClick(parent));
        holder.buttonEdit.setOnClickListener(v -> listener.onEditClick(parent));
        holder.buttonDelete.setOnClickListener(v -> listener.onDeleteClick(parent, position));
        holder.textViewChildren.setOnClickListener(v -> {
            // Toggle expanded state
            boolean expanded = expandedPositions.contains(position);
            if (expanded) {
                expandedPositions.remove(Integer.valueOf(position));
                holder.childrenContainer.setVisibility(View.GONE);
                holder.textViewChildren.setText("View Children");
            } else {
                expandedPositions.add(position);
                holder.childrenContainer.setVisibility(View.VISIBLE);
                holder.textViewChildren.setText("Hide Children");
                listener.onViewChildrenClick(parent, position);
            }
        });

        // Disable the view children button if no children
        holder.textViewChildren.setEnabled(childrenCount > 0);
        holder.textViewChildren.setAlpha(childrenCount > 0 ? 1.0f : 0.5f);
    }

    @Override
    public int getItemCount() {
        return parentsList.size();
    }

    public void updateParents(List<User> parents) {
        this.parentsList = parents;
        notifyDataSetChanged();
    }

    public void displayChildrenForParent(int position, Map<String, User.Child> children) {
        if (position >= 0 && position < parentsList.size()) {
            User parent = parentsList.get(position);

            // Cache the children for this parent
            if (parent != null && parent.getId() != null) {
                childrenCache.put(parent.getId(), children);
            }

            RecyclerView recyclerView = getRecyclerView();
            if (recyclerView == null) {
                return;
            }

            ParentViewHolder holder = (ParentViewHolder) recyclerView.findViewHolderForAdapterPosition(position);

            // If holder is null, just cache the children - they'll be displayed when
            // binding
            if (holder == null) {
                return;
            }

            if (children != null) {
                displayChildrenInContainer(holder.childrenContainer, children);
            }
        }
    }

    private void displayChildrenInContainer(LinearLayout container, Map<String, User.Child> children) {
        // Clear previous children
        container.removeAllViews();

        // Add each child view
        for (Map.Entry<String, User.Child> entry : children.entrySet()) {
            try {
                User.Child child = entry.getValue();
                View childView = LayoutInflater.from(context).inflate(R.layout.item_parent_child,
                        container, false);

                TextView textChildName = childView.findViewById(R.id.textChildName);
                TextView textChildGrade = childView.findViewById(R.id.textChildGrade);
                TextView textChildBus = childView.findViewById(R.id.textChildBus);
                View viewAttendanceButton = childView.findViewById(R.id.viewAttendanceButton);

                textChildName.setText(child.getName());
                textChildGrade.setText("Grade: " + child.getGrade());
                textChildBus.setText("Bus ID: " + (child.getBusId() != null ? child.getBusId() : "Not assigned"));

                // Add click listener for view attendance button
                if (viewAttendanceButton != null) {
                    viewAttendanceButton.setOnClickListener(v -> {
                        // Launch attendance history activity
                        android.content.Intent intent = new android.content.Intent(context,
                                com.schoolbus.app.activities.AttendanceHistoryActivity.class);
                        intent.putExtra(com.schoolbus.app.activities.AttendanceHistoryActivity.EXTRA_STUDENT_ID,
                                entry.getKey());
                        intent.putExtra(com.schoolbus.app.activities.AttendanceHistoryActivity.EXTRA_STUDENT_NAME,
                                child.getName());
                        context.startActivity(intent);
                    });
                }

                // Add margin between child items
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                layoutParams.setMargins(0, 0, 0, 8);
                childView.setLayoutParams(layoutParams);

                container.addView(childView);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private RecyclerView getRecyclerView() {
        // Avoid potential recursion by getting RecyclerView from context
        if (context instanceof AppCompatActivity) {
            AppCompatActivity activity = (AppCompatActivity) context;
            return activity.findViewById(R.id.recyclerViewParents);
        }
        return null;
    }

    static class ParentViewHolder extends RecyclerView.ViewHolder {
        TextView textParentName, textParentPhone, textParentEmail, textChildrenCount, textViewChildren;
        ImageButton buttonEdit, buttonDelete;
        LinearLayout childrenContainer;

        public ParentViewHolder(@NonNull View itemView) {
            super(itemView);
            textParentName = itemView.findViewById(R.id.textParentName);
            textParentPhone = itemView.findViewById(R.id.textParentPhone);
            textParentEmail = itemView.findViewById(R.id.textParentEmail);
            textChildrenCount = itemView.findViewById(R.id.textChildrenCount);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
            childrenContainer = itemView.findViewById(R.id.childrenContainer);
            textViewChildren = itemView.findViewById(R.id.textViewChildren);
        }
    }
}