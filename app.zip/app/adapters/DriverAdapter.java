package com.schoolbus.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolbus.app.R;
import com.schoolbus.app.models.Driver;

import java.util.List;

public class DriverAdapter extends RecyclerView.Adapter<DriverAdapter.DriverViewHolder> {

    private final List<Driver> drivers;
    private final Context context;
    private final OnDriverClickListener listener;

    public interface OnDriverClickListener {
        void onDriverClick(Driver driver);
    }

    public DriverAdapter(Context context, List<Driver> drivers, OnDriverClickListener listener) {
        this.context = context;
        this.drivers = drivers;
        this.listener = listener;
    }

    @NonNull
    @Override
    public DriverViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_driver, parent, false);
        return new DriverViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DriverViewHolder holder, int position) {
        Driver driver = drivers.get(position);
        holder.bind(driver);
    }

    @Override
    public int getItemCount() {
        return drivers.size();
    }

    public class DriverViewHolder extends RecyclerView.ViewHolder {
        private final TextView driverNameTextView;
        private final TextView driverIdTextView;
        private final TextView busAssignedTextView;

        public DriverViewHolder(@NonNull View itemView) {
            super(itemView);
            driverNameTextView = itemView.findViewById(R.id.driverNameTextView);
            driverIdTextView = itemView.findViewById(R.id.driverIdTextView);
            busAssignedTextView = itemView.findViewById(R.id.busAssignedTextView);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onDriverClick(drivers.get(position));
                }
            });
        }

        public void bind(Driver driver) {
            driverNameTextView.setText(driver.getName());
            driverIdTextView.setText(context.getString(R.string.driver_id, driver.getId()));

            if (driver.hasBusAssigned()) {
                busAssignedTextView.setText(context.getString(R.string.bus_assigned, driver.getBusNumber()));
            } else {
                busAssignedTextView.setText(R.string.no_bus_assigned);
            }
        }
    }
}