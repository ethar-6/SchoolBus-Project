package com.schoolbus.app.adapters;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.schoolbus.app.R;
import com.schoolbus.app.activities.AttendanceHistoryActivity;
import com.schoolbus.app.activities.ChatConversationActivity;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.Bus;
import com.schoolbus.app.models.Chat;
import com.schoolbus.app.models.User;
import com.schoolbus.app.services.ChatService;
import com.schoolbus.app.utils.Constants;

import java.util.List;

public class ChildrenAdapter extends RecyclerView.Adapter<ChildrenAdapter.ChildViewHolder> {

    private List<User.Child> children;
    private final OnChildClickListener listener;

    public interface OnChildClickListener {
        void onChildClick(User.Child child);
    }

    public ChildrenAdapter(List<User.Child> children, OnChildClickListener listener) {
        this.children = children;
        this.listener = listener;
    }

    public void updateChildren(List<User.Child> newChildren) {
        this.children = newChildren;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ChildViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_child, parent, false);
        return new ChildViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChildViewHolder holder, int position) {
        User.Child child = children.get(position);
        holder.bind(child, listener);
    }

    @Override
    public int getItemCount() {
        return children.size();
    }

    static class ChildViewHolder extends RecyclerView.ViewHolder {
        private final ImageView childImageView;
        private final TextView childNameTextView;
        private final TextView gradeTextView;
        private final TextView busTextView;
        private final TextView studentIdTextView;
        private final ImageButton editButton;
        private final MaterialButton viewAttendanceButton;
        private final MaterialButton chatButton;

        public ChildViewHolder(@NonNull View itemView) {
            super(itemView);
            childImageView = itemView.findViewById(R.id.childImageView);
            childNameTextView = itemView.findViewById(R.id.childNameTextView);
            gradeTextView = itemView.findViewById(R.id.gradeTextView);
            busTextView = itemView.findViewById(R.id.busTextView);
            studentIdTextView = itemView.findViewById(R.id.studentIdTextView);
            editButton = itemView.findViewById(R.id.editButton);
            viewAttendanceButton = itemView.findViewById(R.id.viewAttendanceButton);
            chatButton = itemView.findViewById(R.id.chatButton);
        }

        public void bind(User.Child child, OnChildClickListener listener) {
            childNameTextView.setText(child.getName());
            gradeTextView.setText(String.format("Grade %s", child.getGrade()));
            studentIdTextView.setText(String.format("ID: %s", child.getId()));

            // Load and display bus information
            FirebaseManager.getInstance().getBusDetails(child.getBusId(), new FirebaseManager.DataCallback<Bus>() {
                @Override
                public void onSuccess(Bus bus) {
                    busTextView.setText(String.format("Bus: %s", bus.getBusNumber()));
                }

                @Override
                public void onError(String errorMessage) {
                    busTextView.setText("Bus: Unknown");
                }
            });

            editButton.setOnClickListener(v -> listener.onChildClick(child));

            // Set up view attendance button click
            viewAttendanceButton.setOnClickListener(v -> {
                Intent intent = new Intent(itemView.getContext(), AttendanceHistoryActivity.class);
                intent.putExtra(AttendanceHistoryActivity.EXTRA_STUDENT_ID, child.getId());
                intent.putExtra(AttendanceHistoryActivity.EXTRA_STUDENT_NAME, child.getName());
                itemView.getContext().startActivity(intent);
            });

            // Set up chat button click
            chatButton.setOnClickListener(v -> {
                // Show loading dialog
                android.app.ProgressDialog progressDialog = new android.app.ProgressDialog(itemView.getContext());
                progressDialog.setMessage("Loading chat...");
                progressDialog.setCancelable(false);
                progressDialog.show();

                // Get or create chat for child
                ChatService chatService = new ChatService(FirebaseManager.getInstance().getDatabaseReference(""),
                        itemView.getContext());
                chatService.getOrCreateChatForChild(child.getId(), child.getName(),
                        new ChatService.ChatCallback() {
                            @Override
                            public void onSuccess(Chat chat) {
                                progressDialog.dismiss();

                                // Navigate to chat conversation
                                Intent intent = new Intent(itemView.getContext(), ChatConversationActivity.class);
                                intent.putExtra(Constants.EXTRA_CHAT_ID, chat.getId());
                                intent.putExtra(Constants.EXTRA_CHILD_NAME, child.getName());
                                itemView.getContext().startActivity(intent);
                            }

                            @Override
                            public void onError(String error) {
                                progressDialog.dismiss();
                                Toast.makeText(itemView.getContext(), "Error: " + error, Toast.LENGTH_SHORT).show();
                            }
                        });
            });
        }
    }
}