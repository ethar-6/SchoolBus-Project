package com.schoolbus.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolbus.app.R;
import com.schoolbus.app.models.Attendance;
import com.schoolbus.app.utils.Constants;

import java.util.List;

public class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.AttendanceViewHolder> {

    private List<Attendance> attendanceList;

    public AttendanceAdapter(List<Attendance> attendanceList) {
        this.attendanceList = attendanceList;
    }

    @NonNull
    @Override
    public AttendanceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_attendance, parent, false);
        return new AttendanceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AttendanceViewHolder holder, int position) {
        Attendance attendance = attendanceList.get(position);

        // Set date and time
        holder.dateTextView.setText(String.format("Date: %s", attendance.getDate()));
        holder.timeTextView.setText(String.format("Time: %s", attendance.getTime()));

        // Set status with appropriate color
        if (Constants.ATTENDANCE_STATUS_PRESENT.equals(attendance.getStatus())) {
            holder.statusTextView.setText(R.string.present);
            holder.statusTextView
                    .setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.status_active));
        } else {
            holder.statusTextView.setText(R.string.absent);
            holder.statusTextView
                    .setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.status_error));
        }
    }

    @Override
    public int getItemCount() {
        return attendanceList.size();
    }

    static class AttendanceViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView;
        TextView timeTextView;
        TextView statusTextView;

        public AttendanceViewHolder(@NonNull View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            timeTextView = itemView.findViewById(R.id.timeTextView);
            statusTextView = itemView.findViewById(R.id.statusTextView);
        }
    }
}