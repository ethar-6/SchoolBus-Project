package com.schoolbus.app.adapters;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.schoolbus.app.R;
import com.schoolbus.app.activities.AttendanceHistoryActivity;
import com.schoolbus.app.activities.ChatConversationActivity;
import com.schoolbus.app.activities.EditStudentActivity;
import com.schoolbus.app.models.Chat;
import com.schoolbus.app.models.Student;
import com.schoolbus.app.services.ChatService;
import com.schoolbus.app.utils.Constants;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.StudentViewHolder> {
    private static final int EDIT_STUDENT_REQUEST_CODE = 100;
    private static final String TAG = "StudentAdapter";

    private Context context;
    private List<Student> studentList;
    private OnStudentDeleteListener deleteListener;

    public interface OnStudentDeleteListener {
        void onStudentDeleted(int remainingCount);
    }

    public StudentAdapter(Context context, List<Student> studentList) {
        this.context = context;
        this.studentList = studentList;

        // Try to set delete listener if context implements it
        if (context instanceof OnStudentDeleteListener) {
            this.deleteListener = (OnStudentDeleteListener) context;
        }
    }

    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_student, parent, false);
        return new StudentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        Student student = studentList.get(position);

        holder.textViewStudentName.setText(student.getName());
        holder.textViewStudentParent
                .setText("Parent: " + (student.getParentName() != null ? student.getParentName() : "Unknown"));
        holder.textViewStudentGrade.setText("Grade: " + student.getGrade());
        holder.textViewStudentBus.setText("Bus: " + (student.getBusId() != null ? student.getBusId() : "Not Assigned"));

        holder.buttonEditStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the edit activity
                Intent intent = new Intent(context, EditStudentActivity.class);
                intent.putExtra("STUDENT_ID", student.getId());
                intent.putExtra("STUDENT_NAME", student.getName());
                intent.putExtra("STUDENT_GRADE", student.getGrade());
                intent.putExtra("STUDENT_BUS_ID", student.getBusId());
                intent.putExtra("PARENT_ID", student.getParentId());

                // Use startActivityForResult if context is an Activity
                if (context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, EDIT_STUDENT_REQUEST_CODE);
                } else {
                    context.startActivity(intent);
                }
            }
        });

        holder.buttonViewAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the attendance history activity
                Intent intent = new Intent(context, AttendanceHistoryActivity.class);
                intent.putExtra(AttendanceHistoryActivity.EXTRA_STUDENT_ID, student.getId());
                intent.putExtra(AttendanceHistoryActivity.EXTRA_STUDENT_NAME, student.getName());
                context.startActivity(intent);
            }
        });

        holder.buttonChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start chat with parent
                if (student.getParentId() != null) {
                    // Show loading dialog
                    android.app.ProgressDialog progressDialog = new android.app.ProgressDialog(context);
                    progressDialog.setMessage("Loading chat...");
                    progressDialog.setCancelable(false);
                    progressDialog.show();

                    // Get or create chat with parent
                    DatabaseReference database = FirebaseDatabase.getInstance().getReference("");
                    ChatService chatService = new ChatService(database, context);
                    chatService.getOrCreateChatForChild(student.getId(), student.getName(),
                            new ChatService.ChatCallback() {
                                @Override
                                public void onSuccess(Chat chat) {
                                    progressDialog.dismiss();

                                    // Navigate to chat conversation
                                    Intent intent = new Intent(context, ChatConversationActivity.class);
                                    intent.putExtra(Constants.EXTRA_CHAT_ID, chat.getId());
                                    intent.putExtra(Constants.EXTRA_CHILD_NAME, student.getName());
                                    context.startActivity(intent);
                                }

                                @Override
                                public void onError(String error) {
                                    progressDialog.dismiss();
                                    Toast.makeText(context, "Error: " + error, Toast.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    Toast.makeText(context, "Student information not available", Toast.LENGTH_SHORT).show();
                }
            }
        });

        holder.buttonDeleteStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteConfirmationDialog(student);
            }
        });
    }

    private void showDeleteConfirmationDialog(Student student) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.delete_student)
                .setMessage(R.string.delete_student_confirmation)
                .setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteStudent(student);
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .show();
    }

    private void deleteStudent(Student student) {
        if (student.getParentId() == null || student.getId() == null) {
            Toast.makeText(context, "Invalid student data", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get reference to the student in the parent's children collection
        DatabaseReference studentRef = FirebaseDatabase.getInstance()
                .getReference("users")
                .child(student.getParentId())
                .child("children")
                .child(student.getId());

        // Delete the student
        studentRef.removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // Remove the student from the list and notify adapter
                        int position = studentList.indexOf(student);
                        if (position != -1) {
                            studentList.remove(position);
                            notifyItemRemoved(position);
                            notifyItemRangeChanged(position, studentList.size());
                        }

                        Toast.makeText(context, R.string.student_deleted_success, Toast.LENGTH_SHORT).show();

                        // Notify the listener
                        if (deleteListener != null) {
                            deleteListener.onStudentDeleted(studentList.size());
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.e(TAG, "Error deleting student: " + e.getMessage());
                        Toast.makeText(context,
                                context.getString(R.string.student_deleted_error, e.getMessage()),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    @Override
    public int getItemCount() {
        return studentList.size();
    }

    public static class StudentViewHolder extends RecyclerView.ViewHolder {
        ImageView imageViewStudent;
        TextView textViewStudentName;
        TextView textViewStudentParent;
        TextView textViewStudentGrade;
        TextView textViewStudentBus;
        Button buttonEditStudent;
        Button buttonViewAttendance;
        Button buttonChat;
        ImageButton buttonDeleteStudent;

        public StudentViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewStudent = itemView.findViewById(R.id.imageViewStudent);
            textViewStudentName = itemView.findViewById(R.id.textViewStudentName);
            textViewStudentParent = itemView.findViewById(R.id.textViewStudentParent);
            textViewStudentGrade = itemView.findViewById(R.id.textViewStudentGrade);
            textViewStudentBus = itemView.findViewById(R.id.textViewStudentBus);
            buttonEditStudent = itemView.findViewById(R.id.buttonEditStudent);
            buttonViewAttendance = itemView.findViewById(R.id.buttonViewAttendance);
            buttonChat = itemView.findViewById(R.id.buttonChat);
            buttonDeleteStudent = itemView.findViewById(R.id.buttonDeleteStudent);
        }
    }
}