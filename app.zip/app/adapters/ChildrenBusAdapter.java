package com.schoolbus.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolbus.app.R;
import com.schoolbus.app.models.Bus;

import java.util.List;

public class ChildrenBusAdapter extends RecyclerView.Adapter<ChildrenBusAdapter.BusViewHolder> {

    private final List<Bus> busList;
    private final OnBusClickListener listener;

    public interface OnBusClickListener {
        void onClick(Bus bus);
    }

    public ChildrenBusAdapter(List<Bus> busList, OnBusClickListener listener) {
        this.busList = busList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public BusViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_bus, parent, false);
        return new BusViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BusViewHolder holder, int position) {
        Bus bus = busList.get(position);
        holder.bind(bus, listener);
    }

    @Override
    public int getItemCount() {
        return busList.size();
    }

    static class BusViewHolder extends RecyclerView.ViewHolder {
        private final TextView busNumberText;
        private final TextView driverNameText;
        private final TextView routeNameText;
        private final TextView statusText;

        BusViewHolder(@NonNull View itemView) {
            super(itemView);
            busNumberText = itemView.findViewById(R.id.busNumberTextView);
            driverNameText = itemView.findViewById(R.id.driverNameTextView);
            routeNameText = itemView.findViewById(R.id.routeNameTextView);
            statusText = itemView.findViewById(R.id.statusTextView);
        }

        void bind(Bus bus, OnBusClickListener listener) {
            // Set bus number
            busNumberText.setText("Bus: " + bus.getBusNumber());

            // Set driver name if available
            if (bus.getDriverName() != null && !bus.getDriverName().isEmpty()) {
                driverNameText.setText("Driver: " + bus.getDriverName());
                driverNameText.setVisibility(View.VISIBLE);
            } else {
                driverNameText.setVisibility(View.GONE);
            }

            // Set route name if available
            if (bus.getRouteName() != null && !bus.getRouteName().isEmpty()) {
                routeNameText.setText("Route: " + bus.getRouteName());
                routeNameText.setVisibility(View.VISIBLE);
            } else {
                routeNameText.setVisibility(View.GONE);
            }

            // Set status
            statusText.setText("Status: " + bus.getStatus());

            // Set item click listener
            itemView.setOnClickListener(v -> listener.onClick(bus));
        }
    }
}