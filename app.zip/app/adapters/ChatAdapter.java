package com.schoolbus.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolbus.app.R;
import com.schoolbus.app.models.Chat;
import com.schoolbus.app.utils.PreferenceManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {
    private List<Chat> chatList;
    private OnChatClickListener listener;
    private SimpleDateFormat dateFormat;
    private PreferenceManager preferenceManager;

    public interface OnChatClickListener {
        void onChatClick(Chat chat);
    }

    public ChatAdapter(List<Chat> chatList, OnChatClickListener listener) {
        this.chatList = chatList;
        this.listener = listener;
        this.dateFormat = new SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault());
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_chat, parent, false);
        preferenceManager = new PreferenceManager(parent.getContext());
        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        Chat chat = chatList.get(position);
        String userType = preferenceManager.getUserType();
        String userId = preferenceManager.getUserId();

        // Set the title - always show child name
        holder.childNameTextView.setText(chat.getChildName());

        // Show additional information conditionally if available
        StringBuilder participantsInfo = new StringBuilder();

        switch (userType.toLowerCase()) {
            case "admin":
                // For admin, show child name and all available participants
                if (chat.getBusId() != null) {
                    holder.childNameTextView.setText(String.format("%s (Bus: %s)",
                            chat.getChildName(), chat.getBusId()));
                }

                if (chat.getDriverId() != null) {
                    participantsInfo.append("Driver: ").append(chat.getDriverId());
                }

                if (chat.getParentId() != null) {
                    if (participantsInfo.length() > 0) {
                        participantsInfo.append(" | ");
                    }
                    participantsInfo.append("Parent: ").append(chat.getParentId());
                }
                break;

            case "driver":
                // For driver, show child name and parent info if available
                if (chat.getParentId() != null) {
                    participantsInfo.append("Parent: ").append(chat.getParentId());
                }

                if (chat.getAdminId() != null) {
                    if (participantsInfo.length() > 0) {
                        participantsInfo.append(" | ");
                    }
                    participantsInfo.append("Admin: ").append(chat.getAdminId());
                }
                break;

            case "parent":
                // For parent, show child name and driver info if available
                if (chat.getDriverId() != null) {
                    participantsInfo.append("Driver: ").append(chat.getDriverId());
                }

                if (chat.getAdminId() != null) {
                    if (participantsInfo.length() > 0) {
                        participantsInfo.append(" | ");
                    }
                    participantsInfo.append("Admin: ").append(chat.getAdminId());
                }
                break;
        }

        if (participantsInfo.length() > 0) {
            holder.participantsTextView.setText(participantsInfo.toString());
            holder.participantsTextView.setVisibility(View.VISIBLE);
        } else {
            holder.participantsTextView.setVisibility(View.GONE);
        }

        // Get the last message if available
        if (chat.getMessages() != null && !chat.getMessages().isEmpty()) {
            Chat.Message lastMessage = chat.getMessages().values().iterator().next();
            holder.lastMessageTextView.setText(lastMessage.getText());
            holder.timestampTextView.setText(dateFormat.format(new Date(lastMessage.getTimestamp())));

            // Show unread count if there are unread messages
            int unreadCount = getUnreadCount(chat, userId);
            if (unreadCount > 0) {
                holder.unreadCountTextView.setVisibility(View.VISIBLE);
                holder.unreadCountTextView.setText(String.valueOf(unreadCount));
            } else {
                holder.unreadCountTextView.setVisibility(View.GONE);
            }
        } else {
            holder.lastMessageTextView.setText("No messages yet");
            holder.timestampTextView.setText("");
            holder.unreadCountTextView.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(v -> listener.onChatClick(chat));
    }

    private int getUnreadCount(Chat chat, String userId) {
        int count = 0;
        if (chat.getMessages() != null) {
            for (Chat.Message message : chat.getMessages().values()) {
                if (!message.getSenderId().equals(userId) &&
                        !"read".equals(message.getStatus())) {
                    count++;
                }
            }
        }
        return count;
    }

    @Override
    public int getItemCount() {
        return chatList.size();
    }

    static class ChatViewHolder extends RecyclerView.ViewHolder {
        TextView childNameTextView;
        TextView lastMessageTextView;
        TextView timestampTextView;
        TextView unreadCountTextView;
        TextView participantsTextView;

        ChatViewHolder(View itemView) {
            super(itemView);
            childNameTextView = itemView.findViewById(R.id.childNameTextView);
            lastMessageTextView = itemView.findViewById(R.id.lastMessageTextView);
            timestampTextView = itemView.findViewById(R.id.timestampTextView);
            unreadCountTextView = itemView.findViewById(R.id.unreadCountTextView);
            participantsTextView = itemView.findViewById(R.id.participantsTextView);
        }
    }
}