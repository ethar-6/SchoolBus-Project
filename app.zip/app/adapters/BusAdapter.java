package com.schoolbus.app.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolbus.app.R;
import com.schoolbus.app.activities.TrackBusActivity;
import com.schoolbus.app.models.Bus;

import java.util.List;

public class BusAdapter extends RecyclerView.Adapter<BusAdapter.BusViewHolder> {
    private Context context;
    private List<Bus> busList;
    private OnBusClickListener listener;

    public interface OnBusClickListener {
        void onBusClick(Bus bus);
    }

    public BusAdapter(Context context, List<Bus> busList) {
        this.context = context;
        this.busList = busList;
        this.listener = null;
    }

    public BusAdapter(Context context, List<Bus> busList, OnBusClickListener listener) {
        this.context = context;
        this.busList = busList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public BusViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_bus, parent, false);
        return new BusViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BusViewHolder holder, int position) {
        Bus bus = busList.get(position);

        holder.busNumberTextView.setText("Bus #" + bus.getBusNumber());
        holder.driverNameTextView
                .setText("Driver: " + (bus.getDriverName() != null ? bus.getDriverName() : "Not Assigned"));
        holder.routeNameTextView
                .setText("Route: " + (bus.getRouteName() != null ? bus.getRouteName() : "Not Assigned"));
        holder.statusTextView.setText("Status: " + (bus.getStatus() != null ? bus.getStatus() : "Unknown"));

        // Check if track button exists (might be null in some layouts)
        if (holder.buttonTrackBus != null) {
            holder.buttonTrackBus.setText("Track");
            holder.buttonTrackBus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onBusClick(bus);
                    } else {
                        // Start the track bus activity if no listener provided
                        try {
                            android.util.Log.d("BusAdapter", "Track button clicked for bus: " + 
                                    bus.getId() + ", number: " + bus.getBusNumber());
                            
                            if (context == null) {
                                android.util.Log.e("BusAdapter", "Context is null!");
                                return;
                            }
                            
                            if (bus.getId() == null || bus.getBusNumber() == null) {
                                android.util.Log.e("BusAdapter", "Missing bus ID or number!");
                                return;
                            }
                            
                            Intent intent = new Intent(context, TrackBusActivity.class);
                            intent.putExtra("BUS_ID", bus.getId());
                            intent.putExtra("BUS_NUMBER", bus.getBusNumber());
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            android.util.Log.d("BusAdapter", "Starting TrackBusActivity...");
                            context.startActivity(intent);
                            android.util.Log.d("BusAdapter", "TrackBusActivity should have been started");
                        } catch (Exception e) {
                            android.util.Log.e("BusAdapter", "Error starting TrackBusActivity: " + e.getMessage(), e);
                            if (context != null) {
                                android.widget.Toast.makeText(context, 
                                    "Error: " + e.getMessage(), android.widget.Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            });
        }

        // Make the whole item clickable if listener is provided
        if (listener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onBusClick(bus);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return busList.size();
    }

    public static class BusViewHolder extends RecyclerView.ViewHolder {
        TextView busNumberTextView;
        TextView driverNameTextView;
        TextView routeNameTextView;
        TextView statusTextView;
        Button buttonTrackBus;

        public BusViewHolder(@NonNull View itemView) {
            super(itemView);
            busNumberTextView = itemView.findViewById(R.id.busNumberTextView);
            driverNameTextView = itemView.findViewById(R.id.driverNameTextView);
            routeNameTextView = itemView.findViewById(R.id.routeNameTextView);
            statusTextView = itemView.findViewById(R.id.statusTextView);
            buttonTrackBus = itemView.findViewById(R.id.buttonTrackBus);
        }
    }
}