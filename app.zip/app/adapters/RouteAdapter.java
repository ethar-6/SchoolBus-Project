package com.schoolbus.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolbus.app.R;
import com.schoolbus.app.models.Route;

import java.util.List;

public class RouteAdapter extends RecyclerView.Adapter<RouteAdapter.RouteViewHolder> {

    private final Context context;
    private List<Route> routes;
    private final OnRouteClickListener listener;

    public interface OnRouteClickListener {
        void onRouteClick(Route route);
    }

    public RouteAdapter(Context context, List<Route> routes, OnRouteClickListener listener) {
        this.context = context;
        this.routes = routes;
        this.listener = listener;
    }

    public void updateRoutes(List<Route> routes) {
        this.routes = routes;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public RouteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_route, parent, false);
        return new RouteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RouteViewHolder holder, int position) {
        Route route = routes.get(position);

        // Show name with ID
        String routeTitle = route.getName();
        if (route.getId() != null && !route.getId().isEmpty()) {
            routeTitle += " (ID: " + route.getId() + ")";
        }
        holder.routeNameTextView.setText(routeTitle);

        // Set description or bus info
        StringBuilder busInfo = new StringBuilder();
        if (route.getBusId() != null && !route.getBusId().isEmpty()) {
            busInfo.append("Bus ID: ").append(route.getBusId());
        }

        if (route.getDescription() != null && !route.getDescription().isEmpty()) {
            if (busInfo.length() > 0) {
                busInfo.append(" • ");
            }
            busInfo.append(route.getDescription());
        }

        if (busInfo.length() > 0) {
            holder.routeDescriptionTextView.setText(busInfo.toString());
            holder.routeDescriptionTextView.setVisibility(View.VISIBLE);
        } else {
            holder.routeDescriptionTextView.setVisibility(View.GONE);
        }

        // Set schedule info
        StringBuilder scheduleInfo = new StringBuilder();
        if (route.getStartTime() != null && route.getEndTime() != null) {
            scheduleInfo.append(route.getStartTime()).append(" - ").append(route.getEndTime());
        }

        if (scheduleInfo.length() > 0) {
            holder.routeScheduleTextView.setText(scheduleInfo.toString());
            holder.routeScheduleTextView.setVisibility(View.VISIBLE);
        } else {
            holder.routeScheduleTextView.setVisibility(View.GONE);
        }

        // Set stops count and days
        int stopsCount = route.getStopsMap() != null ? route.getStopsMap().size() : 0;
        holder.routeStopsTextView.setText(stopsCount + " Stops");

        // Set days on the right side
        TextView daysTextView = holder.itemView.findViewById(R.id.daysTextView);
        if (route.getDays() != null && !route.getDays().isEmpty()) {
            daysTextView.setText(formatDays(route.getDays()));
            daysTextView.setVisibility(View.VISIBLE);
        } else {
            daysTextView.setVisibility(View.GONE);
        }

        // Set status label
        TextView statusTextView = holder.itemView.findViewById(R.id.statusTextView);
        boolean isActive = route.isActive();
        statusTextView.setText(isActive ? "Active" : "Inactive");
        statusTextView.setBackgroundResource(isActive ? R.drawable.bg_status_active : R.drawable.bg_status_inactive);

        // Set click listener
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onRouteClick(route);
            }
        });
    }

    private boolean isRouteActive(Route route) {
        return route.getBusId() != null &&
                route.getDays() != null &&
                !route.getDays().isEmpty() &&
                route.getStopsMap() != null &&
                !route.getStopsMap().isEmpty();
    }

    @Override
    public int getItemCount() {
        return routes != null ? routes.size() : 0;
    }

    private String formatDays(List<String> days) {
        if (days == null || days.isEmpty()) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < days.size(); i++) {
            if (i > 0) {
                result.append(", ");
            }
            // Abbreviate day names to first 3 letters
            String day = days.get(i);
            if (day.length() > 3) {
                result.append(day.substring(0, 3));
            } else {
                result.append(day);
            }
        }
        return result.toString();
    }

    static class RouteViewHolder extends RecyclerView.ViewHolder {
        TextView routeNameTextView;
        TextView routeDescriptionTextView;
        TextView routeScheduleTextView;
        TextView routeStopsTextView;

        public RouteViewHolder(@NonNull View itemView) {
            super(itemView);
            routeNameTextView = itemView.findViewById(R.id.routeNameTextView);
            routeDescriptionTextView = itemView.findViewById(R.id.busNumberTextView);
            routeScheduleTextView = itemView.findViewById(R.id.timeTextView);
            routeStopsTextView = itemView.findViewById(R.id.stopsCountTextView);
        }
    }
}