package com.schoolbus.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.schoolbus.app.R;
import com.schoolbus.app.models.AttendanceNotification;
import com.schoolbus.app.utils.Constants;

import java.util.List;

public class AttendanceNotificationAdapter extends RecyclerView.Adapter<AttendanceNotificationAdapter.AttendanceViewHolder> {

    private Context context;
    private List<AttendanceNotification> attendanceList;
    private OnAttendanceNotificationClickListener listener;

    public interface OnAttendanceNotificationClickListener {
        void onAttendanceClick(AttendanceNotification notification);
    }

    public AttendanceNotificationAdapter(Context context, List<AttendanceNotification> attendanceList, OnAttendanceNotificationClickListener listener) {
        this.context = context;
        this.attendanceList = attendanceList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public AttendanceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_attendance_notification, parent, false);
        return new AttendanceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AttendanceViewHolder holder, int position) {
        AttendanceNotification notification = attendanceList.get(position);
        
        holder.textViewChildName.setText(notification.getChildName());
        holder.textViewDate.setText(notification.getDate());
        holder.textViewTime.setText(notification.getTime());
        
        // Set status with appropriate color
        if (Constants.ATTENDANCE_STATUS_PRESENT.equals(notification.getStatus())) {
            holder.textViewStatus.setText("Present on the bus");
            holder.textViewStatus.setTextColor(ContextCompat.getColor(context, android.R.color.holo_green_dark));
        } else {
            holder.textViewStatus.setText("Absent from the bus");
            holder.textViewStatus.setTextColor(ContextCompat.getColor(context, android.R.color.holo_red_dark));
        }
        
        // Set bus info
        holder.textViewBusInfo.setText("Bus #" + notification.getBusNumber());
        
        // Apply unread/read styling
        if (!notification.isRead()) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.colorUnreadNotification));
        } else {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context, android.R.color.white));
        }
        
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onAttendanceClick(notification);
            }
        });
    }

    @Override
    public int getItemCount() {
        return attendanceList.size();
    }

    public void updateAttendanceList(List<AttendanceNotification> newAttendanceList) {
        this.attendanceList = newAttendanceList;
        notifyDataSetChanged();
    }

    static class AttendanceViewHolder extends RecyclerView.ViewHolder {
        TextView textViewChildName;
        TextView textViewDate;
        TextView textViewStatus;
        TextView textViewBusInfo;
        TextView textViewTime;

        public AttendanceViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewChildName = itemView.findViewById(R.id.textViewChildName);
            textViewDate = itemView.findViewById(R.id.textViewDate);
            textViewStatus = itemView.findViewById(R.id.textViewStatus);
            textViewBusInfo = itemView.findViewById(R.id.textViewBusInfo);
            textViewTime = itemView.findViewById(R.id.textViewTime);
        }
    }
} 