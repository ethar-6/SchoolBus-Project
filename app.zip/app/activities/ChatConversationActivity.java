package com.schoolbus.app.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.SchoolBusApplication;
import com.schoolbus.app.adapters.MessageAdapter;
import com.schoolbus.app.models.Chat;
import com.schoolbus.app.services.ChatService;
import com.schoolbus.app.utils.Constants;
import com.schoolbus.app.utils.PreferenceManager;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.User;
import com.schoolbus.app.models.Bus;

import java.util.ArrayList;
import java.util.List;

public class ChatConversationActivity extends AppCompatActivity {
    private RecyclerView messagesRecyclerView;
    private EditText messageInput;
    private ImageButton sendButton;
    private ChatService chatService;
    private PreferenceManager preferenceManager;
    private String chatId;
    private String childId;
    private String childName;
    private MessageAdapter messageAdapter;
    private List<Chat.Message> messageList;
    private FirebaseManager firebaseManager;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_conversation);

        // Initialize Firebase and Preferences
        firebaseManager = FirebaseManager.getInstance();
        preferenceManager = PreferenceManager.getInstance(this);
        chatService = new ChatService(firebaseManager.getDatabaseReference(""), this);

        // Get chat ID and child info from intent
        chatId = getIntent().getStringExtra(Constants.EXTRA_CHAT_ID);
        childId = getIntent().getStringExtra(Constants.EXTRA_CHILD_ID);
        childName = getIntent().getStringExtra(Constants.EXTRA_CHILD_NAME);

        android.util.Log.d("ChatConversationActivity", "Initial chatId: " + chatId);
        android.util.Log.d("ChatConversationActivity", "Initial childId: " + childId);
        android.util.Log.d("ChatConversationActivity", "Initial childName: " + childName);
        android.util.Log.d("ChatConversationActivity", "User type: " + preferenceManager.getUserType());
        android.util.Log.d("ChatConversationActivity", "User ID: " + preferenceManager.getUserId());

        // Initialize views
        initViews();

        // Set up toolbar
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(childName != null ? childName : "Chat");
        }

        // Set up RecyclerView
        setupRecyclerView();

        // Set up click listeners
        setupClickListeners();

        // Load or create chat
        if (chatId != null) {
            android.util.Log.d("ChatConversationActivity", "Loading existing chat with ID: " + chatId);
            loadChat();
        } else if (childId != null && childName != null) {
            android.util.Log.d("ChatConversationActivity",
                    "Creating new chat for child: " + childId + " (" + childName + ")");
            createOrLoadChat();
        } else {
            android.util.Log.e("ChatConversationActivity", "Error: Both chatId and childId are null");
            showToast(getString(R.string.error_chat_not_initialized));
            finish();
        }
    }

    private void initViews() {
        // Initialize RecyclerView
        messagesRecyclerView = findViewById(R.id.messagesRecyclerView);
        messagesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        messagesRecyclerView.setHasFixedSize(true);

        // Initialize message input
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);

        // Initialize toolbar
        toolbar = findViewById(R.id.toolbar);
    }

    private void setupRecyclerView() {
        // Initialize message list
        messageList = new ArrayList<>();
        messageAdapter = new MessageAdapter(messageList, preferenceManager.getUserId());
        messagesRecyclerView.setAdapter(messageAdapter);
    }

    private void setupClickListeners() {
        // Set up send button click listener
        sendButton.setOnClickListener(v -> sendMessage());
    }

    private void loadChat() {
        android.util.Log.d("ChatConversationActivity", "Loading chat with ID: " + chatId);

        // Special handling for admin users
        String userType = preferenceManager.getUserType();
        String userId = preferenceManager.getUserId();

        if ("admin".equals(userType)) {
            android.util.Log.d("ChatConversationActivity", "Admin user detected, updating chat with admin ID");
            // Update the chat with admin information first
            chatService.updateChatWithAdminUser(chatId, userId, new ChatService.ChatCallback() {
                @Override
                public void onSuccess(Chat chat) {
                    android.util.Log.d("ChatConversationActivity", "Chat updated with admin ID successfully");
                    displayChat(chat);
                }

                @Override
                public void onError(String error) {
                    android.util.Log.e("ChatConversationActivity", "Error updating chat with admin ID: " + error);
                    Toast.makeText(ChatConversationActivity.this, error, Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            // Regular user flow
            chatService.getChat(chatId, new ChatService.ChatCallback() {
                @Override
                public void onSuccess(Chat chat) {
                    android.util.Log.d("ChatConversationActivity", "Chat loaded successfully: " + chat.getId());
                    displayChat(chat);
                }

                @Override
                public void onError(String error) {
                    Toast.makeText(ChatConversationActivity.this, error, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    // Display chat UI and messages
    private void displayChat(Chat chat) {
        // Update toolbar subtitle with available participant information
        String userType = preferenceManager.getUserType();
        StringBuilder subtitle = new StringBuilder();

        switch (userType.toLowerCase()) {
            case "admin":
                if (chat.getDriverId() != null) {
                    subtitle.append("Driver: ").append(chat.getDriverId());
                }
                if (chat.getParentId() != null) {
                    if (subtitle.length() > 0) {
                        subtitle.append(" | ");
                    }
                    subtitle.append("Parent: ").append(chat.getParentId());
                }
                break;
            case "driver":
                if (chat.getParentId() != null) {
                    subtitle.append("Parent: ").append(chat.getParentId());
                }
                if (chat.getAdminId() != null) {
                    if (subtitle.length() > 0) {
                        subtitle.append(" | ");
                    }
                    subtitle.append("Admin: ").append(chat.getAdminId());
                }
                break;
            case "parent":
                if (chat.getDriverId() != null) {
                    subtitle.append("Driver: ").append(chat.getDriverId());
                }
                if (chat.getAdminId() != null) {
                    if (subtitle.length() > 0) {
                        subtitle.append(" | ");
                    }
                    subtitle.append("Admin: ").append(chat.getAdminId());
                }
                break;
        }

        if (getSupportActionBar() != null) {
            if (subtitle.length() > 0) {
                getSupportActionBar().setSubtitle(subtitle.toString());
            }
        }

        // Load messages
        messageList.clear();
        if (chat.getMessages() != null) {
            messageList.addAll(chat.getMessages().values());
        }
        messageAdapter.notifyDataSetChanged();
        messagesRecyclerView.scrollToPosition(messageList.size() - 1);
    }

    private void sendMessage() {
        android.util.Log.d("ChatConversationActivity", "Attempting to send message with chatId: " + chatId);

        if (chatId == null) {
            android.util.Log.e("ChatConversationActivity", "Error: chatId is null");
            showToast(getString(R.string.error_chat_not_initialized));
            return;
        }

        String messageText = messageInput.getText().toString().trim();
        if (TextUtils.isEmpty(messageText)) {
            return;
        }

        String userId = preferenceManager.getUserId();
        String userName = preferenceManager.getUserName();

        android.util.Log.d("ChatConversationActivity", "Sending message as user: " + userId + " (" + userName + ")");

        chatService.sendMessage(chatId, userId, userName, messageText, new ChatService.MessageCallback() {
            @Override
            public void onSuccess(Chat.Message message) {
                android.util.Log.d("ChatConversationActivity", "Message sent successfully");
                messageInput.setText("");
                messageList.add(message);
                messageAdapter.notifyItemInserted(messageList.size() - 1);
                messagesRecyclerView.scrollToPosition(messageList.size() - 1);
            }

            @Override
            public void onError(String error) {
                android.util.Log.e("ChatConversationActivity", "Error sending message: " + error);
                Toast.makeText(ChatConversationActivity.this, error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void createOrLoadChat() {
        String userId = preferenceManager.getUserId();
        String userType = preferenceManager.getUserType();

        if (userId == null || userId.isEmpty()) {
            showToast(getString(R.string.error_user_not_found));
            finish();
            return;
        }

        if (childId == null) {
            android.util.Log.e("ChatConversationActivity", "Child ID is null, can't create chat");
            showToast("Error: Missing child ID");
            finish();
            return;
        }

        android.util.Log.d("ChatConversationActivity",
                "Creating or loading chat for child " + childId + " as user " + userId + " (" + userType + ")");

        // Create a predictable chat ID based on the child ID
        String generatedChatId = childId + "_chat";
        android.util.Log.d("ChatConversationActivity", "Using generated chat ID: " + generatedChatId);

        // First check if a chat with this ID already exists
        chatService.getChat(generatedChatId, new ChatService.ChatCallback() {
            @Override
            public void onSuccess(Chat existingChat) {
                // Chat already exists
                android.util.Log.d("ChatConversationActivity", "Found existing chat with ID: " + generatedChatId);
                chatId = generatedChatId;
                displayChat(existingChat);
            }

            @Override
            public void onError(String error) {
                // Chat doesn't exist, create a new one
                android.util.Log.d("ChatConversationActivity",
                        "Chat not found, creating new chat for child: " + childId);

                // Create a new chat for this child
                chatService.createSimpleChat(childId, childName, new ChatService.ChatCallback() {
                    @Override
                    public void onSuccess(Chat newChat) {
                        android.util.Log.d("ChatConversationActivity",
                                "Successfully created new chat with ID: " + newChat.getId());
                        chatId = newChat.getId();

                        // Update the chat with user info based on type
                        if (Constants.USER_TYPE_ADMIN.equals(userType)) {
                            updateChatWithAdminId(chatId, userId);
                        } else {
                            displayChat(newChat);
                        }
                    }

                    @Override
                    public void onError(String createError) {
                        android.util.Log.e("ChatConversationActivity", "Error creating chat: " + createError);
                        showToast("Error creating chat: " + createError);
                        finish();
                    }
                });
            }
        });
    }

    // Helper method to update chat with admin ID
    private void updateChatWithAdminId(String chatId, String adminId) {
        android.util.Log.d("ChatConversationActivity", "Updating chat " + chatId + " with admin ID: " + adminId);

        chatService.updateChatWithAdminUser(chatId, adminId, new ChatService.ChatCallback() {
            @Override
            public void onSuccess(Chat chat) {
                android.util.Log.d("ChatConversationActivity", "Successfully updated chat with admin ID");
                loadChat();
            }

            @Override
            public void onError(String error) {
                android.util.Log.e("ChatConversationActivity", "Failed to update chat with admin ID: " + error);
                // Continue loading chat anyway - the chat was created, we just couldn't update
                // it
                loadChat();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Shows a toast message
     * 
     * @param message The message to display
     */
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}