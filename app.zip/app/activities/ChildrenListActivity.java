package com.schoolbus.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.adapters.ChildrenAdapter;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.User;
import com.schoolbus.app.utils.PreferenceManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ChildrenListActivity extends BaseActivity {

    private RecyclerView childrenRecyclerView;
    private TextView emptyTextView;
    private FloatingActionButton addChildFab;
    private View progressBar;
    private SwipeRefreshLayout swipeRefreshLayout;
    private Toolbar toolbar;

    private ChildrenAdapter childrenAdapter;
    private FirebaseManager firebaseManager;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_children_list);

        // Initialize Firebase and Preferences
        firebaseManager = FirebaseManager.getInstance();
        preferenceManager = PreferenceManager.getInstance(this);

        // Initialize views
        initViews();

        // Set up toolbar
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.children);
        }

        // Set up RecyclerView
        setupRecyclerView();

        // Set up click listeners
        setupClickListeners();

        // Set up swipe refresh
        swipeRefreshLayout.setOnRefreshListener(this::loadChildren);
        swipeRefreshLayout.setColorSchemeResources(
                R.color.primary,
                R.color.primary_dark,
                R.color.accent);

        // Load children
        loadChildren();
    }

    private void initViews() {
        childrenRecyclerView = findViewById(R.id.childrenRecyclerView);
        emptyTextView = findViewById(R.id.emptyTextView);
        addChildFab = findViewById(R.id.addChildFab);
        progressBar = findViewById(R.id.progressBar);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        toolbar = findViewById(R.id.toolbar);
    }

    private void setupRecyclerView() {
        childrenAdapter = new ChildrenAdapter(new ArrayList<>(), this::onChildEditClick);
        childrenRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        childrenRecyclerView.setAdapter(childrenAdapter);
    }

    private void setupClickListeners() {
        addChildFab.setOnClickListener(v -> {
            Intent intent = new Intent(this, ChildFormActivity.class);
            startActivity(intent);
        });
    }

    private void loadChildren() {
        String userId = preferenceManager.getUserId();
        if (userId == null || userId.isEmpty()) {
            showToast(getString(R.string.error_user_not_found));
            finish();
            return;
        }

        if (!swipeRefreshLayout.isRefreshing()) {
            progressBar.setVisibility(View.VISIBLE);
        }

        firebaseManager.getUserProfile(userId, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    User user = dataSnapshot.getValue(User.class);
                    if (user != null && user.getChildren() != null) {
                        List<User.Child> children = new ArrayList<>();
                        Map<String, User.Child> childrenMap = user.getChildren();

                        // Ensure each child has its ID set from the map key
                        for (Map.Entry<String, User.Child> entry : childrenMap.entrySet()) {
                            User.Child child = entry.getValue();
                            child.setId(entry.getKey()); // Set the ID from the map key
                            children.add(child);
                        }

                        childrenAdapter.updateChildren(children);
                        updateEmptyState(children.isEmpty());
                    } else {
                        updateEmptyState(true);
                    }
                } else {
                    updateEmptyState(true);
                }
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);
                showToast(getString(R.string.error_loading_children));
            }
        });
    }

    private void updateEmptyState(boolean isEmpty) {
        emptyTextView.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        childrenRecyclerView.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
    }

    private void onChildEditClick(User.Child child) {
        Intent intent = new Intent(this, ChildFormActivity.class);
        intent.putExtra("child_id", child.getId());
        intent.putExtra("child_name", child.getName());
        intent.putExtra("child_grade", child.getGrade());
        intent.putExtra("child_bus_id", child.getBusId());
        startActivity(intent);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}