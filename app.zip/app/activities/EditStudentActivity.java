package com.schoolbus.app.activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.models.Bus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EditStudentActivity extends AppCompatActivity {
    private static final String TAG = "EditStudentActivity";

    private TextView textViewStudentName;
    private TextInputLayout gradeLayout;
    private TextInputEditText gradeEditText;
    private TextInputLayout busLayout;
    private AutoCompleteTextView busEditText;
    private Button saveButton;
    private ProgressBar progressBar;

    private String studentId;
    private String studentName;
    private String parentId;
    private String currentGrade;
    private String currentBusId;
    private List<Bus> busList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_student);

        // Initialize views
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        textViewStudentName = findViewById(R.id.textViewStudentName);
        gradeLayout = findViewById(R.id.gradeLayout);
        gradeEditText = findViewById(R.id.gradeEditText);
        busLayout = findViewById(R.id.busLayout);
        busEditText = findViewById(R.id.busEditText);
        saveButton = findViewById(R.id.saveButton);
        progressBar = findViewById(R.id.progressBar);

        // Get data from intent
        studentId = getIntent().getStringExtra("STUDENT_ID");
        studentName = getIntent().getStringExtra("STUDENT_NAME");
        currentGrade = getIntent().getStringExtra("STUDENT_GRADE");
        currentBusId = getIntent().getStringExtra("STUDENT_BUS_ID");
        parentId = getIntent().getStringExtra("PARENT_ID");

        // Set student name
        textViewStudentName.setText(studentName);

        // Set current grade
        if (currentGrade != null) {
            gradeEditText.setText(currentGrade);
        }

        // Load buses for dropdown
        loadBuses();

        // Set save button click listener
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveChanges();
            }
        });
    }

    private void loadBuses() {
        progressBar.setVisibility(View.VISIBLE);

        DatabaseReference busesRef = FirebaseDatabase.getInstance().getReference("buses");
        busesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                busList.clear();

                for (DataSnapshot busSnapshot : dataSnapshot.getChildren()) {
                    Bus bus = busSnapshot.getValue(Bus.class);
                    if (bus != null) {
                        bus.setId(busSnapshot.getKey());
                        busList.add(bus);
                    }
                }

                // Create adapter for bus dropdown
                ArrayAdapter<Bus> busAdapter = new ArrayAdapter<>(
                        EditStudentActivity.this,
                        android.R.layout.simple_dropdown_item_1line,
                        busList);
                busEditText.setAdapter(busAdapter);

                // Set current bus if available
                if (currentBusId != null) {
                    for (Bus bus : busList) {
                        if (bus.getId().equals(currentBusId)) {
                            busEditText.setText(bus.toString(), false);
                            break;
                        }
                    }
                }

                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Error loading buses: " + databaseError.getMessage());
                Toast.makeText(EditStudentActivity.this, "Error loading buses", Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    private void saveChanges() {
        // Validate inputs
        String grade = gradeEditText.getText().toString().trim();
        if (grade.isEmpty()) {
            gradeLayout.setError("Grade is required");
            return;
        }

        // Get selected bus
        Bus selectedBus = null;
        if (busEditText.getAdapter() != null && busEditText.getText() != null) {
            String selectedText = busEditText.getText().toString();
            ArrayAdapter<Bus> adapter = (ArrayAdapter<Bus>) busEditText.getAdapter();
            for (int i = 0; i < adapter.getCount(); i++) {
                Bus bus = adapter.getItem(i);
                if (bus != null && bus.toString().equals(selectedText)) {
                    selectedBus = bus;
                    break;
                }
            }
        }

        if (selectedBus == null) {
            busLayout.setError("Please select a bus");
            return;
        }

        // Show progress
        progressBar.setVisibility(View.VISIBLE);
        saveButton.setEnabled(false);

        // Prepare updates
        Map<String, Object> updates = new HashMap<>();
        updates.put("grade", grade);
        updates.put("busId", selectedBus.getId());

        // Update database
        DatabaseReference studentRef = FirebaseDatabase.getInstance()
                .getReference("users")
                .child(parentId)
                .child("children")
                .child(studentId);

        studentRef.updateChildren(updates)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        progressBar.setVisibility(View.GONE);
                        saveButton.setEnabled(true);

                        if (task.isSuccessful()) {
                            Toast.makeText(EditStudentActivity.this, "Student updated successfully", Toast.LENGTH_SHORT)
                                    .show();
                            // Set result to indicate successful edit
                            setResult(RESULT_OK);
                            finish();
                        } else {
                            Toast.makeText(EditStudentActivity.this, "Failed to update student", Toast.LENGTH_SHORT)
                                    .show();
                        }
                    }
                });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}