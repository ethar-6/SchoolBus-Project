package com.schoolbus.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.adapters.BusAdapter;
import com.schoolbus.app.models.Bus;

import java.util.ArrayList;
import java.util.List;

public class AllBusesActivity extends AppCompatActivity implements BusAdapter.OnBusClickListener {
    private static final String TAG = "AllBusesActivity";

    private RecyclerView recyclerView;
    private TextView emptyView;
    private ProgressBar progressBar;
    private BusAdapter adapter;
    private List<Bus> busList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_buses);

        // Initialize views
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        recyclerView = findViewById(R.id.recyclerViewBuses);
        emptyView = findViewById(R.id.emptyView);
        progressBar = findViewById(R.id.progressBar);

        // Set up FloatingActionButton
        FloatingActionButton fabAddBus = findViewById(R.id.fabAddBus);
        fabAddBus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AllBusesActivity.this, AddBusActivity.class);
                startActivity(intent);
            }
        });

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        busList = new ArrayList<>();
        adapter = new BusAdapter(this, busList, this);
        recyclerView.setAdapter(adapter);

        // Fetch all buses from Firebase
        fetchAllBuses();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data when returning to this activity
        fetchAllBuses();
    }

    private void fetchAllBuses() {
        progressBar.setVisibility(View.VISIBLE);

        DatabaseReference busesRef = FirebaseDatabase.getInstance().getReference("buses");
        busesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                busList.clear();
                Log.d(TAG, "Retrieved buses data: " + dataSnapshot.toString());

                for (DataSnapshot busSnapshot : dataSnapshot.getChildren()) {
                    Bus bus = busSnapshot.getValue(Bus.class);
                    if (bus != null) {
                        bus.setId(busSnapshot.getKey());
                        busList.add(bus);
                        Log.d(TAG, "Added bus: " + bus.getBusNumber());
                    }
                }

                adapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);

                // Show empty view if no buses found
                if (busList.isEmpty()) {
                    Log.d(TAG, "No buses found");
                    recyclerView.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    Log.d(TAG, "Found " + busList.size() + " buses");
                    recyclerView.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Error fetching buses: " + databaseError.getMessage());
                progressBar.setVisibility(View.GONE);
                recyclerView.setVisibility(View.GONE);
                emptyView.setVisibility(View.VISIBLE);
                emptyView.setText("Error loading buses. Please try again.");
            }
        });
    }

    @Override
    public void onBusClick(Bus bus) {
        // Navigate to bus details activity
        Intent intent = new Intent(this, BusDetailsActivity.class);
        intent.putExtra("BUS_ID", bus.getId());
        startActivity(intent);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}