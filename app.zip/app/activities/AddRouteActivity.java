package com.schoolbus.app.activities;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.models.Bus;
import com.schoolbus.app.models.Route;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class AddRouteActivity extends AppCompatActivity {
    private static final String TAG = "AddRouteActivity";

    // UI components
    private SwitchMaterial activeSwitch;
    private TextInputEditText routeNameInput, descriptionInput;
    private AutoCompleteTextView busDropdown;
    private TextInputEditText startTimeInput, endTimeInput;
    private CheckBox mondayCheckbox, tuesdayCheckbox, wednesdayCheckbox,
            thursdayCheckbox, fridayCheckbox, saturdayCheckbox, sundayCheckbox;
    private Button saveButton, cancelButton;
    private ProgressBar progressBar;

    // Data
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
    private List<Bus> busList = new ArrayList<>();
    private Map<String, Bus> busMap = new HashMap<>();
    private String selectedBusId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_route);

        // Initialize views
        initializeViews();

        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // Set click listeners
        setClickListeners();

        // Fetch buses for dropdown
        fetchBuses();
    }

    private void initializeViews() {
        routeNameInput = findViewById(R.id.routeNameInput);
        descriptionInput = findViewById(R.id.descriptionInput);
        busDropdown = findViewById(R.id.busDropdown);
        startTimeInput = findViewById(R.id.startTimeInput);
        endTimeInput = findViewById(R.id.endTimeInput);

        // Initialize active switch
        activeSwitch = findViewById(R.id.activeSwitch);
        if (activeSwitch != null) {
            activeSwitch.setChecked(true); // Default to active
            activeSwitch.setText("Active  ");
            activeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
                activeSwitch.setText(isChecked ? "Active  " : "Inactive  ");
            });
        }

        // Checkboxes for days
        mondayCheckbox = findViewById(R.id.mondayCheckbox);
        tuesdayCheckbox = findViewById(R.id.tuesdayCheckbox);
        wednesdayCheckbox = findViewById(R.id.wednesdayCheckbox);
        thursdayCheckbox = findViewById(R.id.thursdayCheckbox);
        fridayCheckbox = findViewById(R.id.fridayCheckbox);
        saturdayCheckbox = findViewById(R.id.saturdayCheckbox);
        sundayCheckbox = findViewById(R.id.sundayCheckbox);

        // Default to weekdays checked
        mondayCheckbox.setChecked(true);
        tuesdayCheckbox.setChecked(true);
        wednesdayCheckbox.setChecked(true);
        thursdayCheckbox.setChecked(true);
        fridayCheckbox.setChecked(true);

        // Other views
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setClickListeners() {
        // Time picker dialogs
        startTimeInput.setOnClickListener(v -> showTimePickerDialog(startTimeInput));
        endTimeInput.setOnClickListener(v -> showTimePickerDialog(endTimeInput));

        // Save button
        saveButton.setOnClickListener(v -> createNewRoute());

        // Cancel button
        cancelButton.setOnClickListener(v -> finish());

        // Bus dropdown selection
        busDropdown.setOnItemClickListener((parent, view, position, id) -> {
            String selection = parent.getItemAtPosition(position).toString();
            for (Map.Entry<String, Bus> entry : busMap.entrySet()) {
                Bus bus = entry.getValue();
                String displayText = getBusDisplayText(bus);
                if (displayText.equals(selection)) {
                    selectedBusId = entry.getKey();
                    break;
                }
            }
        });
    }

    private void fetchBuses() {
        progressBar.setVisibility(View.VISIBLE);
        DatabaseReference busesRef = FirebaseDatabase.getInstance().getReference("buses");

        busesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                busList.clear();
                busMap.clear();

                // Add default "No bus" option
                List<String> busItems = new ArrayList<>();
                busItems.add("No bus selected");

                for (DataSnapshot busSnapshot : snapshot.getChildren()) {
                    Bus bus = busSnapshot.getValue(Bus.class);
                    if (bus != null) {
                        String busId = busSnapshot.getKey();
                        bus.setId(busId);
                        busList.add(bus);
                        busMap.put(busId, bus);

                        // Create display text
                        String displayText = getBusDisplayText(bus);
                        busItems.add(displayText);
                    }
                }

                // Create and set adapter
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        AddRouteActivity.this,
                        android.R.layout.simple_dropdown_item_1line,
                        busItems);

                busDropdown.setAdapter(adapter);
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
                showError("Error loading buses: " + error.getMessage());
            }
        });
    }

    private String getBusDisplayText(Bus bus) {
        String driverInfo = (bus.getDriverName() != null && !bus.getDriverName().isEmpty())
                ? " - " + bus.getDriverName()
                : " - No driver assigned";
        return bus.getBusNumber() + driverInfo;
    }

    private void createNewRoute() {
        if (!validateForm()) {
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        try {
            // Create a new route object
            String routeId = UUID.randomUUID().toString();
            Route newRoute = new Route();
            newRoute.setId(routeId);
            newRoute.setName(routeNameInput.getText().toString().trim());
            newRoute.setDescription(descriptionInput.getText().toString().trim());
            newRoute.setBusId(selectedBusId);
            newRoute.setStartTime(startTimeInput.getText().toString().trim());
            newRoute.setEndTime(endTimeInput.getText().toString().trim());
            newRoute.setActive(activeSwitch.isChecked());

            // Set days
            List<String> days = new ArrayList<>();
            if (mondayCheckbox.isChecked())
                days.add("Monday");
            if (tuesdayCheckbox.isChecked())
                days.add("Tuesday");
            if (wednesdayCheckbox.isChecked())
                days.add("Wednesday");
            if (thursdayCheckbox.isChecked())
                days.add("Thursday");
            if (fridayCheckbox.isChecked())
                days.add("Friday");
            if (saturdayCheckbox.isChecked())
                days.add("Saturday");
            if (sundayCheckbox.isChecked())
                days.add("Sunday");
            newRoute.setDays(days);

            // Init empty stops map
            newRoute.setStops(new HashMap<>());

            // Create a map for Firebase
            Map<String, Object> routeValues = new HashMap<>();
            routeValues.put("name", newRoute.getName());
            routeValues.put("description", newRoute.getDescription());
            routeValues.put("busId", newRoute.getBusId());
            routeValues.put("startTime", newRoute.getStartTime());
            routeValues.put("endTime", newRoute.getEndTime());
            routeValues.put("days", newRoute.getDays());
            routeValues.put("stops", newRoute.getStopsMap());
            routeValues.put("active", newRoute.isActive());

            // Save to Firebase
            DatabaseReference routesRef = FirebaseDatabase.getInstance().getReference("routes");
            routesRef.child(routeId).setValue(routeValues)
                    .addOnSuccessListener(aVoid -> {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(AddRouteActivity.this, "Route created successfully", Toast.LENGTH_SHORT).show();

                        // If a bus ID was provided, update the bus with this route info
                        if (!selectedBusId.isEmpty() && !selectedBusId.equals("No bus selected")) {
                            updateBusWithRouteInfo(newRoute);
                        }

                        finish();
                    })
                    .addOnFailureListener(e -> {
                        progressBar.setVisibility(View.GONE);
                        showError("Failed to create route: " + e.getMessage());
                    });

        } catch (Exception e) {
            progressBar.setVisibility(View.GONE);
            Log.e(TAG, "Error creating route: " + e.getMessage());
            showError("Error creating route: " + e.getMessage());
        }
    }

    private void updateBusWithRouteInfo(Route route) {
        String busId = route.getBusId();
        if (busId == null || busId.isEmpty()) {
            return; // No bus to update
        }

        DatabaseReference busRef = FirebaseDatabase.getInstance().getReference("buses").child(busId);
        Map<String, Object> updates = new HashMap<>();
        updates.put("routeId", route.getId());
        updates.put("routeName", route.getName());

        busRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Bus updated with new route information");
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Failed to update bus with route info: " + e.getMessage());
                });
    }

    private boolean validateForm() {
        boolean valid = true;

        String routeName = routeNameInput.getText().toString().trim();
        if (routeName.isEmpty()) {
            routeNameInput.setError("Route name is required");
            valid = false;
        }

        String startTime = startTimeInput.getText().toString().trim();
        if (startTime.isEmpty()) {
            startTimeInput.setError("Start time is required");
            valid = false;
        }

        String endTime = endTimeInput.getText().toString().trim();
        if (endTime.isEmpty()) {
            endTimeInput.setError("End time is required");
            valid = false;
        }

        boolean anyDaySelected = mondayCheckbox.isChecked() || tuesdayCheckbox.isChecked() ||
                wednesdayCheckbox.isChecked() || thursdayCheckbox.isChecked() ||
                fridayCheckbox.isChecked() || saturdayCheckbox.isChecked() ||
                sundayCheckbox.isChecked();

        if (!anyDaySelected) {
            Toast.makeText(this, "At least one day must be selected", Toast.LENGTH_SHORT).show();
            valid = false;
        }

        return valid;
    }

    private void showTimePickerDialog(TextInputEditText timeInput) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, hourOfDay, selectedMinute) -> {
                    calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    calendar.set(Calendar.MINUTE, selectedMinute);
                    timeInput.setText(timeFormat.format(calendar.getTime()));
                },
                hour,
                minute,
                false);

        timePickerDialog.show();
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}