package com.schoolbus.app.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ExpandableListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.schoolbus.app.R;
import com.schoolbus.app.adapters.HelpExpandableListAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HelpActivity extends AppCompatActivity {

    private ExpandableListView expandableListView;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        // Initialize views
        initViews();

        // Setup toolbar
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setTitle(R.string.help);
        }

        // Setup expandable list
        setupExpandableList();
    }

    private void initViews() {
        toolbar = findViewById(R.id.toolbar);
        expandableListView = findViewById(R.id.expandableListView);
    }

    private void setupExpandableList() {
        // Prepare help content
        List<String> listDataHeader = new ArrayList<>();
        Map<String, List<String>> listDataChild = new HashMap<>();

        // Add headers and their content
        addParentSection(listDataHeader, listDataChild);
        addDriverSection(listDataHeader, listDataChild);
        addTrackingSection(listDataHeader, listDataChild);
        addNotificationsSection(listDataHeader, listDataChild);
        addChildrenSection(listDataHeader, listDataChild);
        addGeneralSection(listDataHeader, listDataChild);

        // Set up adapter
        HelpExpandableListAdapter adapter = new HelpExpandableListAdapter(this, listDataHeader, listDataChild);
        expandableListView.setAdapter(adapter);

        // Expand the first group by default
        expandableListView.expandGroup(0);
    }

    private void addParentSection(List<String> listDataHeader, Map<String, List<String>> listDataChild) {
        String header = "Parent Dashboard";
        List<String> childItems = new ArrayList<>();
        
        childItems.add("The Parent Dashboard provides a central hub for monitoring your child's school bus.");
        childItems.add("Track your child's bus in real-time using the tracking feature.");
        childItems.add("Receive important notifications about bus delays, route changes, or other important announcements.");
        childItems.add("View and manage your children's information and bus assignments.");
        
        listDataHeader.add(header);
        listDataChild.put(header, childItems);
    }

    private void addDriverSection(List<String> listDataHeader, Map<String, List<String>> listDataChild) {
        String header = "Driver Information";
        List<String> childItems = new ArrayList<>();
        
        childItems.add("You can view information about your child's bus driver in the bus details section.");
        childItems.add("Driver contact information is available for emergency situations.");
        childItems.add("Drivers are certified professionals who prioritize the safety of your children.");
        
        listDataHeader.add(header);
        listDataChild.put(header, childItems);
    }

    private void addTrackingSection(List<String> listDataHeader, Map<String, List<String>> listDataChild) {
        String header = "Bus Tracking";
        List<String> childItems = new ArrayList<>();
        
        childItems.add("Use the tracking feature to monitor your child's bus location in real-time.");
        childItems.add("The map shows the current position of the bus and its route.");
        childItems.add("You can estimate arrival times based on the bus's current location.");
        childItems.add("Tracking is available when the bus is in service and the driver has enabled location sharing.");
        
        listDataHeader.add(header);
        listDataChild.put(header, childItems);
    }

    private void addNotificationsSection(List<String> listDataHeader, Map<String, List<String>> listDataChild) {
        String header = "Notifications";
        List<String> childItems = new ArrayList<>();
        
        childItems.add("The app sends notifications about important events related to your child's school bus.");
        childItems.add("You'll be notified about delays, route changes, or emergency situations.");
        childItems.add("You can manage notification settings in your profile.");
        
        listDataHeader.add(header);
        listDataChild.put(header, childItems);
    }

    private void addChildrenSection(List<String> listDataHeader, Map<String, List<String>> listDataChild) {
        String header = "Managing Children";
        List<String> childItems = new ArrayList<>();
        
        childItems.add("Add your children to your account through the 'Children' section in your profile.");
        childItems.add("For each child, you can set their school, grade, and other relevant information.");
        childItems.add("You can view and update your child's bus assignment when needed.");
        
        listDataHeader.add(header);
        listDataChild.put(header, childItems);
    }

    private void addGeneralSection(List<String> listDataHeader, Map<String, List<String>> listDataChild) {
        String header = "General App Information";
        List<String> childItems = new ArrayList<>();
        
        childItems.add("This app is designed to improve communication between schools, bus services, and parents.");
        childItems.add("For technical support, please contact your school administrator.");
        childItems.add("The app requires an internet connection to provide real-time updates.");
        childItems.add("Your privacy is important to us. Location data is only used for bus tracking purposes.");
        
        listDataHeader.add(header);
        listDataChild.put(header, childItems);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
} 