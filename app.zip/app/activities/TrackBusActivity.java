package com.schoolbus.app.activities;

import android.content.ComponentName;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.models.Bus;
import com.schoolbus.app.models.Location;
import com.schoolbus.app.utils.Constants;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TrackBusActivity extends AppCompatActivity implements OnMapReadyCallback {
    private static final String TAG = "TrackBusActivity";

    private TextView textViewTitle;
    private TextView textViewBusNumber;
    private TextView textViewDriverName;
    private TextView textViewLastUpdate;
    private TextView textViewStatus;
    private ProgressBar progressBar;
    private ProgressBar loadingIndicator;
    private GoogleMap googleMap;

    private String busId;
    private String busNumber;
    private DatabaseReference busRef;
    private DatabaseReference locationRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Show a toast with calling activity info
        try {
            ComponentName callingActivity = getCallingActivity();
            String caller = callingActivity != null ? callingActivity.getClassName() : "Unknown";
            Toast.makeText(this, "Called by: " + caller, Toast.LENGTH_LONG).show();
            Log.d(TAG, "TrackBusActivity called by: " + caller);
        } catch (Exception e) {
            Log.e(TAG, "Error getting calling activity: " + e.getMessage());
        }
        
        setContentView(R.layout.activity_track_bus);

        // Get bus info from intent
        busId = getIntent().getStringExtra("BUS_ID");
        busNumber = getIntent().getStringExtra("BUS_NUMBER");

        Log.d(TAG, "onCreate: Starting tracking for bus ID: " + busId + ", bus number: " + busNumber);

        if (busId == null || busNumber == null) {
            Log.e(TAG, "onCreate: Missing bus information. busId=" + busId + ", busNumber=" + busNumber);
            Toast.makeText(this, "Error: Bus information not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize views
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        textViewTitle = findViewById(R.id.textViewTitle);
        textViewBusNumber = findViewById(R.id.textViewBusNumber);
        textViewDriverName = findViewById(R.id.textViewDriverName);
        textViewLastUpdate = findViewById(R.id.textViewLastUpdate);
        textViewStatus = findViewById(R.id.textViewStatus);
        progressBar = findViewById(R.id.progressBar);
        loadingIndicator = findViewById(R.id.loadingIndicator);

        // Set title and bus info
        textViewTitle.setText("Tracking Bus #" + busNumber);
        textViewBusNumber.setText("Bus #" + busNumber);

        // Initialize Firebase references
        busRef = FirebaseDatabase.getInstance().getReference("buses").child(busId);
        locationRef = FirebaseDatabase.getInstance().getReference("bus_locations").child(busId);
        
        Log.d(TAG, "onCreate: Initialized Firebase references for busId: " + busId);
        Log.d(TAG, "onCreate: bus_locations path: " + locationRef.toString());

        // Show progress until data is loaded
        progressBar.setVisibility(View.VISIBLE);
        loadingIndicator.setVisibility(View.VISIBLE);

        // Load bus details
        loadBusDetails();
        
        // Initialize map
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            Log.d(TAG, "onCreate: Found map fragment, initializing Google Maps");
            mapFragment.getMapAsync(this);
        } else {
            Log.e(TAG, "onCreate: Map fragment not found in layout");
            Toast.makeText(this, "Error: Map not available", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onMapReady(GoogleMap map) {
        Log.d(TAG, "onMapReady: Google Maps is initialized and ready");
        googleMap = map;
        
        // Load the last saved location
        loadBusLocation();
    }
    
    private void loadBusLocation() {
        Log.d(TAG, "loadBusLocation: Starting to load location for bus ID: " + busId);
        if (locationRef == null) {
            Log.e(TAG, "loadBusLocation: Location reference is null");
            textViewStatus.setText("Cannot track bus: location information not available");
            loadingIndicator.setVisibility(View.GONE);
            return;
        }
        Log.d(TAG, "loadBusLocation: Querying Firebase for bus location at path: " + locationRef.toString());
        locationRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d(TAG, "loadBusLocation: Received data snapshot exists=" + dataSnapshot.exists());
                Location location = dataSnapshot.getValue(Location.class);
                if (location != null) {
                    Log.d(TAG, "loadBusLocation: Found location data. Lat=" + location.getLatitude() 
                            + ", Lng=" + location.getLongitude() 
                            + ", Time=" + new Date(location.getTimestamp()));
                    updateBusLocationOnMap(location);
                    updateLastUpdateTime(location.getTimestamp());
                    textViewStatus.setText("Bus location displayed");
                    loadingIndicator.setVisibility(View.GONE);
                } else {
                    Log.d(TAG, "loadBusLocation: No location data found for bus. Trying driver location as fallback.");
                    // If we don't find location in the bus_locations node,
                    // check if the bus has an assigned driver and look up the driver's location
                    checkDriverLocation();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "loadBusLocation: Error getting location: " + databaseError.getMessage());
                textViewStatus.setText("Error getting location data");
                loadingIndicator.setVisibility(View.GONE);
            }
        });
    }
    
    private void checkDriverLocation() {
        Log.d(TAG, "checkDriverLocation: Looking for driver associated with bus ID: " + busId);
        
        // First, get the driver ID for this bus
        busRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d(TAG, "checkDriverLocation: Bus data snapshot exists=" + dataSnapshot.exists());
                
                Bus bus = dataSnapshot.getValue(Bus.class);
                if (bus != null && bus.getDriverId() != null && !bus.getDriverId().isEmpty()) {
                    String driverId = bus.getDriverId();
                    Log.d(TAG, "checkDriverLocation: Found driver ID: " + driverId + " for bus: " + busId);
                    
                    // Found a driver, check for their location
                    DatabaseReference driverLocationRef = FirebaseDatabase.getInstance()
                            .getReference("driver_locations")
                            .child(driverId);
                    
                    Log.d(TAG, "checkDriverLocation: Querying driver location at path: " + driverLocationRef.toString());
                    
                    driverLocationRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Log.d(TAG, "checkDriverLocation: Driver location data snapshot exists=" + dataSnapshot.exists());
                            
                            Location location = dataSnapshot.getValue(Location.class);
                            if (location != null) {
                                Log.d(TAG, "checkDriverLocation: Found driver location. Lat=" + location.getLatitude() 
                                        + ", Lng=" + location.getLongitude() 
                                        + ", Time=" + new Date(location.getTimestamp()));
                                
                                updateBusLocationOnMap(location);
                                updateLastUpdateTime(location.getTimestamp());
                                textViewStatus.setText("Bus location found via driver");
                                loadingIndicator.setVisibility(View.GONE);
                            } else {
                                Log.e(TAG, "checkDriverLocation: No location data found for driver: " + driverId);
                                textViewStatus.setText("No location data available");
                                loadingIndicator.setVisibility(View.GONE);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Log.e(TAG, "checkDriverLocation: Error getting driver location: " + databaseError.getMessage());
                            textViewStatus.setText("Error getting location data");
                            loadingIndicator.setVisibility(View.GONE);
                        }
                    });
                } else {
                    Log.e(TAG, "checkDriverLocation: No driver assigned to bus ID: " + busId);
                    textViewStatus.setText("No driver assigned to this bus");
                    loadingIndicator.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "checkDriverLocation: Error getting bus data: " + databaseError.getMessage());
                textViewStatus.setText("Error getting bus data");
                loadingIndicator.setVisibility(View.GONE);
            }
        });
    }
    
    private void updateBusLocationOnMap(Location location) {
        if (googleMap == null || location == null) {
            Log.e(TAG, "updateBusLocationOnMap: Google Map or location is null");
            return;
        }
        
        Log.d(TAG, "updateBusLocationOnMap: Updating bus location on map: Lat=" + location.getLatitude() + ", Lng=" + location.getLongitude());
        
        LatLng busLocation = new LatLng(location.getLatitude(), location.getLongitude());
        
        // Clear any existing markers
        googleMap.clear();
        
        // Add marker for the bus
        googleMap.addMarker(new MarkerOptions()
                .position(busLocation)
                .title("Bus #" + busNumber));
        
        // Set proper zoom level for better visibility (higher value = more zoomed in)
        float zoomLevel = 15.0f; // Adjust this value as needed (15-18 is good for street-level detail)
        
        // Move camera to the bus location with appropriate zoom
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(busLocation, zoomLevel));
        
        // Enable zoom controls for better user experience
        googleMap.getUiSettings().setZoomControlsEnabled(true);
        googleMap.getUiSettings().setZoomGesturesEnabled(true);
        googleMap.getUiSettings().setCompassEnabled(true);
        
        Log.d(TAG, "updateBusLocationOnMap: Map updated with zoom level: " + zoomLevel);
    }

    private void loadBusDetails() {
        Log.d(TAG, "loadBusDetails: Loading bus details for bus ID: " + busId);
        
        busRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d(TAG, "loadBusDetails: Bus data snapshot exists=" + dataSnapshot.exists());
                
                Bus bus = dataSnapshot.getValue(Bus.class);
                if (bus != null) {
                    String driverName = bus.getDriverName() != null ? bus.getDriverName() : "Not Assigned";
                    Log.d(TAG, "loadBusDetails: Bus details loaded. Driver name: " + driverName);
                    
                    textViewDriverName.setText("Driver: " + driverName);
                } else {
                    Log.e(TAG, "loadBusDetails: Failed to parse bus data");
                    textViewDriverName.setText("Driver: Not Available");
                }
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "loadBusDetails: Error loading bus data: " + databaseError.getMessage());
                progressBar.setVisibility(View.GONE);
                textViewDriverName.setText("Driver: Not Available");
            }
        });
    }

    private void updateLastUpdateTime(long timestamp) {
        if (timestamp > 0) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault());
            String formattedTime = sdf.format(new Date(timestamp));
            Log.d(TAG, "updateLastUpdateTime: Formatted time: " + formattedTime);
            textViewLastUpdate.setText("Last updated: " + formattedTime);
        } else {
            Log.e(TAG, "updateLastUpdateTime: Invalid timestamp: " + timestamp);
            textViewLastUpdate.setText("Last updated: Unknown");
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        Log.d(TAG, "onSupportNavigateUp: Navigating back");
        onBackPressed();
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: Activity starting");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: Activity resuming");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: Activity pausing");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: Activity stopping");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: Activity being destroyed");
    }
}