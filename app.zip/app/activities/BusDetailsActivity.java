package com.schoolbus.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.models.Bus;
import com.schoolbus.app.models.Route;
import com.schoolbus.app.models.User;
import com.schoolbus.app.utils.Constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BusDetailsActivity extends AppCompatActivity {
    private static final String TAG = "BusDetailsActivity";

    // UI Components
    private Toolbar toolbar;
    private TextView toolbarTitle;
    private TextView busIdTextView;
    private TextInputEditText busNumberInput;
    private TextInputEditText capacityInput;
    private Spinner driverSpinner;
    private Spinner routeSpinner;
    private Spinner statusSpinner;
    private Button saveButton;
    private Button trackButton;
    private Button deleteButton;
    private CardView locationCard;
    private TextView locationTextView;
    private ProgressBar progressBar;

    // Data
    private String busId;
    private Bus currentBus;
    private List<User> driversList = new ArrayList<>();
    private Map<String, User> driversMap = new HashMap<>();
    private List<Route> routesList = new ArrayList<>();
    private Map<String, Route> routesMap = new HashMap<>();
    private String selectedDriverId = "";
    private String selectedRouteId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_details);

        // Get bus ID from intent
        busId = getIntent().getStringExtra("BUS_ID");
        if (busId == null) {
            Toast.makeText(this, "Error: Bus ID not provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize views
        initializeViews();

        // Set up toolbar
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        toolbarTitle.setText("Bus Details");

        // Set up status spinner
        setupStatusSpinner();

        // Fetch data
        fetchBusData();
        fetchDriversData();
        fetchRoutesData();

        // Set click listeners
        setClickListeners();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        toolbarTitle = findViewById(R.id.toolbarTitle);
        busIdTextView = findViewById(R.id.busIdTextView);
        busNumberInput = findViewById(R.id.busNumberInput);
        capacityInput = findViewById(R.id.capacityInput);
        driverSpinner = findViewById(R.id.driverSpinner);
        routeSpinner = findViewById(R.id.routeSpinner);
        statusSpinner = findViewById(R.id.statusSpinner);
        saveButton = findViewById(R.id.saveButton);
        trackButton = findViewById(R.id.trackButton);
        deleteButton = findViewById(R.id.deleteButton);
        locationCard = findViewById(R.id.locationCard);
        locationTextView = findViewById(R.id.locationTextView);
        progressBar = findViewById(R.id.progressBar);

        busIdTextView.setText("Bus ID: " + busId);
    }

    private void setupStatusSpinner() {
        // Create status options with display names
        String[] statusOptions = {
                "Available",
                "Out of Service",
                "Under Maintenance"
        };

        // Create mapping of display name to actual status value
        final Map<String, String> statusValueMap = new HashMap<>();
        statusValueMap.put("Available", Constants.BUS_STATUS_ACTIVE);
        statusValueMap.put("Out of Service", Constants.BUS_STATUS_INACTIVE);
        statusValueMap.put("Under Maintenance", Constants.BUS_STATUS_MAINTENANCE);

        // Reverse mapping to find display name from status value
        final Map<String, String> valueToDisplayMap = new HashMap<>();
        valueToDisplayMap.put(Constants.BUS_STATUS_ACTIVE, "Available");
        valueToDisplayMap.put(Constants.BUS_STATUS_INACTIVE, "Out of Service");
        valueToDisplayMap.put(Constants.BUS_STATUS_MAINTENANCE, "Under Maintenance");

        ArrayAdapter<String> statusAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, statusOptions);
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(statusAdapter);

        // Update the populateBusData method to display the friendly name
        if (currentBus != null && currentBus.getStatus() != null) {
            String displayStatus = valueToDisplayMap.get(currentBus.getStatus());
            if (displayStatus != null) {
                for (int i = 0; i < statusAdapter.getCount(); i++) {
                    if (statusAdapter.getItem(i).equals(displayStatus)) {
                        statusSpinner.setSelection(i);
                        break;
                    }
                }
            }
        }

        // Store the mapping to be used in saveBusChanges
        statusSpinner.setTag(statusValueMap);
    }

    private void setClickListeners() {
        saveButton.setOnClickListener(v -> saveBusChanges());

        trackButton.setOnClickListener(v -> {
            try {
                Log.d(TAG, "Track button clicked. Bus ID: " + busId + ", Bus Number: " + 
                      (currentBus != null ? currentBus.getBusNumber() : "null"));
                
                if (busId == null || currentBus == null) {
                    showError("Cannot track bus: Missing bus information");
                    return;
                }
                
                Intent intent = new Intent(BusDetailsActivity.this, TrackBusActivity.class);
                intent.putExtra("BUS_ID", busId);
                intent.putExtra("BUS_NUMBER", currentBus.getBusNumber());
                Log.d(TAG, "Starting TrackBusActivity...");
                startActivity(intent);
                Log.d(TAG, "TrackBusActivity should have been started");
            } catch (Exception e) {
                Log.e(TAG, "Error starting TrackBusActivity: " + e.getMessage(), e);
                showError("Error: " + e.getMessage());
            }
        });

        deleteButton.setOnClickListener(v -> confirmDeleteBus());
    }

    private void fetchBusData() {
        progressBar.setVisibility(View.VISIBLE);

        DatabaseReference busRef = FirebaseDatabase.getInstance().getReference("buses").child(busId);
        busRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    currentBus = snapshot.getValue(Bus.class);
                    if (currentBus != null) {
                        currentBus.setId(busId);
                        populateBusData();
                    } else {
                        showError("Error loading bus data");
                    }
                } else {
                    showError("Bus not found");
                }
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                showError("Database error: " + error.getMessage());
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    private void fetchDriversData() {
        DatabaseReference driversRef = FirebaseDatabase.getInstance().getReference("users");
        driversRef.orderByChild("userType").equalTo("driver").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                driversList.clear();
                driversMap.clear();

                // Add "No driver" option
                List<String> driverNames = new ArrayList<>();
                driverNames.add("No driver assigned");

                for (DataSnapshot driverSnapshot : snapshot.getChildren()) {
                    User driver = driverSnapshot.getValue(User.class);
                    if (driver != null) {
                        String driverId = driverSnapshot.getKey();
                        driver.setId(driverId);
                        driversList.add(driver);
                        driversMap.put(driverId, driver);

                        String displayName = driver.getName() + " (" + driver.getPhone() + ")";
                        driverNames.add(displayName);
                    }
                }

                // Set up spinner
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        BusDetailsActivity.this,
                        android.R.layout.simple_spinner_item,
                        driverNames);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                driverSpinner.setAdapter(adapter);

                // Set current driver if data is loaded
                if (currentBus != null) {
                    setSelectedDriver();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading drivers: " + error.getMessage());
            }
        });
    }

    private void fetchRoutesData() {
        DatabaseReference routesRef = FirebaseDatabase.getInstance().getReference("routes");
        routesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                routesList.clear();
                routesMap.clear();

                // Add "No route" option
                List<String> routeNames = new ArrayList<>();
                routeNames.add("No route assigned");

                for (DataSnapshot routeSnapshot : snapshot.getChildren()) {
                    Route route = routeSnapshot.getValue(Route.class);
                    if (route != null) {
                        String routeId = routeSnapshot.getKey();
                        route.setId(routeId);
                        routesList.add(route);
                        routesMap.put(routeId, route);

                        routeNames.add(route.getName());
                    }
                }

                // Set up spinner
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        BusDetailsActivity.this,
                        android.R.layout.simple_spinner_item,
                        routeNames);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                routeSpinner.setAdapter(adapter);

                // Set current route if data is loaded
                if (currentBus != null) {
                    setSelectedRoute();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error loading routes: " + error.getMessage());
            }
        });
    }

    private void populateBusData() {
        busNumberInput.setText(currentBus.getBusNumber());
        capacityInput.setText(String.valueOf(currentBus.getCapacity()));

        // Set status spinner selection
        if (currentBus.getStatus() != null) {
            String status = currentBus.getStatus();
            // Create reverse mapping
            Map<String, String> valueToDisplayMap = new HashMap<>();
            valueToDisplayMap.put(Constants.BUS_STATUS_ACTIVE, "Available");
            valueToDisplayMap.put(Constants.BUS_STATUS_INACTIVE, "Out of Service");
            valueToDisplayMap.put(Constants.BUS_STATUS_MAINTENANCE, "Under Maintenance");

            // Get the display name
            String displayStatus = valueToDisplayMap.get(status);

            if (displayStatus != null) {
                ArrayAdapter<String> adapter = (ArrayAdapter<String>) statusSpinner.getAdapter();
                for (int i = 0; i < adapter.getCount(); i++) {
                    if (adapter.getItem(i).equals(displayStatus)) {
                        statusSpinner.setSelection(i);
                        break;
                    }
                }
            }
        }

        // Set driver and route if spinners are loaded
        setSelectedDriver();
        setSelectedRoute();

        // Set location info if available
        if (currentBus.getCurrentLocation() != null) {
            locationCard.setVisibility(View.VISIBLE);
            double lat = currentBus.getCurrentLocation().getLatitude();
            double lng = currentBus.getCurrentLocation().getLongitude();
            long lastUpdated = currentBus.getCurrentLocation().getLastUpdated();

            String locationInfo = String.format("Lat: %.6f, Lng: %.6f\nLast updated: %s",
                    lat, lng, formatTimestamp(lastUpdated));
            locationTextView.setText(locationInfo);
        } else {
            locationCard.setVisibility(View.GONE);
        }
    }

    private void setSelectedDriver() {
        if (driverSpinner.getAdapter() == null || currentBus == null)
            return;

        String driverId = currentBus.getDriverId();
        if (driverId != null && !driverId.isEmpty()) {
            User driver = driversMap.get(driverId);
            if (driver != null) {
                String displayName = driver.getName() + " (" + driver.getPhone() + ")";
                ArrayAdapter<String> adapter = (ArrayAdapter<String>) driverSpinner.getAdapter();
                for (int i = 0; i < adapter.getCount(); i++) {
                    if (adapter.getItem(i).equals(displayName)) {
                        driverSpinner.setSelection(i);
                        break;
                    }
                }
            }
        }
    }

    private void setSelectedRoute() {
        if (routeSpinner.getAdapter() == null || currentBus == null)
            return;

        String routeId = currentBus.getRouteId();
        if (routeId != null && !routeId.isEmpty()) {
            Route route = routesMap.get(routeId);
            if (route != null) {
                ArrayAdapter<String> adapter = (ArrayAdapter<String>) routeSpinner.getAdapter();
                for (int i = 0; i < adapter.getCount(); i++) {
                    if (adapter.getItem(i).equals(route.getName())) {
                        routeSpinner.setSelection(i);
                        break;
                    }
                }
            }
        }
    }

    private String formatTimestamp(long timestamp) {
        if (timestamp == 0)
            return "Unknown";

        java.util.Date date = new java.util.Date(timestamp);
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd MMM yyyy HH:mm:ss", java.util.Locale.US);
        return sdf.format(date);
    }

    private void saveBusChanges() {
        if (!validateForm()) {
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        // Get updated values
        String busNumber = busNumberInput.getText().toString().trim();
        int capacity = Integer.parseInt(capacityInput.getText().toString().trim());

        // Get the actual status value from the display name
        String statusDisplay = statusSpinner.getSelectedItem().toString();
        Map<String, String> statusValueMap = new HashMap<>();
        statusValueMap.put("Available", Constants.BUS_STATUS_ACTIVE);
        statusValueMap.put("Out of Service", Constants.BUS_STATUS_INACTIVE);
        statusValueMap.put("Under Maintenance", Constants.BUS_STATUS_MAINTENANCE);
        String status = statusValueMap.get(statusDisplay);

        // Get selected driver
        int driverPosition = driverSpinner.getSelectedItemPosition();
        final String driverId; // Make this final
        final String driverName;
        if (driverPosition > 0) { // Not "No driver assigned"
            User selectedDriver = driversList.get(driverPosition - 1); // -1 because of "No driver" option
            driverId = selectedDriver.getId();
            driverName = selectedDriver.getName();

            // Check if this is a new driver assignment (different from current)
            if (!driverId.equals(currentBus.getDriverId())) {
                // Check for and clear any existing assignments for this driver
                checkDriverBusAssignment(driverId, new BusAssignmentCallback() {
                    @Override
                    public void onResult(boolean isAssigned) {
                        // Continue with the update regardless - we've already cleaned up any existing
                        // assignments
                        continueWithBusUpdate(busNumber, capacity, status, driverId, driverName);
                    }
                });
                return; // Exit here, we'll continue in the callback
            }
        } else {
            driverId = "";
            driverName = "";
        }

        // If we get here, it's either the same driver or no driver, proceed with update
        continueWithBusUpdate(busNumber, capacity, status, driverId, driverName);
    }

    private void continueWithBusUpdate(String busNumber, int capacity, String status, String driverId,
            String driverName) {
        // Get selected route
        int routePosition = routeSpinner.getSelectedItemPosition();
        final String routeId;
        final String routeName;
        if (routePosition > 0) { // Not "No route assigned"
            Route selectedRoute = routesList.get(routePosition - 1); // -1 because of "No route" option
            routeId = selectedRoute.getId();
            routeName = selectedRoute.getName();
        } else {
            routeId = "";
            routeName = "";
        }

        // Create update map
        Map<String, Object> updates = new HashMap<>();
        updates.put("busNumber", busNumber);
        updates.put("capacity", capacity);
        updates.put("driverId", driverId);
        updates.put("driverName", driverName);
        updates.put("routeId", routeId);
        updates.put("routeName", routeName);
        updates.put("status", status);

        // Update in Firebase
        DatabaseReference busRef = FirebaseDatabase.getInstance().getReference("buses").child(busId);
        busRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    // If a driver was selected, update the driver record with this bus ID
                    if (!driverId.isEmpty()) {
                        updateDriverWithBusAssignment(driverId, busId, busNumber);
                    }

                    // Also, if the driver changed, update the previous driver to remove bus
                    String previousDriverId = currentBus.getDriverId();
                    if (previousDriverId != null && !previousDriverId.isEmpty() && !previousDriverId.equals(driverId)) {
                        updateDriverWithBusAssignment(previousDriverId, "", "");
                    }

                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(BusDetailsActivity.this, "Bus updated successfully", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    showError("Failed to update bus: " + e.getMessage());
                });
    }

    private void updateDriverWithBusAssignment(String driverId, String busId, String busNumber) {
        DatabaseReference driverRef = FirebaseDatabase.getInstance().getReference("users").child(driverId);

        Map<String, Object> updates = new HashMap<>();
        updates.put("busId", busId);
        updates.put("busNumber", busNumber);

        driverRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Driver " + driverId + " updated with bus " + busId);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error updating driver " + driverId + ": " + e.getMessage());
                });
    }

    private boolean validateForm() {
        boolean valid = true;

        String busNumber = busNumberInput.getText().toString().trim();
        if (busNumber.isEmpty()) {
            busNumberInput.setError("Bus number is required");
            valid = false;
        }

        String capacityStr = capacityInput.getText().toString().trim();
        if (capacityStr.isEmpty()) {
            capacityInput.setError("Capacity is required");
            valid = false;
        } else {
            try {
                int capacity = Integer.parseInt(capacityStr);
                if (capacity <= 0) {
                    capacityInput.setError("Capacity must be greater than 0");
                    valid = false;
                }
            } catch (NumberFormatException e) {
                capacityInput.setError("Invalid capacity");
                valid = false;
            }
        }

        return valid;
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void confirmDeleteBus() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Delete Bus");
        builder.setMessage("Are you sure you want to delete this bus? All related assignments will be removed.");
        builder.setPositiveButton("Delete", (dialog, which) -> {
            deleteBus();
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> {
            dialog.dismiss();
        });
        builder.show();
    }

    private void deleteBus() {
        progressBar.setVisibility(View.VISIBLE);

        // First, update all entities that reference this bus
        updateStudentsAssignedToBus(
                () -> updateDriverAssignedToBus(() -> updateRouteAssignedToBus(() -> performBusDeletion())));
    }

    private void updateStudentsAssignedToBus(Runnable onComplete) {
        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users");

        // Query users with type 'parent'
        usersRef.orderByChild("userType").equalTo("parent").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Task<Void>> updateTasks = new ArrayList<>();

                for (DataSnapshot parentSnapshot : snapshot.getChildren()) {
                    User parent = parentSnapshot.getValue(User.class);
                    String parentId = parentSnapshot.getKey();

                    if (parent != null && parent.getChildren() != null) {
                        boolean hasUpdates = false;
                        Map<String, Object> childrenUpdates = new HashMap<>();

                        for (Map.Entry<String, User.Child> entry : parent.getChildren().entrySet()) {
                            String childId = entry.getKey();
                            User.Child child = entry.getValue();

                            if (child != null && busId.equals(child.getBusId())) {
                                // Create a map for this child's update
                                Map<String, Object> childUpdate = new HashMap<>();
                                childUpdate.put("name", child.getName());
                                childUpdate.put("grade", child.getGrade());
                                childUpdate.put("busId", ""); // Remove bus assignment

                                // Add to the overall children updates
                                childrenUpdates.put("children/" + childId, childUpdate);
                                hasUpdates = true;
                            }
                        }

                        if (hasUpdates) {
                            Task<Void> updateTask = usersRef.child(parentId).updateChildren(childrenUpdates);
                            updateTasks.add(updateTask);
                        }
                    }
                }

                // When all student updates are complete, continue with the next step
                if (updateTasks.isEmpty()) {
                    Log.d(TAG, "No students found assigned to this bus");
                    onComplete.run();
                } else {
                    Tasks.whenAll(updateTasks)
                            .addOnSuccessListener(aVoid -> {
                                Log.d(TAG, "Successfully updated all students");
                                onComplete.run();
                            })
                            .addOnFailureListener(e -> {
                                Log.e(TAG, "Error updating students: " + e.getMessage());
                                // Continue anyway to ensure all entities are updated
                                onComplete.run();
                            });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error querying parents: " + error.getMessage());
                // Continue anyway to ensure all entities are updated
                onComplete.run();
            }
        });
    }

    private void updateDriverAssignedToBus(Runnable onComplete) {
        if (currentBus.getDriverId() == null || currentBus.getDriverId().isEmpty()) {
            // No driver assigned, move to next step
            onComplete.run();
            return;
        }

        DatabaseReference driverRef = FirebaseDatabase.getInstance().getReference("users")
                .child(currentBus.getDriverId());

        // Update driver to remove the bus assignment
        Map<String, Object> updates = new HashMap<>();
        updates.put("busId", "");
        updates.put("busNumber", "");

        driverRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Successfully updated driver");
                    onComplete.run();
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error updating driver: " + e.getMessage());
                    // Continue anyway to ensure all entities are updated
                    onComplete.run();
                });
    }

    private void updateRouteAssignedToBus(Runnable onComplete) {
        if (currentBus.getRouteId() == null || currentBus.getRouteId().isEmpty()) {
            // No route assigned, move to next step
            onComplete.run();
            return;
        }

        DatabaseReference routeRef = FirebaseDatabase.getInstance().getReference("routes")
                .child(currentBus.getRouteId());

        // Update route to remove the bus assignment
        Map<String, Object> updates = new HashMap<>();
        updates.put("busId", "");

        routeRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Successfully updated route");
                    onComplete.run();
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error updating route: " + e.getMessage());
                    // Continue anyway to ensure all entities are updated
                    onComplete.run();
                });
    }

    private void performBusDeletion() {
        DatabaseReference busRef = FirebaseDatabase.getInstance().getReference("buses").child(busId);

        busRef.removeValue()
                .addOnSuccessListener(aVoid -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(BusDetailsActivity.this, "Bus deleted successfully", Toast.LENGTH_SHORT).show();
                    finish(); // Go back to the previous screen
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    showError("Failed to delete bus: " + e.getMessage());
                });
    }

    /**
     * Check if a driver is already assigned to a bus
     * 
     * @param driverId Driver ID to check
     * @param callback Callback with result (true if driver is already assigned to a
     *                 bus)
     */
    private void checkDriverBusAssignment(String driverId, BusAssignmentCallback callback) {
        DatabaseReference busesRef = FirebaseDatabase.getInstance().getReference("buses");
        busesRef.orderByChild("driverId").equalTo(driverId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean isAssigned = false;
                List<Task<Void>> updateTasks = new ArrayList<>();

                // Check all buses with this driver
                for (DataSnapshot busSnapshot : snapshot.getChildren()) {
                    String busDatabaseId = busSnapshot.getKey();
                    // If the driver is assigned to a bus that's not the current one
                    if (!busDatabaseId.equals(busId)) {
                        isAssigned = true;

                        // Clear the driver assignment from this bus
                        Map<String, Object> updates = new HashMap<>();
                        updates.put("driverId", "");
                        updates.put("driverName", "");

                        DatabaseReference otherBusRef = busesRef.child(busDatabaseId);
                        Task<Void> updateTask = otherBusRef.updateChildren(updates);
                        updateTasks.add(updateTask);

                        Log.d(TAG, "Removing driver " + driverId + " from bus " + busDatabaseId);
                    }
                }

                // If we found assignments, wait for all updates to complete
                if (!updateTasks.isEmpty()) {
                    // Show toast that we're removing driver from other buses
                    runOnUiThread(() -> {
                        Toast.makeText(BusDetailsActivity.this,
                                "Driver was assigned to another bus. Removing previous assignment.",
                                Toast.LENGTH_SHORT).show();
                    });

                    Tasks.whenAll(updateTasks)
                            .addOnSuccessListener(aVoid -> {
                                Log.d(TAG, "Successfully cleared previous driver assignments");
                                // Always return false since we've now cleared the assignments
                                callback.onResult(false);
                            })
                            .addOnFailureListener(e -> {
                                Log.e(TAG, "Error clearing driver assignments: " + e.getMessage());
                                // Return false to allow the update to proceed anyway
                                callback.onResult(false);
                            });
                } else {
                    // No assignments found or cleared
                    callback.onResult(false);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error checking driver assignment: " + error.getMessage());
                // Default to false to allow the update to proceed
                callback.onResult(false);
            }
        });
    }

    /**
     * Interface for driver bus assignment check callback
     */
    interface BusAssignmentCallback {
        void onResult(boolean isAssigned);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}