package com.schoolbus.app.activities;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.models.Route;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class EditRouteActivity extends AppCompatActivity {
    private static final String TAG = "EditRouteActivity";

    // UI components
    private TextView routeIdView;
    private SwitchMaterial activeSwitch;
    private TextInputEditText routeNameInput, descriptionInput, busIdInput;
    private TextInputEditText startTimeInput, endTimeInput;
    private CheckBox mondayCheckbox, tuesdayCheckbox, wednesdayCheckbox,
            thursdayCheckbox, fridayCheckbox, saturdayCheckbox, sundayCheckbox;
    private RecyclerView stopsRecyclerView;
    private Button addStopButton, saveButton, deleteButton;
    private ProgressBar progressBar;

    // Data
    private String routeId;
    private Route currentRoute;
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_route);

        // Get route ID from intent
        routeId = getIntent().getStringExtra("route_id");
        if (routeId == null) {
            Toast.makeText(this, "Error: Route ID not provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize views
        initializeViews();

        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // Fetch route data
        fetchRouteData();

        // Set click listeners
        setClickListeners();
    }

    private void initializeViews() {
        routeIdView = findViewById(R.id.routeIdView);
        routeNameInput = findViewById(R.id.routeNameInput);
        descriptionInput = findViewById(R.id.descriptionInput);
        busIdInput = findViewById(R.id.busIdInput);
        startTimeInput = findViewById(R.id.startTimeInput);
        endTimeInput = findViewById(R.id.endTimeInput);

        // Initialize active switch with null check
        activeSwitch = findViewById(R.id.activeSwitch);
        if (activeSwitch != null) {
            activeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    activeSwitch.setText(isChecked ? "Active  " : "Inactive  ");
                }
            });
        }

        // Checkboxes for days
        mondayCheckbox = findViewById(R.id.mondayCheckbox);
        tuesdayCheckbox = findViewById(R.id.tuesdayCheckbox);
        wednesdayCheckbox = findViewById(R.id.wednesdayCheckbox);
        thursdayCheckbox = findViewById(R.id.thursdayCheckbox);
        fridayCheckbox = findViewById(R.id.fridayCheckbox);
        saturdayCheckbox = findViewById(R.id.saturdayCheckbox);
        sundayCheckbox = findViewById(R.id.sundayCheckbox);

        // Other views
        stopsRecyclerView = findViewById(R.id.stopsRecyclerView);
        stopsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        addStopButton = findViewById(R.id.addStopButton);
        saveButton = findViewById(R.id.saveButton);
        deleteButton = findViewById(R.id.deleteButton);
        progressBar = findViewById(R.id.progressBar);

        // Display route ID
        routeIdView.setText("Route ID: " + routeId);
    }

    private void setClickListeners() {
        // Time picker dialogs
        startTimeInput.setOnClickListener(v -> showTimePickerDialog(startTimeInput));
        endTimeInput.setOnClickListener(v -> showTimePickerDialog(endTimeInput));

        // Add stop button
        addStopButton.setOnClickListener(v -> {
            // TODO: Implement add stop functionality
            Toast.makeText(this, "Add stop feature coming soon", Toast.LENGTH_SHORT).show();
        });

        // Save button
        saveButton.setOnClickListener(v -> saveRouteChanges());

        // Delete button
        deleteButton.setOnClickListener(v -> confirmDelete());
    }

    private void fetchRouteData() {
        progressBar.setVisibility(View.VISIBLE);

        DatabaseReference routeRef = FirebaseDatabase.getInstance().getReference("routes").child(routeId);
        routeRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressBar.setVisibility(View.GONE);

                if (snapshot.exists()) {
                    currentRoute = snapshot.getValue(Route.class);

                    if (currentRoute != null) {
                        currentRoute.setId(routeId);
                        populateFormFields();
                    } else {
                        showError("Error loading route data");
                    }
                } else {
                    showError("Route not found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
                showError("Database error: " + error.getMessage());
            }
        });
    }

    private void populateFormFields() {
        try {
            // Basic info
            if (routeNameInput != null)
                routeNameInput.setText(currentRoute.getName());
            if (descriptionInput != null)
                descriptionInput.setText(currentRoute.getDescription());
            if (busIdInput != null)
                busIdInput.setText(currentRoute.getBusId());

            // Set active status
            if (activeSwitch != null) {
                activeSwitch.setChecked(currentRoute.isActive());
                activeSwitch.setText(currentRoute.isActive() ? "Active  " : "Inactive  ");
            }

            // Times
            if (startTimeInput != null)
                startTimeInput.setText(currentRoute.getStartTime());
            if (endTimeInput != null)
                endTimeInput.setText(currentRoute.getEndTime());

            // Days
            List<String> days = currentRoute.getDays();
            if (days != null) {
                for (String day : days) {
                    switch (day.toLowerCase()) {
                        case "monday":
                            mondayCheckbox.setChecked(true);
                            break;
                        case "tuesday":
                            tuesdayCheckbox.setChecked(true);
                            break;
                        case "wednesday":
                            wednesdayCheckbox.setChecked(true);
                            break;
                        case "thursday":
                            thursdayCheckbox.setChecked(true);
                            break;
                        case "friday":
                            fridayCheckbox.setChecked(true);
                            break;
                        case "saturday":
                            saturdayCheckbox.setChecked(true);
                            break;
                        case "sunday":
                            sundayCheckbox.setChecked(true);
                            break;
                    }
                }
            }

            // TODO: Set up stops adapter
        } catch (Exception e) {
            Log.e(TAG, "Error populating form fields: " + e.getMessage());
            showError("Error populating form fields");
        }
    }

    private void saveRouteChanges() {
        if (!validateForm()) {
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        try {
            // Update route object
            currentRoute.setName(routeNameInput.getText().toString().trim());
            currentRoute.setDescription(descriptionInput.getText().toString().trim());
            currentRoute.setBusId(busIdInput.getText().toString().trim());
            currentRoute.setStartTime(startTimeInput.getText().toString().trim());
            currentRoute.setEndTime(endTimeInput.getText().toString().trim());

            // Update active status if the switch exists
            if (activeSwitch != null) {
                currentRoute.setActive(activeSwitch.isChecked());
            }

            // Update days
            List<String> selectedDays = new ArrayList<>();
            if (mondayCheckbox.isChecked())
                selectedDays.add("Monday");
            if (tuesdayCheckbox.isChecked())
                selectedDays.add("Tuesday");
            if (wednesdayCheckbox.isChecked())
                selectedDays.add("Wednesday");
            if (thursdayCheckbox.isChecked())
                selectedDays.add("Thursday");
            if (fridayCheckbox.isChecked())
                selectedDays.add("Friday");
            if (saturdayCheckbox.isChecked())
                selectedDays.add("Saturday");
            if (sundayCheckbox.isChecked())
                selectedDays.add("Sunday");
            currentRoute.setDays(selectedDays);

            // Save to Firebase
            DatabaseReference routeRef = FirebaseDatabase.getInstance().getReference("routes").child(routeId);

            Map<String, Object> routeValues = new HashMap<>();
            routeValues.put("name", currentRoute.getName());
            routeValues.put("description", currentRoute.getDescription());
            routeValues.put("busId", currentRoute.getBusId());
            routeValues.put("startTime", currentRoute.getStartTime());
            routeValues.put("endTime", currentRoute.getEndTime());
            routeValues.put("days", currentRoute.getDays());
            routeValues.put("active", currentRoute.isActive());

            routeRef.updateChildren(routeValues)
                    .addOnSuccessListener(aVoid -> {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(EditRouteActivity.this, "Route updated successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> {
                        progressBar.setVisibility(View.GONE);
                        showError("Error updating route: " + e.getMessage());
                    });
        } catch (Exception e) {
            Log.e(TAG, "Error saving route changes: " + e.getMessage());
            showError("Error saving route changes");
        }
    }

    private boolean validateForm() {
        boolean valid = true;

        // Validate required fields
        if (routeNameInput.getText().toString().trim().isEmpty()) {
            routeNameInput.setError("Route name is required");
            valid = false;
        }

        if (busIdInput.getText().toString().trim().isEmpty()) {
            busIdInput.setError("Bus ID is required");
            valid = false;
        }

        return valid;
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Delete Route")
                .setMessage("Are you sure you want to delete this route? This action cannot be undone.")
                .setPositiveButton("Delete", (dialog, which) -> deleteRoute())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteRoute() {
        progressBar.setVisibility(View.VISIBLE);

        DatabaseReference routeRef = FirebaseDatabase.getInstance().getReference("routes").child(routeId);
        routeRef.removeValue()
                .addOnSuccessListener(aVoid -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(EditRouteActivity.this, "Route deleted successfully", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    showError("Error deleting route: " + e.getMessage());
                });
    }

    private void showTimePickerDialog(TextInputEditText timeInput) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        // Parse existing time if available
        String currentTime = timeInput.getText().toString();
        if (!currentTime.isEmpty()) {
            try {
                Calendar parsedTime = Calendar.getInstance();
                parsedTime.setTime(timeFormat.parse(currentTime));
                hour = parsedTime.get(Calendar.HOUR_OF_DAY);
                minute = parsedTime.get(Calendar.MINUTE);
            } catch (Exception e) {
                Log.e(TAG, "Error parsing time: " + e.getMessage());
            }
        }

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, hourOfDay, selectedMinute) -> {
                    Calendar selectedTime = Calendar.getInstance();
                    selectedTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    selectedTime.set(Calendar.MINUTE, selectedMinute);
                    timeInput.setText(timeFormat.format(selectedTime.getTime()));
                },
                hour,
                minute,
                false);

        timePickerDialog.show();
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}