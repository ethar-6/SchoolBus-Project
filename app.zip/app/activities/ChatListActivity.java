package com.schoolbus.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.schoolbus.app.R;
import com.schoolbus.app.SchoolBusApplication;
import com.schoolbus.app.adapters.ChatAdapter;
import com.schoolbus.app.models.Chat;
import com.schoolbus.app.services.ChatService;
import com.schoolbus.app.utils.Constants;
import com.schoolbus.app.utils.PreferenceManager;

import java.util.ArrayList;
import java.util.List;

public class ChatListActivity extends AppCompatActivity implements ChatAdapter.OnChatClickListener {
    private RecyclerView chatsRecyclerView;
    private ChatAdapter chatAdapter;
    private ChatService chatService;
    private PreferenceManager preferenceManager;
    private List<Chat> chatList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);

        // Initialize views
        chatsRecyclerView = findViewById(R.id.chatsRecyclerView);
        chatsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize services
        DatabaseReference database = ((SchoolBusApplication) getApplication()).getFirebaseDatabase().getReference("");
        chatService = new ChatService(database, this);
        preferenceManager = new PreferenceManager(this);

        // Initialize chat list
        chatList = new ArrayList<>();
        chatAdapter = new ChatAdapter(chatList, this);
        chatsRecyclerView.setAdapter(chatAdapter);

        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.chat);
        }

        // Load user's chats
        loadUserChats();
    }

    private void loadUserChats() {
        String userId = preferenceManager.getUserId();
        String userType = preferenceManager.getUserType();

        if (userId == null || userType == null) {
            Toast.makeText(this, R.string.error_user_not_found, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        chatService.getUserChats(userId, userType, new ChatService.ChatsCallback() {
            @Override
            public void onSuccess(List<Chat> chats) {
                chatList.clear();

                // Only filter out chats that don't have a child ID
                for (Chat chat : chats) {
                    if (chat.getChildId() != null && chat.getChildName() != null) {
                        chatList.add(chat);
                    }
                }

                chatAdapter.notifyDataSetChanged();

                // Show empty state if no chats
                if (chatList.isEmpty()) {
                    findViewById(R.id.emptyView).setVisibility(View.VISIBLE);
                    chatsRecyclerView.setVisibility(View.GONE);
                } else {
                    findViewById(R.id.emptyView).setVisibility(View.GONE);
                    chatsRecyclerView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onError(String error) {
                Toast.makeText(ChatListActivity.this, error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onChatClick(Chat chat) {
        android.util.Log.d("ChatListActivity", "Chat clicked: " + chat.getId() + " for child: " + chat.getChildName());

        // Make sure we have the required data
        if (chat.getChildId() == null) {
            Toast.makeText(this, "Error: Missing child ID", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(this, ChatConversationActivity.class);

        // For consistent behavior, always use chat.getId() only if we're sure it exists
        if (chat.getId() != null) {
            intent.putExtra(Constants.EXTRA_CHAT_ID, chat.getId());
            android.util.Log.d("ChatListActivity", "Passing chat ID: " + chat.getId());
        } else {
            // If no chat ID, we can create one (though this shouldn't happen with our
            // fixes)
            String generatedChatId = chat.getChildId() + "_chat";
            intent.putExtra(Constants.EXTRA_CHAT_ID, generatedChatId);
            android.util.Log.d("ChatListActivity", "Generated chat ID: " + generatedChatId);
        }

        // Always pass child info
        intent.putExtra(Constants.EXTRA_CHILD_ID, chat.getChildId());
        intent.putExtra(Constants.EXTRA_CHILD_NAME, chat.getChildName());
        android.util.Log.d("ChatListActivity", "Passing child ID: " + chat.getChildId());

        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}