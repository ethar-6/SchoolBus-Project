package com.schoolbus.app.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.models.User;
import com.schoolbus.app.utils.Constants;

public class LoginActivity extends BaseActivity {
    private TextInputLayout emailLayout;
    private TextInputLayout passwordLayout;
    private TextInputEditText emailInput;
    private TextInputEditText passwordInput;
    private MaterialButton loginButton;
    private TextView registerText;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize views
        initViews();
        // Set click listeners
        setListeners();
        // Check if user is already logged in
        checkLoginStatus();
    }

    private void initViews() {
        emailLayout = findViewById(R.id.emailLayout);
        passwordLayout = findViewById(R.id.passwordLayout);
        emailInput = findViewById(R.id.emailEditText);
        passwordInput = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerText = findViewById(R.id.registerTextView);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setListeners() {
        loginButton.setOnClickListener(v -> validateAndLogin());
        registerText.setOnClickListener(v -> navigateToActivity(RegisterActivity.class));
    }

    private void checkLoginStatus() {
        if (isUserLoggedIn()) {
            // Get user type from preferences and navigate accordingly
            String userType = preferenceManager.getUserType();

            if (userType != null) {
                if (userType.equals(Constants.USER_TYPE_ADMIN)) {
                    navigateToActivityAndClear(AdminDashboardActivity.class);
                } else if (userType.equals(Constants.USER_TYPE_DRIVER)) {
                    navigateToActivityAndClear(DriverDashboardActivity.class);
                } else {
                    // Default for parent or unspecified type
                    navigateToActivityAndClear(MainActivity.class);
                }
            } else {
                // Fallback in case user type is null
                navigateToActivityAndClear(MainActivity.class);
            }
        }
    }

    private void validateAndLogin() {
        // Reset errors
        emailLayout.setError(null);
        passwordLayout.setError(null);

        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            emailLayout.setError(getString(R.string.error_email_required));
            return;
        }

        if (TextUtils.isEmpty(password)) {
            passwordLayout.setError(getString(R.string.error_password_required));
            return;
        }

        // Show loading
        progressBar.setVisibility(View.VISIBLE);
        loginButton.setEnabled(false);

        // Check for admin credentials
        if (email.equals("admin") && password.equals("admin")) {
            // Create a dummy admin user
            User adminUser = new User();
            adminUser.setId("admin");
            adminUser.setName("Admin");
            adminUser.setEmail("admin@schoolbus.com");
            adminUser.setType(Constants.USER_TYPE_ADMIN);

            // Save admin user in preferences
            preferenceManager.saveUser(adminUser);
            preferenceManager.setUserId("admin");
            preferenceManager.setUserType(Constants.USER_TYPE_ADMIN); // Explicitly save user type

            // Hide loading
            progressBar.setVisibility(View.GONE);
            loginButton.setEnabled(true);

            // Navigate to admin dashboard
            navigateToActivityAndClear(AdminDashboardActivity.class);
            return;
        }

        // For testing purposes - allow test@test.com to login without Firebase
        if (email.contains("test")) {
            // Create a test user
            User testUser = new User();
            testUser.setId("test_user");
            testUser.setName("Test User");
            testUser.setEmail(email);
            testUser.setType(Constants.USER_TYPE_PARENT); // Default to parent for test accounts

            // Save test user in preferences
            preferenceManager.saveUser(testUser);
            preferenceManager.setUserId("test_user");
            preferenceManager.setUserType(Constants.USER_TYPE_PARENT);

            // Hide loading
            progressBar.setVisibility(View.GONE);
            loginButton.setEnabled(true);

            // Navigate to main activity (parent dashboard)
            navigateToActivityAndClear(MainActivity.class);
            return;
        }

        // Attempt login with Firebase
        firebaseManager.signIn(email, password, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    // Update last login timestamp
                    updateLastLogin();
                } else {
                    // Hide loading
                    progressBar.setVisibility(View.GONE);
                    loginButton.setEnabled(true);
                    // Show error
                    showToast(task.getException() != null ? task.getException().getMessage()
                            : getString(R.string.error_login_failed));
                }
            }
        });
    }

    private void updateLastLogin() {
        firebaseManager.getCurrentUserRef().child("lastLoginAt")
                .setValue(System.currentTimeMillis())
                .addOnCompleteListener(task -> {
                    // Hide loading
                    progressBar.setVisibility(View.GONE);
                    loginButton.setEnabled(true);

                    if (task.isSuccessful()) {
                        // Save user ID in preferences
                        if (firebaseManager.getCurrentUser() != null) {
                            String userId = firebaseManager.getCurrentUser().getUid();
                            preferenceManager.setUserId(userId);

                            // Get and save user profile
                            firebaseManager.getUserProfile(userId, new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.exists()) {
                                        // Log the raw data from firebase for debugging
                                        Log.d("LoginActivity", "User data snapshot: " + dataSnapshot.toString());

                                        // Log specific fields
                                        Log.d("LoginActivity",
                                                "User type field: " + dataSnapshot.child("type").getValue());
                                        Log.d("LoginActivity",
                                                "User userType field: " + dataSnapshot.child("userType").getValue());

                                        User user = dataSnapshot.getValue(User.class);
                                        if (user != null) {
                                            user.setId(userId);

                                            // Check for userType field if type is null (for backward compatibility)
                                            if (user.getType() == null) {
                                                // Try first the "type" field
                                                String userType = dataSnapshot.child("type").getValue(String.class);

                                                // If still null, try the "userType" field
                                                if (userType == null) {
                                                    userType = dataSnapshot.child("userType").getValue(String.class);
                                                }

                                                if (userType != null) {
                                                    user.setType(userType);
                                                    Log.d("LoginActivity",
                                                            "Setting user type from database field: " + userType);
                                                }
                                            }

                                            // Force check for driver type (special handler for driver accounts)
                                            if (dataSnapshot.child("userType").getValue(String.class) != null &&
                                                    Constants.USER_TYPE_DRIVER.equals(
                                                            dataSnapshot.child("userType").getValue(String.class))) {
                                                Log.d("LoginActivity", "Detected driver account from userType field!");
                                                user.setType(Constants.USER_TYPE_DRIVER);
                                            }

                                            // Save user and user type in preferences
                                            preferenceManager.saveUser(user);
                                            preferenceManager.setUserType(user.getType()); // Explicitly save user type

                                            // Log user type for debugging
                                            Log.d("LoginActivity", "Final user type: " + user.getType());

                                            // Navigate based on user type
                                            navigateBasedOnUserType(user);
                                        } else {
                                            Log.e("LoginActivity", "User object is null after getValue()");
                                        }
                                    } else {
                                        Log.e("LoginActivity", "User data does not exist in database");
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                    showToast(getString(R.string.error_login_failed));
                                }
                            });
                        } else {
                            // Handle case where firebase user is null
                            Log.e("LoginActivity", "Firebase user is null after successful login");
                            showToast(getString(R.string.error_login_failed));
                        }
                    } else {
                        showToast(getString(R.string.error_login_failed));
                    }
                });
    }

    private void navigateBasedOnUserType(User user) {
        // Check if user is null as a safety measure
        if (user == null) {
            Log.e("LoginActivity", "User object is null in navigateBasedOnUserType");
            showToast("Error: User data is missing");
            navigateToActivityAndClear(MainActivity.class);
            return;
        }

        String userType = user.getType();
        Log.d("LoginActivity", "Navigating based on user type: " + userType);

        if (userType != null) {
            if (userType.equals(Constants.USER_TYPE_ADMIN)) {
                Log.d("LoginActivity", "Navigating to AdminDashboardActivity");
                navigateToActivityAndClear(AdminDashboardActivity.class);
            } else if (userType.equals(Constants.USER_TYPE_DRIVER)) {
                Log.d("LoginActivity", "Navigating to DriverDashboardActivity");
                navigateToActivityAndClear(DriverDashboardActivity.class);
            } else {
                // Default for parent or unspecified type
                Log.d("LoginActivity", "Navigating to MainActivity (default for parent/unknown)");
                navigateToActivityAndClear(MainActivity.class);
            }
        } else {
            // Default to main activity if user type is not set
            Log.e("LoginActivity", "User type is null, defaulting to MainActivity");
            showToast("Warning: User type is not specified");
            preferenceManager.setUserType(Constants.USER_TYPE_PARENT); // Set default type as parent
            navigateToActivityAndClear(MainActivity.class);
        }
    }
}