package com.schoolbus.app.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.models.Bus;
import com.schoolbus.app.models.Route;
import com.schoolbus.app.models.User;
import com.schoolbus.app.utils.Constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddBusActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private TextInputEditText busNumberInput, capacityInput;
    private Spinner driverSpinner, routeSpinner, statusSpinner;
    private Button saveButton, cancelButton;
    private ProgressBar progressBar;

    private List<User> drivers = new ArrayList<>();
    private List<Route> routes = new ArrayList<>();
    private Map<String, User> driverMap = new HashMap<>();
    private Map<String, Route> routeMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_bus);

        initViews();
        setupToolbar();
        setupStatusSpinner();
        fetchDriversData();
        fetchRoutesData();

        // The saveButton click listener is now set in setupStatusSpinner
        cancelButton.setOnClickListener(v -> finish());
    }

    private void initViews() {
        toolbar = findViewById(R.id.toolbar);
        busNumberInput = findViewById(R.id.busNumberInput);
        capacityInput = findViewById(R.id.capacityInput);
        driverSpinner = findViewById(R.id.driverSpinner);
        routeSpinner = findViewById(R.id.routeSpinner);
        statusSpinner = findViewById(R.id.statusSpinner);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    private void setupStatusSpinner() {
        // Create status options with display names
        String[] statusOptions = {
                "Available",
                "Out of Service",
                "Under Maintenance"
        };

        // Create mapping of display name to actual status value
        final Map<String, String> statusValueMap = new HashMap<>();
        statusValueMap.put("Available", Constants.BUS_STATUS_ACTIVE);
        statusValueMap.put("Out of Service", Constants.BUS_STATUS_INACTIVE);
        statusValueMap.put("Under Maintenance", Constants.BUS_STATUS_MAINTENANCE);

        ArrayAdapter<String> statusAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, statusOptions);
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(statusAdapter);

        // Update the saveBus method to use the correct status value
        saveButton.setOnClickListener(v -> {
            // Get the display name from the spinner
            String statusDisplay = statusSpinner.getSelectedItem().toString();
            // Get the actual status value from the map
            String actualStatus = statusValueMap.get(statusDisplay);

            // Save the bus with the correct status
            saveBusWithStatus(actualStatus);
        });

        // Remove the original click listener since we added a new one
        cancelButton.setOnClickListener(v -> finish());
    }

    private void saveBusWithStatus(String status) {
        String busNumber = busNumberInput.getText().toString().trim();
        String capacityStr = capacityInput.getText().toString().trim();
        String driverName = driverSpinner.getSelectedItem().toString();
        String routeName = routeSpinner.getSelectedItem().toString();

        // Validate input
        if (TextUtils.isEmpty(busNumber)) {
            busNumberInput.setError("Bus number is required");
            busNumberInput.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(capacityStr)) {
            capacityInput.setError("Capacity is required");
            capacityInput.requestFocus();
            return;
        }

        int capacity = Integer.parseInt(capacityStr);

        showLoading(true);

        // Create a new bus ID
        DatabaseReference busesRef = FirebaseDatabase.getInstance().getReference("buses");
        String busId = busesRef.push().getKey();

        // Get driver ID if a driver was selected
        String driverId = null;
        if (!driverName.equals("No driver assigned") && driverMap.containsKey(driverName)) {
            driverId = driverMap.get(driverName).getId();
        }

        // Get route ID if a route was selected
        final String routeId;
        final Route selectedRoute;
        if (!routeName.equals("No route assigned") && routeMap.containsKey(routeName)) {
            selectedRoute = routeMap.get(routeName);
            routeId = selectedRoute.getId();
        } else {
            selectedRoute = null;
            routeId = null;
        }

        // Create new bus object
        Bus newBus = new Bus();
        newBus.setId(busId);
        newBus.setBusNumber(busNumber);
        newBus.setCapacity(capacity);
        newBus.setDriverId(driverId);
        newBus.setRouteId(routeId);
        newBus.setStatus(status);

        // Save to Firebase
        busesRef.child(busId).setValue(newBus)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Update route with bus ID if a route was selected
                        if (selectedRoute != null) {
                            FirebaseDatabase.getInstance().getReference("routes")
                                    .child(routeId)
                                    .child("busId")
                                    .setValue(busId)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> routeUpdateTask) {
                                            if (!routeUpdateTask.isSuccessful()) {
                                                Toast.makeText(AddBusActivity.this,
                                                        "Note: Bus added but route update failed",
                                                        Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                        }

                        Toast.makeText(AddBusActivity.this,
                                "Bus added successfully",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(AddBusActivity.this,
                                "Failed to add bus: " + task.getException().getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                    showLoading(false);
                });
    }

    private void fetchDriversData() {
        showLoading(true);
        FirebaseDatabase.getInstance().getReference("users")
                .orderByChild("role")
                .equalTo("driver")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        drivers.clear();
                        driverMap.clear();

                        // Add "No driver assigned" option
                        List<String> driverNames = new ArrayList<>();
                        driverNames.add("No driver assigned");

                        for (DataSnapshot driverSnapshot : snapshot.getChildren()) {
                            User driver = driverSnapshot.getValue(User.class);
                            if (driver != null) {
                                drivers.add(driver);
                                driverMap.put(driver.getName(), driver);
                                driverNames.add(driver.getName());
                            }
                        }

                        ArrayAdapter<String> driverAdapter = new ArrayAdapter<>(
                                AddBusActivity.this,
                                android.R.layout.simple_spinner_item,
                                driverNames);
                        driverAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        driverSpinner.setAdapter(driverAdapter);

                        showLoading(false);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        showLoading(false);
                        Toast.makeText(AddBusActivity.this,
                                "Failed to load drivers: " + error.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void fetchRoutesData() {
        FirebaseDatabase.getInstance().getReference("routes")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        routes.clear();
                        routeMap.clear();

                        // Add "No route assigned" option
                        List<String> routeNames = new ArrayList<>();
                        routeNames.add("No route assigned");

                        for (DataSnapshot routeSnapshot : snapshot.getChildren()) {
                            Route route = routeSnapshot.getValue(Route.class);
                            if (route != null) {
                                routes.add(route);
                                routeMap.put(route.getName(), route);
                                routeNames.add(route.getName());
                            }
                        }

                        ArrayAdapter<String> routeAdapter = new ArrayAdapter<>(
                                AddBusActivity.this,
                                android.R.layout.simple_spinner_item,
                                routeNames);
                        routeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        routeSpinner.setAdapter(routeAdapter);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(AddBusActivity.this,
                                "Failed to load routes: " + error.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void showLoading(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        saveButton.setEnabled(!isLoading);
        cancelButton.setEnabled(!isLoading);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}