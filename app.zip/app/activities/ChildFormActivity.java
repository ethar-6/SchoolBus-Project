package com.schoolbus.app.activities;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.schoolbus.app.R;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.Bus;
import com.schoolbus.app.models.User;
import com.schoolbus.app.utils.PreferenceManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import android.widget.AutoCompleteTextView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class ChildFormActivity extends BaseActivity {

    private TextInputLayout childNameLayout;
    private TextInputLayout gradeLayout;
    private TextInputLayout busLayout;

    private TextInputEditText childNameEditText;
    private TextInputEditText gradeEditText;
    private AutoCompleteTextView busEditText;

    private View saveButton;
    private View progressBar;

    private FirebaseManager firebaseManager;
    private PreferenceManager preferenceManager;
    private String childId;
    private User user;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child_form);

        // Initialize Firebase and Preferences
        firebaseManager = FirebaseManager.getInstance();
        preferenceManager = PreferenceManager.getInstance(this);

        // Get current user
        user = preferenceManager.getUser();

        // Initialize views
        initViews();

        // Set up click listeners
        setupClickListeners();

        // Load child data if editing
        loadChildData();
    }

    private void initViews() {
        childNameLayout = findViewById(R.id.childNameLayout);
        gradeLayout = findViewById(R.id.gradeLayout);
        busLayout = findViewById(R.id.busLayout);

        childNameEditText = findViewById(R.id.childNameEditText);
        gradeEditText = findViewById(R.id.gradeEditText);
        busEditText = findViewById(R.id.busEditText);

        saveButton = findViewById(R.id.saveButton);
        progressBar = findViewById(R.id.progressBar);

        // Load buses data
        loadBuses();
    }

    private void setupClickListeners() {
        saveButton.setOnClickListener(v -> saveChild());
    }

    private void loadChildData() {
        childId = getIntent().getStringExtra("child_id");
        if (childId != null) {
            String childName = getIntent().getStringExtra("child_name");
            String childGrade = getIntent().getStringExtra("child_grade");
            String busId = getIntent().getStringExtra("child_bus_id");

            // Populate fields with existing data
            childNameEditText.setText(childName);
            gradeEditText.setText(childGrade);

            // Load buses and select the correct one
            firebaseManager.getActiveBuses(new FirebaseManager.DataCallback<List<Bus>>() {
                @Override
                public void onSuccess(List<Bus> buses) {
                    ArrayAdapter<Bus> adapter = new ArrayAdapter<>(
                            ChildFormActivity.this,
                            android.R.layout.simple_dropdown_item_1line,
                            buses);
                    busEditText.setAdapter(adapter);

                    // Select the correct bus
                    if (busId != null) {
                        for (int i = 0; i < buses.size(); i++) {
                            Bus bus = buses.get(i);
                            if (bus.getId().equals(busId)) {
                                busEditText.setText(bus.toString(), false);
                                break;
                            }
                        }
                    }
                }

                @Override
                public void onError(String errorMessage) {
                    showToast(errorMessage);
                }
            });
        } else {
            // For new child, just load buses normally
            loadBuses();
        }
    }

    private void loadBuses() {
        firebaseManager.getActiveBuses(new FirebaseManager.DataCallback<List<Bus>>() {
            @Override
            public void onSuccess(List<Bus> buses) {
                ArrayAdapter<Bus> adapter = new ArrayAdapter<>(
                        ChildFormActivity.this,
                        android.R.layout.simple_dropdown_item_1line,
                        buses);
                busEditText.setAdapter(adapter);
            }

            @Override
            public void onError(String errorMessage) {
                showToast(errorMessage);
            }
        });
    }

    private void saveChild() {
        // Check if user is available
        if (user == null) {
            // Try to get user from preferences
            user = preferenceManager.getUser();
            if (user == null) {
                // If still null, try to get from Firebase
                String userId = preferenceManager.getUserId();
                if (userId == null) {
                    showToast(getString(R.string.error_user_not_found));
                    return;
                }

                firebaseManager.getUserProfile(userId, new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            User refreshedUser = dataSnapshot.getValue(User.class);
                            if (refreshedUser != null) {
                                refreshedUser.setId(userId);
                                user = refreshedUser;
                                preferenceManager.saveUser(user);
                                proceedWithSaveChild();
                            } else {
                                showToast(getString(R.string.error_user_not_found));
                            }
                        } else {
                            showToast(getString(R.string.error_user_not_found));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        showToast(getString(R.string.error_user_not_found));
                    }
                });
                return;
            }
        }

        proceedWithSaveChild();
    }

    private void proceedWithSaveChild() {
        // Show progress and disable save button
        progressBar.setVisibility(View.VISIBLE);
        saveButton.setEnabled(false);

        String name = childNameEditText.getText().toString().trim();
        String grade = gradeEditText.getText().toString().trim();
        Bus selectedBus = null;
        if (busEditText.getAdapter() != null && busEditText.getText() != null) {
            String selectedText = busEditText.getText().toString();
            ArrayAdapter<Bus> adapter = (ArrayAdapter<Bus>) busEditText.getAdapter();
            for (int i = 0; i < adapter.getCount(); i++) {
                Bus bus = adapter.getItem(i);
                if (bus != null && bus.toString().equals(selectedText)) {
                    selectedBus = bus;
                    break;
                }
            }
        }

        // Validate inputs
        if (name.isEmpty()) {
            childNameLayout.setError(getString(R.string.error_child_name_required));
            progressBar.setVisibility(View.GONE);
            saveButton.setEnabled(true);
            return;
        }

        if (grade.isEmpty()) {
            gradeLayout.setError(getString(R.string.error_grade_required));
            progressBar.setVisibility(View.GONE);
            saveButton.setEnabled(true);
            return;
        }

        if (selectedBus == null) {
            busLayout.setError(getString(R.string.error_bus_required));
            progressBar.setVisibility(View.GONE);
            saveButton.setEnabled(true);
            return;
        }

        // Clear any previous errors
        childNameLayout.setError(null);
        gradeLayout.setError(null);
        busLayout.setError(null);

        // Create child object
        User.Child child;
        if (childId != null) {
            // For editing existing child
            child = new User.Child(childId, name, grade, selectedBus.getId());
        } else {
            // For new child
            child = new User.Child(name, grade, selectedBus.getId());
        }

        // Update user's children map
        Map<String, User.Child> children = user.getChildren();
        if (children == null) {
            children = new HashMap<>();
        }

        if (childId != null) {
            // Update existing child
            children.put(childId, child);
        } else {
            // Add new child
            children.put(child.getId(), child);
        }

        // Update user profile
        Map<String, Object> updates = new HashMap<>();
        updates.put("/children/" + child.getId(), child);

        firebaseManager.updateUserProfile(user.getId(), updates, new FirebaseManager.DataCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                // Hide progress and enable save button
                progressBar.setVisibility(View.GONE);
                saveButton.setEnabled(true);

                // Show success message
                Toast.makeText(ChildFormActivity.this,
                        childId != null ? R.string.child_updated : R.string.child_added,
                        Toast.LENGTH_SHORT).show();

                // Return to children list
                setResult(RESULT_OK);
                finish();
            }

            @Override
            public void onError(String error) {
                // Hide progress and enable save button
                progressBar.setVisibility(View.GONE);
                saveButton.setEnabled(true);

                // Show error message
                Toast.makeText(ChildFormActivity.this,
                        error != null ? error : getString(R.string.error_saving_child),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}