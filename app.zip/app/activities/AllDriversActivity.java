package com.schoolbus.app.activities;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.adapters.DriverAdapter;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.Driver;
import com.schoolbus.app.models.User;
import com.schoolbus.app.utils.Constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AllDriversActivity extends AppCompatActivity implements DriverAdapter.OnDriverClickListener {

    private static final String TAG = "AllDriversActivity";

    private RecyclerView driversRecyclerView;
    private ProgressBar progressBar;
    private TextView noDriversTextView;
    private FloatingActionButton fabAddDriver;

    private FirebaseManager firebaseManager;
    private DriverAdapter driverAdapter;
    private List<Driver> driverList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_drivers);

        // Initialize Firebase manager
        firebaseManager = FirebaseManager.getInstance();

        // Initialize views
        initializeViews();

        // Set up RecyclerView
        setupRecyclerView();

        // Load drivers
        loadDrivers();

        // Set click listener for fab
        fabAddDriver.setOnClickListener(v -> showAddDriverDialog());
    }

    private void initializeViews() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        driversRecyclerView = findViewById(R.id.driversRecyclerView);
        progressBar = findViewById(R.id.progressBar);
        noDriversTextView = findViewById(R.id.noDriversTextView);
        fabAddDriver = findViewById(R.id.fabAddDriver);
    }

    private void setupRecyclerView() {
        driverList = new ArrayList<>();
        driverAdapter = new DriverAdapter(this, driverList, this);
        driversRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        driversRecyclerView.setAdapter(driverAdapter);
    }

    private void loadDrivers() {
        progressBar.setVisibility(View.VISIBLE);

        DatabaseReference usersRef = firebaseManager.getDatabaseReference(Constants.USERS_PATH);

        usersRef.orderByChild("userType").equalTo(Constants.USER_TYPE_DRIVER)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        driverList.clear();

                        for (DataSnapshot driverSnapshot : dataSnapshot.getChildren()) {
                            try {
                                String driverId = driverSnapshot.getKey();
                                String name = driverSnapshot.child("name").getValue(String.class);
                                String email = driverSnapshot.child("email").getValue(String.class);

                                // Try to get phoneNumber, fall back to phone if not found
                                String phoneNumber = driverSnapshot.child("phoneNumber").getValue(String.class);
                                if (phoneNumber == null) {
                                    phoneNumber = driverSnapshot.child("phone").getValue(String.class);
                                }

                                String profileImageUrl = driverSnapshot.child("profileImageUrl").getValue(String.class);
                                String busId = driverSnapshot.child("busId").getValue(String.class);

                                // Log retrieved user data for debugging
                                Log.d(TAG, "Driver data retrieved: " + driverId + ", type: " +
                                        driverSnapshot.child("type").getValue(String.class) +
                                        ", userType: " + driverSnapshot.child("userType").getValue(String.class));

                                Driver driver = new Driver(driverId, name, email, phoneNumber, profileImageUrl);

                                if (busId != null && !busId.isEmpty()) {
                                    driver.setBusId(busId);
                                    loadBusDetails(driver);
                                } else {
                                    driverList.add(driver);
                                }
                            } catch (Exception e) {
                                Log.e(TAG, "Error parsing driver data: " + e.getMessage());
                            }
                        }

                        if (driverList.isEmpty()) {
                            noDriversTextView.setVisibility(View.VISIBLE);
                        } else {
                            noDriversTextView.setVisibility(View.GONE);
                        }

                        driverAdapter.notifyDataSetChanged();
                        progressBar.setVisibility(View.GONE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e(TAG, "Database error: " + databaseError.getMessage());
                        progressBar.setVisibility(View.GONE);
                    }
                });
    }

    private void loadBusDetails(Driver driver) {
        DatabaseReference busRef = firebaseManager.getDatabaseReference(Constants.BUSES_PATH)
                .child(driver.getBusId());

        busRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String busNumber = dataSnapshot.child("busNumber").getValue(String.class);
                    if (busNumber != null) {
                        driver.setBusNumber(busNumber);
                    }
                }

                driverList.add(driver);
                driverAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Error loading bus details: " + databaseError.getMessage());
                driverList.add(driver);
                driverAdapter.notifyDataSetChanged();
            }
        });
    }

    private void showAddDriverDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_driver, null);

        TextInputLayout nameInputLayout = dialogView.findViewById(R.id.nameInputLayout);
        TextInputLayout emailInputLayout = dialogView.findViewById(R.id.emailInputLayout);
        TextInputLayout phoneInputLayout = dialogView.findViewById(R.id.phoneInputLayout);
        TextInputLayout passwordInputLayout = dialogView.findViewById(R.id.passwordInputLayout);
        TextInputLayout confirmPasswordInputLayout = dialogView.findViewById(R.id.confirmPasswordInputLayout);

        TextInputEditText nameEditText = dialogView.findViewById(R.id.nameEditText);
        TextInputEditText emailEditText = dialogView.findViewById(R.id.emailEditText);
        TextInputEditText phoneEditText = dialogView.findViewById(R.id.phoneEditText);
        TextInputEditText passwordEditText = dialogView.findViewById(R.id.passwordEditText);
        TextInputEditText confirmPasswordEditText = dialogView.findViewById(R.id.confirmPasswordEditText);

        Button cancelButton = dialogView.findViewById(R.id.cancelButton);
        Button createButton = dialogView.findViewById(R.id.createButton);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create();

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        createButton.setOnClickListener(v -> {
            // Validate input fields
            boolean isValid = true;

            String name = nameEditText.getText().toString().trim();
            String email = emailEditText.getText().toString().trim();
            String phone = phoneEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString();
            String confirmPassword = confirmPasswordEditText.getText().toString();

            if (TextUtils.isEmpty(name)) {
                nameInputLayout.setError(getString(R.string.required_field));
                isValid = false;
            } else {
                nameInputLayout.setError(null);
            }

            if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                emailInputLayout.setError(getString(R.string.required_field));
                isValid = false;
            } else {
                emailInputLayout.setError(null);
            }

            if (TextUtils.isEmpty(phone)) {
                phoneInputLayout.setError(getString(R.string.required_field));
                isValid = false;
            } else {
                phoneInputLayout.setError(null);
            }

            if (TextUtils.isEmpty(password)) {
                passwordInputLayout.setError(getString(R.string.required_field));
                isValid = false;
            } else {
                passwordInputLayout.setError(null);
            }

            if (!password.equals(confirmPassword)) {
                confirmPasswordInputLayout.setError(getString(R.string.passwords_not_match));
                isValid = false;
            } else {
                confirmPasswordInputLayout.setError(null);
            }

            if (isValid) {
                dialog.dismiss();
                createDriverAccount(name, email, phone, password);
            }
        });

        dialog.show();
    }

    private void createDriverAccount(String name, String email, String phoneNumber, String password) {
        progressBar.setVisibility(View.VISIBLE);

        // Register the user with Firebase Authentication
        firebaseManager.registerUser(email, password, new FirebaseManager.AuthCallback() {
            @Override
            public void onSuccess(String userId) {
                // Create the user profile in the database
                User driver = new User();
                driver.setName(name);
                driver.setEmail(email);
                driver.setPhone(phoneNumber);
                driver.setType(Constants.USER_TYPE_DRIVER);

                // Prepare the data for Firebase update
                Map<String, Object> updates = new HashMap<>();
                updates.put("name", name);
                updates.put("email", email);
                updates.put("phone", phoneNumber);
                updates.put("phoneNumber", phoneNumber);
                updates.put("userType", Constants.USER_TYPE_DRIVER);
                updates.put("type", Constants.USER_TYPE_DRIVER);

                // Log the data being saved to Firebase for debugging
                Log.d("AllDriversActivity", "Creating driver with data: " + updates.toString());

                firebaseManager.getDatabaseReference(Constants.USERS_PATH)
                        .child(userId)
                        .setValue(updates, (error, ref) -> {
                            progressBar.setVisibility(View.GONE);
                            if (error == null) {
                                Toast.makeText(AllDriversActivity.this,
                                        getString(R.string.driver_created_success),
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(AllDriversActivity.this,
                                        getString(R.string.driver_created_error, error.getMessage()),
                                        Toast.LENGTH_LONG).show();
                            }
                        });
            }

            @Override
            public void onError(String errorMessage) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(AllDriversActivity.this,
                        getString(R.string.driver_created_error, errorMessage),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onDriverClick(Driver driver) {
        // Navigate to driver details activity
        Intent intent = new Intent(this, DriverDetailsActivity.class);
        intent.putExtra(DriverDetailsActivity.EXTRA_DRIVER_ID, driver.getId());
        startActivity(intent);
    }
}