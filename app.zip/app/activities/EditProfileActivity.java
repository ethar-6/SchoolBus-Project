package com.schoolbus.app.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.User;
import com.schoolbus.app.utils.PreferenceManager;

import java.util.HashMap;
import java.util.Map;

public class EditProfileActivity extends BaseActivity {

    private TextInputLayout firstNameLayout;
    private TextInputLayout lastNameLayout;
    private TextInputLayout addressLayout;

    private TextInputEditText firstNameEditText;
    private TextInputEditText lastNameEditText;
    private TextInputEditText addressEditText;

    private View saveButton;
    private View progressBar;

    private FirebaseManager firebaseManager;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        // Initialize Firebase and Preferences
        firebaseManager = FirebaseManager.getInstance();
        preferenceManager = PreferenceManager.getInstance(this);

        // Initialize views
        initViews();

        // Set up click listeners
        setupClickListeners();

        // Load user profile
        loadUserProfile();
    }

    private void initViews() {
        firstNameLayout = findViewById(R.id.firstNameLayout);
        lastNameLayout = findViewById(R.id.lastNameLayout);
        addressLayout = findViewById(R.id.addressLayout);

        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        addressEditText = findViewById(R.id.addressEditText);

        saveButton = findViewById(R.id.saveButton);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupClickListeners() {
        saveButton.setOnClickListener(v -> saveProfile());
    }

    private void loadUserProfile() {
        String userId = preferenceManager.getUserId();
        if (userId == null || userId.isEmpty()) {
            showToast(getString(R.string.error_user_not_found));
            finish();
            return;
        }

        firebaseManager.getUserProfile(userId, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    User user = dataSnapshot.getValue(User.class);
                    if (user != null) {
                        updateUI(user);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                showToast(getString(R.string.error_loading_profile));
            }
        });
    }

    private void updateUI(User user) {
        String[] nameParts = user.getName().split(" ", 2);
        firstNameEditText.setText(nameParts[0]);
        lastNameEditText.setText(nameParts.length > 1 ? nameParts[1] : "");
        addressEditText.setText(user.getAddress());
    }

    private void saveProfile() {
        String firstName = firstNameEditText.getText().toString().trim();
        String lastName = lastNameEditText.getText().toString().trim();
        String address = addressEditText.getText().toString().trim();

        // Validate inputs
        if (firstName.isEmpty()) {
            firstNameLayout.setError(getString(R.string.error_first_name_required));
            return;
        }

        if (lastName.isEmpty()) {
            lastNameLayout.setError(getString(R.string.error_last_name_required));
            return;
        }

        if (address.isEmpty()) {
            addressLayout.setError(getString(R.string.error_address_required));
            return;
        }

        // Clear errors
        firstNameLayout.setError(null);
        lastNameLayout.setError(null);
        addressLayout.setError(null);

        // Show progress
        progressBar.setVisibility(View.VISIBLE);
        saveButton.setEnabled(false);

        // Prepare updates
        Map<String, Object> updates = new HashMap<>();
        updates.put("name", firstName + " " + lastName);
        updates.put("address", address);

        // Update profile
        String userId = preferenceManager.getUserId();
        firebaseManager.updateUserProfile(userId, updates, new FirebaseManager.DataCallback<Void>() {
            @Override
            public void onSuccess(Void data) {
                progressBar.setVisibility(View.GONE);
                saveButton.setEnabled(true);
                showToast(getString(R.string.profile_updated_successfully));
                finish();
            }

            @Override
            public void onError(String errorMessage) {
                progressBar.setVisibility(View.GONE);
                saveButton.setEnabled(true);
                showToast(errorMessage);
            }
        });
    }
}