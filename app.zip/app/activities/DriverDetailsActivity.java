package com.schoolbus.app.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.Driver;
import com.schoolbus.app.utils.Constants;

import java.util.HashMap;
import java.util.Map;

public class DriverDetailsActivity extends AppCompatActivity {

    private static final String TAG = "DriverDetailsActivity";
    public static final String EXTRA_DRIVER_ID = "extra_driver_id";

    private Toolbar toolbar;
    private TextInputLayout nameInputLayout;
    private TextInputLayout emailInputLayout;
    private TextInputLayout phoneInputLayout;
    private TextInputEditText nameEditText;
    private TextInputEditText emailEditText;
    private TextInputEditText phoneEditText;
    private TextView driverIdTextView;
    private TextView busAssignedTextView;
    private Button saveButton;
    private Button deleteButton;
    private ProgressBar progressBar;

    private FirebaseManager firebaseManager;
    private String driverId;
    private Driver currentDriver;
    private String assignedBusId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_details);

        // Initialize Firebase
        firebaseManager = FirebaseManager.getInstance();

        // Get driver ID from intent
        driverId = getIntent().getStringExtra(EXTRA_DRIVER_ID);
        if (TextUtils.isEmpty(driverId)) {
            Toast.makeText(this, "Driver ID not provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize views
        initializeViews();

        // Set up toolbar
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.driver_details);
        }

        // Set up click listeners
        setupClickListeners();

        // Load driver data
        loadDriverData();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        nameInputLayout = findViewById(R.id.nameInputLayout);
        emailInputLayout = findViewById(R.id.emailInputLayout);
        phoneInputLayout = findViewById(R.id.phoneInputLayout);
        nameEditText = findViewById(R.id.nameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        driverIdTextView = findViewById(R.id.driverIdTextView);
        busAssignedTextView = findViewById(R.id.busAssignedTextView);
        saveButton = findViewById(R.id.saveButton);
        deleteButton = findViewById(R.id.deleteButton);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupClickListeners() {
        saveButton.setOnClickListener(v -> validateAndUpdateDriver());
        deleteButton.setOnClickListener(v -> confirmDeleteDriver());

        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void loadDriverData() {
        showLoading(true);

        // Load driver from Firebase
        DatabaseReference driverRef = firebaseManager.getDatabaseReference(Constants.USERS_PATH).child(driverId);
        driverRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                showLoading(false);

                if (dataSnapshot.exists()) {
                    try {
                        String name = dataSnapshot.child("name").getValue(String.class);
                        String email = dataSnapshot.child("email").getValue(String.class);

                        // Try to get phoneNumber, fall back to phone if not found
                        String phoneNumber = dataSnapshot.child("phoneNumber").getValue(String.class);
                        if (phoneNumber == null) {
                            phoneNumber = dataSnapshot.child("phone").getValue(String.class);
                        }

                        String profileImageUrl = dataSnapshot.child("profileImageUrl").getValue(String.class);
                        assignedBusId = dataSnapshot.child("busId").getValue(String.class);

                        currentDriver = new Driver(driverId, name, email, phoneNumber, profileImageUrl);

                        if (assignedBusId != null && !assignedBusId.isEmpty()) {
                            currentDriver.setBusId(assignedBusId);
                            loadBusDetails();
                        } else {
                            busAssignedTextView.setText(R.string.no_bus_assigned);
                        }

                        // Set driver data to views
                        populateDriverData();

                    } catch (Exception e) {
                        Log.e(TAG, "Error parsing driver data: " + e.getMessage());
                        Toast.makeText(DriverDetailsActivity.this, "Error loading driver data", Toast.LENGTH_SHORT)
                                .show();
                    }
                } else {
                    Toast.makeText(DriverDetailsActivity.this, "Driver not found", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                showLoading(false);
                Log.e(TAG, "Database error: " + databaseError.getMessage());
                Toast.makeText(DriverDetailsActivity.this, "Error loading driver data: " + databaseError.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadBusDetails() {
        DatabaseReference busRef = firebaseManager.getDatabaseReference(Constants.BUSES_PATH).child(assignedBusId);
        busRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String busNumber = dataSnapshot.child("busNumber").getValue(String.class);
                    if (busNumber != null) {
                        currentDriver.setBusNumber(busNumber);
                        busAssignedTextView.setText(getString(R.string.bus_assigned, busNumber));
                    } else {
                        busAssignedTextView.setText(R.string.no_bus_assigned);
                    }
                } else {
                    busAssignedTextView.setText(R.string.no_bus_assigned);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Error loading bus details: " + databaseError.getMessage());
                busAssignedTextView.setText(R.string.no_bus_assigned);
            }
        });
    }

    private void populateDriverData() {
        if (currentDriver == null)
            return;

        nameEditText.setText(currentDriver.getName());
        emailEditText.setText(currentDriver.getEmail());
        phoneEditText.setText(currentDriver.getPhoneNumber());
        driverIdTextView.setText(getString(R.string.driver_id, currentDriver.getId()));

        if (currentDriver.hasBusAssigned() && currentDriver.getBusNumber() != null) {
            busAssignedTextView.setText(getString(R.string.bus_assigned, currentDriver.getBusNumber()));
        } else {
            busAssignedTextView.setText(R.string.no_bus_assigned);
        }
    }

    private void validateAndUpdateDriver() {
        // Reset errors
        emailInputLayout.setError(null);
        phoneInputLayout.setError(null);

        // Get values
        String email = emailEditText.getText().toString().trim();
        String phone = phoneEditText.getText().toString().trim();

        // Validate
        boolean isValid = true;

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInputLayout.setError(getString(R.string.error_email_required));
            isValid = false;
        }

        if (TextUtils.isEmpty(phone)) {
            phoneInputLayout.setError(getString(R.string.error_phone_required));
            isValid = false;
        }

        if (isValid) {
            updateDriverInfo(email, phone);
        }
    }

    private void updateDriverInfo(String email, String phone) {
        showLoading(true);

        Map<String, Object> updates = new HashMap<>();
        updates.put("email", email);
        updates.put("phone", phone);
        updates.put("phoneNumber", phone); // For consistency

        // Update driver in Firebase
        DatabaseReference driverRef = firebaseManager.getDatabaseReference(Constants.USERS_PATH).child(driverId);
        driverRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    showLoading(false);
                    Toast.makeText(DriverDetailsActivity.this, R.string.driver_updated, Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    showLoading(false);
                    Log.e(TAG, "Error updating driver: " + e.getMessage());
                    Toast.makeText(DriverDetailsActivity.this, "Error updating driver: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void confirmDeleteDriver() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_driver)
                .setMessage(R.string.confirm_delete_driver)
                .setPositiveButton(android.R.string.yes, (dialog, which) -> deleteDriver())
                .setNegativeButton(android.R.string.no, null)
                .show();
    }

    private void deleteDriver() {
        showLoading(true);

        // First, update any assigned bus to remove the driver
        if (assignedBusId != null && !assignedBusId.isEmpty()) {
            updateBusDriverAssignment(assignedBusId, () -> {
                // After updating bus, delete the driver
                performDriverDeletion();
            });
        } else {
            // No bus assigned, just delete the driver
            performDriverDeletion();
        }
    }

    private void updateBusDriverAssignment(String busId, Runnable onComplete) {
        DatabaseReference busRef = firebaseManager.getDatabaseReference(Constants.BUSES_PATH).child(busId);

        // Remove driver assignment from bus
        Map<String, Object> updates = new HashMap<>();
        updates.put("driverId", null);

        busRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Bus driver assignment removed successfully");
                    if (onComplete != null) {
                        onComplete.run();
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error updating bus driver assignment: " + e.getMessage());
                    showLoading(false);
                    Toast.makeText(DriverDetailsActivity.this,
                            "Error updating bus assignment: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void performDriverDeletion() {
        // Delete from authentication system
        // Note: In a real application, you would need to re-authenticate the user
        // before deleting their account
        // For simplicity, we're just deleting the database record here

        // Delete driver from database
        DatabaseReference driverRef = firebaseManager.getDatabaseReference(Constants.USERS_PATH).child(driverId);
        driverRef.removeValue()
                .addOnSuccessListener(aVoid -> {
                    showLoading(false);
                    Toast.makeText(DriverDetailsActivity.this, R.string.driver_deleted, Toast.LENGTH_SHORT).show();
                    finish(); // Go back to the previous screen
                })
                .addOnFailureListener(e -> {
                    showLoading(false);
                    Log.e(TAG, "Error deleting driver: " + e.getMessage());
                    Toast.makeText(DriverDetailsActivity.this,
                            "Error deleting driver: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void showLoading(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        saveButton.setEnabled(!isLoading);
        deleteButton.setEnabled(!isLoading);
    }
}