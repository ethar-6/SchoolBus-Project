package com.schoolbus.app.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.adapters.DriverStudentAdapter;
import com.schoolbus.app.models.Attendance;
import com.schoolbus.app.models.Bus;
import com.schoolbus.app.models.Route;
import com.schoolbus.app.models.Student;
import com.schoolbus.app.models.User;
import com.schoolbus.app.services.LocationService;
import com.schoolbus.app.utils.Constants;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class DriverDashboardActivity extends BaseActivity {
    private static final String TAG = "DriverDashboard"; // Consistent tag for logging
    
    private Toolbar toolbar;
    private TextView busIdTextView;
    private TextView busNumberTextView;
    private TextView routeIdTextView;
    private TextView routeNameTextView;
    private TextView busStatusTextView;
    private SwitchCompat busStatusSwitch;
    private Button saveAttendanceButton;
    private Button chatButton;
    private RecyclerView studentsRecyclerView;
    private DriverStudentAdapter studentAdapter;
    private List<Student> studentList;
    private User currentDriver;
    private String assignedBusId;
    private Bus assignedBus;
    private Route assignedRoute;

    // Constants for bus status
    private static final String STATUS_ACTIVE = "active";
    private static final String STATUS_INACTIVE = "inactive";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = Constants.LOCATION_PERMISSION_REQUEST_CODE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_dashboard);
        Log.d(TAG, "onCreate: Initializing Driver Dashboard");

        // Initialize views
        initViews();

        // Set up toolbar
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.driver_dashboard);
        }

        // Set up students list
        setupStudentsList();

        // Load driver data
        loadDriverData();

        // Set click listeners
        setClickListeners();
        
        // We'll check location permissions after we have the driver and bus data
    }
    
    private void checkLocationPermission() {
        Log.d(TAG, "checkLocationPermission: Checking location permissions");
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "checkLocationPermission: Permission not granted, requesting permission");
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            // Permission already granted, save location
            Log.d(TAG, "checkLocationPermission: Permission already granted, saving location");
            saveDriverLocation();
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, save location
                Log.d(TAG, "onRequestPermissionsResult: Location permission granted");
                saveDriverLocation();
            } else {
                Log.w(TAG, "onRequestPermissionsResult: Location permission denied");
                showToast("Location permission denied. Parents will not be able to track the bus.");
            }
        }
    }
    
    private void saveDriverLocation() {
        Log.d(TAG, "saveDriverLocation: Attempting to save driver location");
        if (currentDriver != null && currentDriver.getId() != null) {
            Log.d(TAG, "saveDriverLocation: Driver ID: " + currentDriver.getId());
            
            // Dump all driver data for debugging
            Log.d(TAG, "saveDriverLocation: Driver Data - Name: " + currentDriver.getName() + 
                  ", Email: " + currentDriver.getEmail() + 
                  ", Type: " + currentDriver.getType() + 
                  ", BusId in user model: " + currentDriver.getBusId());
            
            // Determine the busId to use - prefer the assigned bus from the dashboard
            String tempBusId = assignedBusId;
            
            // If we don't have an assigned bus from the dashboard, try the user model
            if (tempBusId == null || tempBusId.isEmpty()) {
                tempBusId = currentDriver.getBusId();
                Log.d(TAG, "saveDriverLocation: No assigned bus from dashboard, using busId from user model: " + tempBusId);
            } else {
                Log.d(TAG, "saveDriverLocation: Using assigned bus from dashboard: " + tempBusId);
            }
            
            // Make sure we have a bus ID - use a final variable for the anonymous inner class
            final String busIdToUse = tempBusId;
            if (busIdToUse != null && !busIdToUse.isEmpty()) {
                // Verify the bus ID exists
                Log.d(TAG, "saveDriverLocation: Verifying bus ID: " + busIdToUse);
                
                firebaseManager.getDatabaseReference(Constants.BUSES_PATH)
                        .child(busIdToUse)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    Log.d(TAG, "saveDriverLocation: Verified bus ID exists: " + busIdToUse);
                                    Bus bus = dataSnapshot.getValue(Bus.class);
                                    if (bus != null) {
                                        Log.d(TAG, "saveDriverLocation: Bus data - Number: " + bus.getBusNumber() + ", Status: " + bus.getStatus());
                                    
                                        // Ensure bus has the correct driver ID
                                        if (bus.getDriverId() == null || !bus.getDriverId().equals(currentDriver.getId())) {
                                            Log.d(TAG, "saveDriverLocation: Bus has incorrect driverId: " + bus.getDriverId() + 
                                                  ", updating to: " + currentDriver.getId());
                                            updateBusDriverAssignment(busIdToUse, currentDriver.getId(), currentDriver.getName());
                                        }
                                    }
                                    
                                    // Save driver location with this bus ID
                                    LocationService.saveDriverLocation(currentDriver.getId(), busIdToUse, DriverDashboardActivity.this);
                                    Log.d(TAG, "saveDriverLocation: Saved driver location with busId: " + busIdToUse);
                                    
                                    // Ensure we have this bus loaded to display in the UI
                                    if (assignedBusId == null || !assignedBusId.equals(busIdToUse)) {
                                        Log.d(TAG, "saveDriverLocation: Loading bus for UI: " + busIdToUse);
                                        assignedBusId = busIdToUse;
                                        loadBusDirectly(busIdToUse);
                                    }
                                    
                                } else {
                                    Log.w(TAG, "saveDriverLocation: Bus ID " + busIdToUse + " does not exist in the database");
                                    
                                    // Try to find a bus with this driver ID
                                    findBusForDriver(currentDriver.getId());
                                    
                                    // Clear the invalid bus ID from the user model
                                    if (currentDriver.getBusId() != null && currentDriver.getBusId().equals(busIdToUse)) {
                                        Log.d(TAG, "saveDriverLocation: Clearing invalid busId from driver record: " + busIdToUse);
                                        updateDriverBusAssignment(currentDriver.getId(), "", "");
                                        currentDriver.setBusId("");
                                        currentDriver.setBusNumber("");
                                        preferenceManager.saveUser(currentDriver);
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Log.e(TAG, "saveDriverLocation: Failed to verify bus: " + databaseError.getMessage());
                            }
                        });
            } else {
                Log.w(TAG, "saveDriverLocation: No busId available to save location");
                // Try to find a bus assigned to this driver
                findBusForDriver(currentDriver.getId());
            }
        } else {
            Log.e(TAG, "saveDriverLocation: Cannot save location - driver info missing");
        }
    }
    
    /**
     * Find a bus assigned to this driver
     */
    private void findBusForDriver(String driverId) {
        Log.d(TAG, "findBusForDriver: Looking for a bus assigned to driver: " + driverId);
        
        firebaseManager.getDatabaseReference(Constants.BUSES_PATH)
            .orderByChild("driverId")
            .equalTo(driverId)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        Log.d(TAG, "findBusForDriver: Found bus(es) assigned to driver");
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            String busId = snapshot.getKey();
                            Log.d(TAG, "findBusForDriver: Found bus: " + busId);
                            
                            Bus bus = snapshot.getValue(Bus.class);
                            if (bus != null) {
                                bus.setId(busId);
                                Log.d(TAG, "findBusForDriver: Bus details - Number: " + bus.getBusNumber());
                                
                                // Update driver record with this bus
                                updateDriverBusAssignment(driverId, busId, bus.getBusNumber());
                                currentDriver.setBusId(busId);
                                currentDriver.setBusNumber(bus.getBusNumber());
                                preferenceManager.saveUser(currentDriver);
                                
                                // Load this bus for the UI
                                assignedBusId = busId;
                                assignedBus = bus;
                                updateBusUI(bus);
                                loadStudentsForBus(busId);
                                
                                // Save location
                                LocationService.saveDriverLocation(driverId, busId, DriverDashboardActivity.this);
                                
                                break; // Just use the first bus found
                            }
                        }
                    } else {
                        Log.w(TAG, "findBusForDriver: No buses found assigned to driver");
                        handleNoBusAssigned();
                    }
                }
                
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e(TAG, "findBusForDriver: Error: " + databaseError.getMessage());
                }
            });
    }
    
    // Helper method to directly check if a bus exists in the bus_locations node
    private void checkBusInLocationsNode(String busId) {
        Log.d(TAG, "checkBusInLocationsNode: Checking if bus exists in bus_locations: " + busId);
        firebaseManager.getDatabaseReference("bus_locations")
            .child(busId)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        Log.d(TAG, "checkBusInLocationsNode: Bus found in bus_locations: " + busId);
                        Log.d(TAG, "checkBusInLocationsNode: Data: " + dataSnapshot.getValue().toString());
                        
                        // Create a minimal bus object and load it
                        Bus bus = new Bus();
                        bus.setId(busId);
                        bus.setBusNumber("Bus #" + busId.substring(0, Math.min(busId.length(), 5)));
                        bus.setStatus(STATUS_ACTIVE);
                        
                        // Set location data if available
                        try {
                            Double latitude = null;
                            Double longitude = null;
                            
                            if (dataSnapshot.hasChild("latitude")) {
                                latitude = dataSnapshot.child("latitude").getValue(Double.class);
                            } else if (dataSnapshot.hasChild("lat")) {
                                latitude = dataSnapshot.child("lat").getValue(Double.class);
                            }
                            
                            if (dataSnapshot.hasChild("longitude")) {
                                longitude = dataSnapshot.child("longitude").getValue(Double.class);
                            } else if (dataSnapshot.hasChild("lng")) {
                                longitude = dataSnapshot.child("lng").getValue(Double.class);
                            }
                            
                            if (latitude != null && longitude != null) {
                                Bus.Location location = new Bus.Location();
                                location.setLatitude(latitude);
                                location.setLongitude(longitude);
                                location.setLastUpdated(System.currentTimeMillis());
                                bus.setCurrentLocation(location);
                                Log.d(TAG, "checkBusInLocationsNode: Created location object - lat: " + latitude + ", lng: " + longitude);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "checkBusInLocationsNode: Error parsing location data: " + e.getMessage());
                        }
                        
                        // Update UI with this bus
                        assignedBus = bus;
                        assignedBusId = busId;
                        
                        // Update UI
                        updateBusUI(bus);
                        
                        // Load students for this bus
                        loadStudentsForBus(busId);
                    } else {
                        Log.w(TAG, "checkBusInLocationsNode: Bus not found in bus_locations: " + busId);
                    }
                }
                
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e(TAG, "checkBusInLocationsNode: Error: " + databaseError.getMessage());
                }
            });
    }
    
    // Helper method to directly load a bus by ID
    private void loadBusDirectly(String busId) {
        Log.d(TAG, "loadBusDirectly: Loading bus with ID: " + busId);
        
        firebaseManager.getDatabaseReference(Constants.BUSES_PATH)
            .child(busId)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        Bus bus = dataSnapshot.getValue(Bus.class);
                        if (bus != null) {
                            Log.d(TAG, "loadBusDirectly: Successfully loaded bus: " + bus.getBusNumber());
                            bus.setId(busId);
                            assignedBus = bus;
                            assignedBusId = busId;
                            
                            // Verify that the driverId in the bus matches the current driver
                            if (currentDriver != null && (bus.getDriverId() == null || !currentDriver.getId().equals(bus.getDriverId()))) {
                                Log.d(TAG, "loadBusDirectly: Bus has incorrect driverId: " + bus.getDriverId() + 
                                      ", updating to: " + currentDriver.getId());
                                // Update the bus with the correct driver ID
                                updateBusDriverAssignment(busId, currentDriver.getId(), currentDriver.getName());
                            }
                            
                            // Update UI
                            updateBusUI(bus);
                            
                            // If the bus has a route ID, load the route details
                            if (bus.getRouteId() != null && !bus.getRouteId().isEmpty()) {
                                Log.d(TAG, "loadBusDirectly: Bus has route ID: " + bus.getRouteId());
                                routeIdTextView.setText(bus.getRouteId());
                                loadRouteForBus(bus.getRouteId());
                            } else {
                                Log.d(TAG, "loadBusDirectly: Bus has no route ID");
                                routeIdTextView.setText("Not assigned");
                                routeNameTextView.setText(R.string.no_route_assigned);
                                saveAttendanceButton.setEnabled(false);
                            }
                            
                            // Load students for this bus
                            loadStudentsForBus(busId);
                            
                            // IMPORTANT: Update the user model if busId doesn't match
                            if (currentDriver != null && 
                               (currentDriver.getBusId() == null || !currentDriver.getBusId().equals(busId))) {
                                Log.d(TAG, "loadBusDirectly: Updating driver's busId in database from " + 
                                      currentDriver.getBusId() + " to " + busId);
                                
                                // Update driver's busId in the database and preferences
                                updateDriverBusAssignment(currentDriver.getId(), busId, bus.getBusNumber());
                                currentDriver.setBusId(busId);
                                currentDriver.setBusNumber(bus.getBusNumber());
                                preferenceManager.saveUser(currentDriver);
                            }
                        } else {
                            Log.e(TAG, "loadBusDirectly: Failed to parse bus data");
                        }
                    } else {
                        Log.e(TAG, "loadBusDirectly: Bus not found with ID: " + busId);
                        
                        // If this busId came from the driver model but doesn't exist, clear it
                        if (currentDriver != null && busId.equals(currentDriver.getBusId())) {
                            Log.w(TAG, "loadBusDirectly: Clearing invalid busId from driver record");
                            updateDriverBusAssignment(currentDriver.getId(), "", "");
                            currentDriver.setBusId("");
                            currentDriver.setBusNumber("");
                            preferenceManager.saveUser(currentDriver);
                        }
                        
                        // Try to check if bus exists in bus_locations
                        checkBusInLocationsNode(busId);
                    }
                }
                
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e(TAG, "loadBusDirectly: Error: " + databaseError.getMessage());
                }
            });
    }
    
    /**
     * Update bus with driver assignment
     */
    private void updateBusDriverAssignment(String busId, String driverId, String driverName) {
        DatabaseReference busRef = firebaseManager.getDatabaseReference(Constants.BUSES_PATH).child(busId);
        
        Map<String, Object> updates = new HashMap<>();
        updates.put("driverId", driverId);
        updates.put("driverName", driverName);
        
        busRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "updateBusDriverAssignment: Successfully updated bus " + busId + " with driverId " + driverId);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "updateBusDriverAssignment: Error updating bus " + busId + ": " + e.getMessage());
                });
    }
    
    // Helper method to update bus UI
    private void updateBusUI(Bus bus) {
        Log.d(TAG, "updateBusUI: Updating UI with bus: " + bus.getId() + ", Number: " + bus.getBusNumber());
        
        busIdTextView.setText(bus.getId());
        busNumberTextView.setText(bus.getBusNumber());
        
        // Update status UI
        String status = bus.getStatus();
        if (status == null || status.isEmpty()) {
            status = STATUS_ACTIVE; // Default to active
        }
        updateBusStatusUI(status);
    }

    private void initViews() {
        Log.d(TAG, "initViews: Initializing views");
        toolbar = findViewById(R.id.toolbar);
        busIdTextView = findViewById(R.id.busIdTextView);
        busNumberTextView = findViewById(R.id.busNumberTextView);
        routeIdTextView = findViewById(R.id.routeIdTextView);
        routeNameTextView = findViewById(R.id.routeNameTextView);
        busStatusTextView = findViewById(R.id.busStatusTextView);
        busStatusSwitch = findViewById(R.id.busStatusSwitch);
        saveAttendanceButton = findViewById(R.id.saveAttendanceButton);
        chatButton = findViewById(R.id.chatButton);
        studentsRecyclerView = findViewById(R.id.studentsRecyclerView);
    }

    private void setupStudentsList() {
        Log.d(TAG, "setupStudentsList: Setting up students RecyclerView");
        studentList = new ArrayList<>();
        studentAdapter = new DriverStudentAdapter(studentList);
        studentsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        studentsRecyclerView.setAdapter(studentAdapter);
    }

    private void setClickListeners() {
        Log.d(TAG, "setClickListeners: Setting up click listeners");
        saveAttendanceButton.setOnClickListener(v -> {
            saveAttendance();
        });

        chatButton.setOnClickListener(v -> {
            Intent intent = new Intent(DriverDashboardActivity.this, ChatListActivity.class);
            startActivity(intent);
        });

        busStatusSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (assignedBus != null) {
                updateBusStatus(isChecked);
            }
        });
    }

    private void updateBusStatus(boolean isActive) {
        Log.d(TAG, "updateBusStatus: Updating bus status to: " + (isActive ? "Active" : "Inactive"));
        if (assignedBusId == null) {
            Log.w(TAG, "updateBusStatus: No bus assigned, cannot update status");
            showToast("No bus assigned");
            return;
        }

        // Show a loading dialog
        android.app.ProgressDialog progressDialog = new android.app.ProgressDialog(this);
        progressDialog.setMessage("Updating bus status...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        // Update status in Firebase
        String newStatus = isActive ? STATUS_ACTIVE : STATUS_INACTIVE;
        Log.d(TAG, "updateBusStatus: Setting status to: " + newStatus + " for bus: " + assignedBusId);

        Map<String, Object> updates = new HashMap<>();
        updates.put("status", newStatus);

        firebaseManager.getDatabaseReference(Constants.BUSES_PATH)
                .child(assignedBusId)
                .updateChildren(updates)
                .addOnCompleteListener(task -> {
                    progressDialog.dismiss();
                    if (task.isSuccessful()) {
                        // Update local bus object
                        Log.d(TAG, "updateBusStatus: Successfully updated bus status");
                        assignedBus.setStatus(newStatus);
                        updateBusStatusUI(newStatus);
                        showToast("Bus status updated to " + (isActive ? "Active" : "Inactive"));
                    } else {
                        // Revert switch to previous state
                        Log.e(TAG, "updateBusStatus: Failed to update bus status: " + 
                              (task.getException() != null ? task.getException().getMessage() : "Unknown error"));
                        busStatusSwitch.setChecked(!isActive);
                        showToast("Failed to update bus status");
                    }
                });
    }

    private void updateBusStatusUI(String status) {
        boolean isActive = STATUS_ACTIVE.equals(status);
        Log.d(TAG, "updateBusStatusUI: Updating status UI to: " + (isActive ? "Active" : "Inactive"));
        busStatusTextView.setText(isActive ? "Active" : "Inactive");
        busStatusTextView.setTextColor(getResources().getColor(
                isActive ? android.R.color.holo_green_dark : android.R.color.holo_red_dark));
        busStatusSwitch.setChecked(isActive);
    }

    private void saveAttendance() {
        if (studentList.isEmpty()) {
            showToast("No students to mark attendance for");
            return;
        }

        if (assignedBusId == null) {
            showToast("No bus assigned");
            return;
        }

        // Show a loading dialog
        android.app.ProgressDialog progressDialog = new android.app.ProgressDialog(this);
        progressDialog.setMessage("Saving attendance...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        List<Student> updatedStudentList = studentAdapter.getStudentList();

        // Get current date and time
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        String formattedDate;
        String formattedTime;
        long timestamp = currentDate.getTime();

        try {
            formattedDate = dateFormat.format(currentDate);
            formattedTime = timeFormat.format(currentDate);
        } catch (Exception e) {
            // In case of date formatting error
            formattedDate = String.valueOf(currentDate);
            formattedTime = "";
            showToast("Error formatting date: " + e.getMessage());
        }

        // Reference to the attendance node
        DatabaseReference attendanceRef = firebaseManager.getDatabaseReference(Constants.ATTENDANCE_PATH);

        // Create a batch of attendance records
        Map<String, Object> attendanceUpdates = new HashMap<>();

        for (Student student : updatedStudentList) {
            // Create attendance object
            String status = student.isPresent() ? Constants.ATTENDANCE_STATUS_PRESENT
                    : Constants.ATTENDANCE_STATUS_ABSENT;

            Attendance attendance = new Attendance(
                    student.getId(),
                    student.getName(),
                    assignedBusId,
                    currentDriver.getId(),
                    status,
                    timestamp,
                    formattedDate,
                    formattedTime);

            // Generate a unique key for this attendance record
            String attendanceId = attendanceRef.push().getKey();
            if (attendanceId != null) {
                attendanceUpdates.put("/" + attendanceId, attendance);
            }
        }

        // Save all attendance records in one batch
        if (!attendanceUpdates.isEmpty()) {
            attendanceRef.updateChildren(attendanceUpdates)
                    .addOnCompleteListener(task -> {
                        progressDialog.dismiss();
                        if (task.isSuccessful()) {
                            showToast(getString(R.string.attendance_saved));
                        } else {
                            String errorMessage = "Failed to save attendance";
                            if (task.getException() != null) {
                                errorMessage += ": " + task.getException().getMessage();
                            }
                            showToast(errorMessage);
                        }
                    });
        } else {
            progressDialog.dismiss();
            showToast("No attendance records to save");
        }
    }

    private void loadDriverData() {
        Log.d(TAG, "loadDriverData: Loading driver data from preferences");
        // Get current user from preferences
        currentDriver = preferenceManager.getUser();
        if (currentDriver == null) {
            Log.e(TAG, "loadDriverData: Driver data not found in preferences");
            showToast("Driver data not found");
            logout();
            return;
        }
        
        // Log all driver data for debugging
        Log.d(TAG, "loadDriverData: Driver ID: " + currentDriver.getId());
        Log.d(TAG, "loadDriverData: Driver Name: " + currentDriver.getName());
        Log.d(TAG, "loadDriverData: Driver Email: " + currentDriver.getEmail());
        Log.d(TAG, "loadDriverData: Driver Type: " + currentDriver.getType());
        Log.d(TAG, "loadDriverData: Driver BusId: " + currentDriver.getBusId());
        
        // Check if we have Firebase ID
        if (currentDriver.getId() == null) {
            // Get ID from Firebase auth
            if (firebaseManager.getCurrentUser() != null) {
                currentDriver.setId(firebaseManager.getCurrentUser().getUid());
                Log.d(TAG, "loadDriverData: Set driver ID from Firebase Auth: " + currentDriver.getId());
            } else {
                Log.e(TAG, "loadDriverData: No Firebase user ID available");
            }
        }

        // Check if we already have busId in the user model
        if (currentDriver.getBusId() != null && !currentDriver.getBusId().isEmpty()) {
            Log.d(TAG, "loadDriverData: Driver has busId in user model: " + currentDriver.getBusId());
            // We can proceed with saving location right away
            if (ContextCompat.checkSelfPermission(this, 
                    Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                saveDriverLocation();
            } else {
                checkLocationPermission();
            }
        } else {
            Log.d(TAG, "loadDriverData: Driver has no busId in user model");
        }

        // Load assigned bus (this will set assignedBusId for cases where it's not in the user model)
        loadAssignedBus();
    }

    private void loadAssignedBus() {
        if (currentDriver == null || currentDriver.getId() == null) {
            Log.e(TAG, "loadAssignedBus: Cannot load bus - driver ID is null");
            return;
        }
        
        Log.d(TAG, "loadAssignedBus: Querying buses for driver ID: " + currentDriver.getId());
        
        // Query the buses to find one assigned to this driver
        DatabaseReference busesRef = firebaseManager.getDatabaseReference(Constants.BUSES_PATH);
        Log.d(TAG, "loadAssignedBus: Database reference path: " + busesRef.toString());
        
        busesRef.orderByChild("driverId")
                .equalTo(currentDriver.getId())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Log.d(TAG, "loadAssignedBus: Query complete, dataSnapshot exists: " + dataSnapshot.exists());
                        Log.d(TAG, "loadAssignedBus: Child count: " + dataSnapshot.getChildrenCount());
                        
                        if (dataSnapshot.exists()) {
                            boolean foundBus = false;
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                Log.d(TAG, "loadAssignedBus: Found bus with key: " + snapshot.getKey());
                                Bus bus = snapshot.getValue(Bus.class);
                                if (bus != null) {
                                    foundBus = true;
                                    bus.setId(snapshot.getKey());
                                    assignedBusId = bus.getId();
                                    assignedBus = bus;
                                    
                                    Log.d(TAG, "loadAssignedBus: Bus details - Number: " + bus.getBusNumber() + 
                                          ", DriverId: " + bus.getDriverId() +
                                          ", RouteId: " + bus.getRouteId() +
                                          ", Status: " + bus.getStatus());

                                    // Update bus details
                                    busIdTextView.setText(bus.getId());
                                    busNumberTextView.setText(bus.getBusNumber());

                                    // Update bus status UI
                                    updateBusStatusUI(bus.getStatus());

                                    // If the bus has a route ID, load the route details
                                    if (bus.getRouteId() != null && !bus.getRouteId().isEmpty()) {
                                        Log.d(TAG, "loadAssignedBus: Loading route details for routeId: " + bus.getRouteId());
                                        routeIdTextView.setText(bus.getRouteId());
                                        loadRouteForBus(bus.getRouteId());
                                    } else {
                                        Log.d(TAG, "loadAssignedBus: No route assigned to this bus");
                                        routeIdTextView.setText("Not assigned");
                                        routeNameTextView.setText(R.string.no_route_assigned);
                                        saveAttendanceButton.setEnabled(false);
                                    }

                                    // Load students for this bus
                                    loadStudentsForBus(assignedBusId);
                                    
                                    // IMPORTANT: Update the user model if busId doesn't match
                                    if (currentDriver.getBusId() == null || !currentDriver.getBusId().equals(assignedBusId)) {
                                        Log.d(TAG, "loadAssignedBus: Updating driver's busId in database from " + 
                                              currentDriver.getBusId() + " to " + assignedBusId);
                                        
                                        // Update driver's busId in the database
                                        updateDriverBusAssignment(currentDriver.getId(), assignedBusId, bus.getBusNumber());
                                        
                                        // Also update the local model and save to preferences
                                        currentDriver.setBusId(assignedBusId);
                                        currentDriver.setBusNumber(bus.getBusNumber());
                                        preferenceManager.saveUser(currentDriver);
                                    }
                                    
                                    // Now that we have the assigned bus, we can try to save location
                                    if (ContextCompat.checkSelfPermission(DriverDashboardActivity.this, 
                                            Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                                        saveDriverLocation();
                                    } else {
                                        checkLocationPermission();
                                    }
                                    
                                    break;
                                } else {
                                    Log.e(TAG, "loadAssignedBus: Failed to parse bus data for key: " + snapshot.getKey());
                                }
                            }
                            
                            if (!foundBus) {
                                Log.w(TAG, "loadAssignedBus: No valid bus found for driver despite dataSnapshot existing");
                                handleNoBusAssigned();
                            }
                        } else {
                            Log.w(TAG, "loadAssignedBus: No buses found assigned to driver ID: " + currentDriver.getId());
                            
                            // If driver has busId in user model, try to load that directly
                            if (currentDriver.getBusId() != null && !currentDriver.getBusId().isEmpty()) {
                                Log.d(TAG, "loadAssignedBus: No bus found in query, but driver has busId in model. Trying direct load: " + currentDriver.getBusId());
                                loadBusDirectly(currentDriver.getBusId());
                            } else {
                                handleNoBusAssigned();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e(TAG, "loadAssignedBus: Error loading bus data: " + databaseError.getMessage());
                        showToast("Error loading bus data: " + databaseError.getMessage());
                    }
                });
    }
    
    /**
     * Update driver's busId in the database to ensure consistency between the user and bus records
     */
    private void updateDriverBusAssignment(String driverId, String busId, String busNumber) {
        DatabaseReference driverRef = firebaseManager.getDatabaseReference(Constants.USERS_PATH).child(driverId);
        
        Map<String, Object> updates = new HashMap<>();
        updates.put("busId", busId);
        updates.put("busNumber", busNumber);
        
        driverRef.updateChildren(updates)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "updateDriverBusAssignment: Successfully updated driver " + driverId + " with busId " + busId);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "updateDriverBusAssignment: Error updating driver " + driverId + ": " + e.getMessage());
                });
    }
    
    private void handleNoBusAssigned() {
        Log.w(TAG, "handleNoBusAssigned: Setting UI for no bus assigned case");
        busIdTextView.setText("Not assigned");
        busNumberTextView.setText(R.string.no_bus_assigned);
        routeIdTextView.setText("Not assigned");
        routeNameTextView.setText(R.string.no_route_assigned);
        saveAttendanceButton.setEnabled(false);
        showToast("No bus assigned to this driver. Location tracking disabled.");
    }

    private void loadRouteForBus(String routeId) {
        firebaseManager.getDatabaseReference(Constants.ROUTES_PATH)
                .child(routeId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            Route route = dataSnapshot.getValue(Route.class);
                            if (route != null) {
                                route.setId(routeId);
                                assignedRoute = route;
                                routeNameTextView.setText(route.getName());
                            } else {
                                routeNameTextView.setText(R.string.no_route_assigned);
                            }
                        } else {
                            routeNameTextView.setText(R.string.no_route_assigned);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        showToast("Error loading route data: " + databaseError.getMessage());
                    }
                });
    }

    private void loadStudentsForBus(String busId) {
        // Get students assigned to the bus that the driver is responsible for
        studentList.clear();

        if (busId == null) {
            Log.w(TAG, "loadStudentsForBus: No bus ID provided, cannot load students");
            showToast("No bus assigned");
            return;
        }

        // Log the bus ID for debugging
        Log.d(TAG, "loadStudentsForBus: Loading students for bus ID: " + busId);
        
        // First, check if we can find the bus in Firebase directly
        firebaseManager.getDatabaseReference(Constants.BUSES_PATH)
            .child(busId)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        Log.d(TAG, "loadStudentsForBus: Found bus in database: " + busId);
                        Bus bus = dataSnapshot.getValue(Bus.class);
                        if (bus != null) {
                            Log.d(TAG, "loadStudentsForBus: Bus details - Number: " + bus.getBusNumber() + 
                                  ", Status: " + bus.getStatus() + 
                                  ", DriverId: " + bus.getDriverId());
                        }
                    } else {
                        Log.w(TAG, "loadStudentsForBus: Bus not found in buses collection: " + busId);
                    }
                }
                
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e(TAG, "loadStudentsForBus: Error checking bus: " + databaseError.getMessage());
                }
            });

        // Load students by busId instead of routeId
        // Look for children of parents who have their busId set to this driver's bus
        Log.d(TAG, "loadStudentsForBus: Querying all parent users to find children with busId: " + busId);
        firebaseManager.getDatabaseReference(Constants.USERS_PATH)
                .orderByChild("type")
                .equalTo("parent")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        studentList.clear();
                        boolean foundAny = false;
                        
                        Log.d(TAG, "loadStudentsForBus: Found " + dataSnapshot.getChildrenCount() + " parent users");
                        
                        if (dataSnapshot.exists()) {
                            int parentCount = 0;
                            int childrenCount = 0;
                            int missingBusIdCount = 0;
                            int mismatchedBusIdCount = 0;
                            
                            for (DataSnapshot parentSnapshot : dataSnapshot.getChildren()) {
                                parentCount++;
                                User parent = parentSnapshot.getValue(User.class);
                                if (parent != null) {
                                    parent.setId(parentSnapshot.getKey());
                                    
                                    Log.d(TAG, "loadStudentsForBus: Checking parent " + parentCount + ": " + 
                                          parent.getName() + " (ID: " + parent.getId() + ")");
                                    
                                    if (parent.getChildren() != null) {
                                        Log.d(TAG, "loadStudentsForBus: Parent has " + parent.getChildren().size() + " children");
                                        
                                        // Check each child to see if they're assigned to this bus
                                        for (Map.Entry<String, User.Child> entry : parent.getChildren().entrySet()) {
                                            childrenCount++;
                                            String childId = entry.getKey();
                                            User.Child child = entry.getValue();
                                            String childBusId = child != null ? child.getBusId() : null;
                                            
                                            // Log the child's bus ID for comparison
                                            Log.d(TAG, "loadStudentsForBus: Child #" + childrenCount + ": " + 
                                                  (child != null ? child.getName() : "unknown") + 
                                                  ", childId: " + childId +
                                                  ", bus ID: " + childBusId);
                                            
                                            // Debug output for string comparison
                                            if (child != null && childBusId != null && busId != null) {
                                                Log.d(TAG, "loadStudentsForBus: String comparison - " +
                                                      "busId length: " + busId.length() + 
                                                      ", childBusId length: " + childBusId.length() + 
                                                      ", equal by ==: " + (busId == childBusId) + 
                                                      ", equal by equals(): " + busId.equals(childBusId) + 
                                                      ", equal ignoring case: " + busId.equalsIgnoreCase(childBusId));
                                                
                                                // Character by character comparison for debugging
                                                StringBuilder diff = new StringBuilder();
                                                for (int i = 0; i < Math.min(busId.length(), childBusId.length()); i++) {
                                                    if (busId.charAt(i) != childBusId.charAt(i)) {
                                                        diff.append("Pos ").append(i).append(": ")
                                                            .append(busId.charAt(i)).append(" vs ")
                                                            .append(childBusId.charAt(i)).append("; ");
                                                    }
                                                }
                                                if (diff.length() > 0) {
                                                    Log.d(TAG, "loadStudentsForBus: String differences: " + diff.toString());
                                                }
                                            }
                                            
                                            if (child != null && childBusId == null) {
                                                missingBusIdCount++;
                                            }
                                            
                                            // Perform proper string comparison with equals()
                                            if (child != null && childBusId != null && busId != null && busId.equals(childBusId)) {
                                                // Create a student from this child
                                                Student student = new Student();
                                                student.setId(childId);
                                                student.setName(child.getName());
                                                student.setGrade(child.getGrade());
                                                student.setBusId(child.getBusId());
                                                student.setParentId(parent.getId());
                                                student.setParentName(parent.getName());
                                                studentList.add(student);
                                                
                                                Log.d(TAG, "loadStudentsForBus: MATCH FOUND! Added student: " + child.getName() + 
                                                      " with matching bus ID: " + child.getBusId());
                                                foundAny = true;
                                            } else if (child != null && childBusId != null && busId != null) {
                                                mismatchedBusIdCount++;
                                                Log.d(TAG, "loadStudentsForBus: Bus ID mismatch for child: " + child.getName() + 
                                                      " - Child bus ID: " + childBusId + ", Driver bus ID: " + busId);
                                            }
                                        }
                                    } else {
                                        Log.d(TAG, "loadStudentsForBus: Parent has no children map");
                                    }
                                } else {
                                    Log.w(TAG, "loadStudentsForBus: Failed to parse parent data");
                                }
                            }
                            
                            // Log summary statistics
                            Log.d(TAG, "loadStudentsForBus: Summary - Checked " + parentCount + " parents, " + 
                                  childrenCount + " total children, " + 
                                  missingBusIdCount + " children with missing busId, " +
                                  mismatchedBusIdCount + " children with mismatched busId, " +
                                  studentList.size() + " matches found");
                        }
                        
                        if (!foundAny) {
                            // If no students found, directly check bus_locations to verify the bus exists
                            Log.d(TAG, "loadStudentsForBus: No student matches found, checking if bus exists in locations");
                            firebaseManager.getDatabaseReference("bus_locations")
                                .child(busId)
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot busLocationSnapshot) {
                                        if (busLocationSnapshot.exists()) {
                                            Log.d(TAG, "loadStudentsForBus: Bus exists in bus_locations but has no students assigned");
                                            
                                            // Cross-check with the children map in all users
                                            Log.d(TAG, "loadStudentsForBus: Performing deep search of all users for this bus");
                                            checkAllUserChildrenForBus(busId);
                                        } else {
                                            Log.w(TAG, "loadStudentsForBus: Bus not found in bus_locations either");
                                            studentAdapter.notifyDataSetChanged();
                                            if (studentList.isEmpty()) {
                                                showToast("No students assigned to this bus");
                                                Log.d(TAG, "loadStudentsForBus: No students found assigned to bus ID: " + busId);
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                        Log.e(TAG, "loadStudentsForBus: Error checking bus_locations: " + databaseError.getMessage());
                                    }
                                });
                        } else {
                            studentAdapter.notifyDataSetChanged();
                            Log.d(TAG, "loadStudentsForBus: Found " + studentList.size() + " students, updated adapter");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        showToast("Error loading student data: " + databaseError.getMessage());
                        Log.e(TAG, "loadStudentsForBus: Error loading student data: " + databaseError.getMessage());
                    }
                });
    }
    
    // Helper method to check all users for children with this bus ID
    private void checkAllUserChildrenForBus(String busId) {
        Log.d(TAG, "checkAllUserChildrenForBus: Searching all users for children with busId: " + busId);
        firebaseManager.getDatabaseReference(Constants.USERS_PATH)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Log.d(TAG, "checkAllUserChildrenForBus: Checking " + dataSnapshot.getChildrenCount() + " users");
                    
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        String userId = userSnapshot.getKey();
                        User user = userSnapshot.getValue(User.class);
                        
                        if (user != null) {
                            Log.d(TAG, "checkAllUserChildrenForBus: Checking user: " + userId + ", type: " + user.getType());
                            
                            if (user.getChildren() != null) {
                                Log.d(TAG, "checkAllUserChildrenForBus: User has " + user.getChildren().size() + " children");
                                
                                for (Map.Entry<String, User.Child> entry : user.getChildren().entrySet()) {
                                    String childId = entry.getKey();
                                    User.Child child = entry.getValue();
                                    String childBusId = child != null ? child.getBusId() : null;
                                    
                                    Log.d(TAG, "checkAllUserChildrenForBus: Checking child: " + 
                                          (child != null ? child.getName() : "unknown") + 
                                          ", busId: " + childBusId);
                                    
                                    if (child != null && busId.equals(childBusId)) {
                                        Log.d(TAG, "checkAllUserChildrenForBus: MATCH FOUND! Found child " + 
                                              child.getName() + " assigned to bus " + busId);
                                        
                                        Student student = new Student();
                                        student.setId(childId);
                                        student.setName(child.getName());
                                        student.setGrade(child.getGrade());
                                        student.setBusId(child.getBusId());
                                        student.setParentId(userId);
                                        student.setParentName(user.getName());
                                        studentList.add(student);
                                    }
                                }
                            }
                        }
                    }
                    
                    studentAdapter.notifyDataSetChanged();
                    Log.d(TAG, "checkAllUserChildrenForBus: Full search complete, found " + studentList.size() + " students");
                    
                    if (studentList.isEmpty()) {
                        showToast("No students assigned to this bus");
                        Log.d(TAG, "checkAllUserChildrenForBus: No students found assigned to bus ID: " + busId + " after full search");
                    } else {
                        Log.d(TAG, "checkAllUserChildrenForBus: Found " + studentList.size() + " students after full search");
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e(TAG, "checkAllUserChildrenForBus: Error in full search: " + databaseError.getMessage());
                }
            });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_driver, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_logout) {
            logout();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}