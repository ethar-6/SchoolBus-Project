package com.schoolbus.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.schoolbus.app.R;
import com.schoolbus.app.firebase.FirebaseManager;
import com.schoolbus.app.models.User;
import com.schoolbus.app.utils.Constants;
import com.schoolbus.app.utils.PreferenceManager;

public class SplashActivity extends AppCompatActivity {
    private static final long SPLASH_DELAY = 2000; // 2 seconds
    private static final String TAG = "SplashActivity";

    private FirebaseManager firebaseManager;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Initialize managers
        firebaseManager = FirebaseManager.getInstance();
        preferenceManager = PreferenceManager.getInstance(this);

        // Delay and navigate
        new Handler(Looper.getMainLooper()).postDelayed(this::checkLoginStatus, SPLASH_DELAY);
    }

    private void checkLoginStatus() {
        if (firebaseManager.isUserLoggedIn() && preferenceManager.getUserId() != null) {
            // User is logged in, get user type from preferences
            User user = preferenceManager.getUser();

            if (user != null && user.getType() != null) {
                String userType = user.getType();
                Log.d(TAG, "User type detected: " + userType);

                // Navigate based on user type
                if (userType.equals("admin")) {
                    Log.d(TAG, "Navigating to AdminDashboardActivity");
                    startActivity(new Intent(this, AdminDashboardActivity.class));
                } else if (userType.equals("driver")) {
                    Log.d(TAG, "Navigating to DriverDashboardActivity");
                    startActivity(new Intent(this, DriverDashboardActivity.class));
                } else {
                    // Default for parent or unspecified type
                    Log.d(TAG, "Navigating to MainActivity (parent dashboard)");
                    startActivity(new Intent(this, MainActivity.class));
                }
            } else {
                // User data is missing or incomplete, navigate to MainActivity as fallback
                Log.w(TAG, "User data missing or incomplete, defaulting to MainActivity");
                startActivity(new Intent(this, MainActivity.class));
            }
        } else {
            // User is not logged in, navigate to login screen
            startActivity(new Intent(this, LoginActivity.class));
        }

        // Finish splash activity
        finish();
    }
}