package com.schoolbus.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.schoolbus.app.R;
import com.schoolbus.app.fragments.BusesFragment;
import com.schoolbus.app.fragments.HomeFragment;
import com.schoolbus.app.fragments.NotificationsFragment;
import com.schoolbus.app.fragments.ProfileFragment;
import com.schoolbus.app.fragments.TrackingFragment;

public class MainActivity extends BaseActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
    private Toolbar toolbar;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        initViews();

        // Set up toolbar
        if (toolbar != null) {
            setSupportActionBar(toolbar);
        }

        // Set up bottom navigation
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

        // Load default fragment
        if (savedInstanceState == null) {
            loadFragment(new HomeFragment());
            setTitle(R.string.home);
        }
    }

    private void initViews() {
        // Toolbar might not be in the layout
        try {
            toolbar = findViewById(R.id.toolbar);
        } catch (Exception e) {
            // Toolbar not found, continue without it
        }

        bottomNavigationView = findViewById(R.id.bottomNavigationView);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        int titleResId = 0;

        int itemId = item.getItemId();
        if (itemId == R.id.homeFragment) {
            fragment = new HomeFragment();
            titleResId = R.string.home;
        } else if (itemId == R.id.trackingFragment) {
            fragment = new TrackingFragment();
            titleResId = R.string.tracking;
        } else if (itemId == R.id.busesFragment) {
            fragment = new BusesFragment();
            titleResId = R.string.buses;
        } else if (itemId == R.id.notificationsFragment) {
            fragment = new NotificationsFragment();
            titleResId = R.string.notifications;
        } else if (itemId == R.id.profileFragment) {
            fragment = new ProfileFragment();
            titleResId = R.string.profile;
        }

        if (fragment != null) {
            loadFragment(fragment);
            setTitle(titleResId);
            return true;
        }

        return false;
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.nav_host_fragment, fragment)
                .commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        // Only show the driver dashboard option for drivers
        boolean isDriver = preferenceManager.getUser() != null &&
                "driver".equals(preferenceManager.getUser().getType());
        menu.findItem(R.id.action_driver_dashboard).setVisible(isDriver);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_driver_dashboard) {
            navigateToActivity(DriverDashboardActivity.class);
            return true;
        } else if (id == R.id.action_logout) {
            logout();
            return true;
        } else if (id == R.id.action_chat) {
            navigateToActivity(ChatListActivity.class);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}