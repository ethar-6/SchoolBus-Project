package com.schoolbus.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.adapters.RouteAdapter;
import com.schoolbus.app.models.Route;

import java.util.ArrayList;
import java.util.List;

public class AllRoutesActivity extends AppCompatActivity implements RouteAdapter.OnRouteClickListener {
    private static final String TAG = "AllRoutesActivity";

    private RecyclerView recyclerView;
    private TextView emptyView;
    private ProgressBar progressBar;
    private FloatingActionButton fabAddRoute;
    private SwipeRefreshLayout swipeRefreshLayout;
    private TabLayout tabLayout;
    private RouteAdapter adapter;
    private List<Route> routeList;
    private List<Route> filteredRouteList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_routes);

        // Initialize views
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        recyclerView = findViewById(R.id.recyclerViewRoutes);
        emptyView = findViewById(R.id.emptyView);
        progressBar = findViewById(R.id.progressBar);
        fabAddRoute = findViewById(R.id.fabAddRoute);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        tabLayout = findViewById(R.id.tabLayout);

        // Set up RecyclerView
        recyclerView.setHasFixedSize(true);

        routeList = new ArrayList<>();
        filteredRouteList = new ArrayList<>();
        adapter = new RouteAdapter(this, filteredRouteList, this);
        recyclerView.setAdapter(adapter);

        // Set up SwipeRefreshLayout
        swipeRefreshLayout.setColorSchemeResources(
                R.color.primary,
                R.color.accent,
                R.color.primary_dark);
        swipeRefreshLayout.setOnRefreshListener(this::fetchAllRoutes);

        // Set up TabLayout
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                filterRoutes(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                // Not needed
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Not needed
            }
        });

        // Set up FAB click listener
        fabAddRoute.setOnClickListener(v -> {
            Intent intent = new Intent(AllRoutesActivity.this, AddRouteActivity.class);
            startActivity(intent);
        });

        // Fetch all routes from Firebase
        fetchAllRoutes();
    }

    private void filterRoutes(int tabPosition) {
        filteredRouteList.clear();

        switch (tabPosition) {
            case 0: // All Routes
                filteredRouteList.addAll(routeList);
                break;
            case 1: // Active
                for (Route route : routeList) {
                    if (route.isActive()) {
                        filteredRouteList.add(route);
                    }
                }
                break;
            case 2: // Inactive
                for (Route route : routeList) {
                    if (!route.isActive()) {
                        filteredRouteList.add(route);
                    }
                }
                break;
        }

        adapter.notifyDataSetChanged();
        updateEmptyView();
    }

    private boolean isRouteActive(Route route) {
        // This is a placeholder logic - customize based on your requirements
        // For example, a route could be active if it has:
        // - Assigned bus
        // - Has days defined
        // - Has stops
        return route.getBusId() != null &&
                route.getDays() != null &&
                !route.getDays().isEmpty() &&
                route.getStopsMap() != null &&
                !route.getStopsMap().isEmpty();
    }

    private void fetchAllRoutes() {
        progressBar.setVisibility(View.VISIBLE);
        swipeRefreshLayout.setRefreshing(true);

        DatabaseReference routesRef = FirebaseDatabase.getInstance().getReference("routes");
        routesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                routeList.clear();
                Log.d(TAG, "Retrieved routes data: " + dataSnapshot.toString());

                for (DataSnapshot routeSnapshot : dataSnapshot.getChildren()) {
                    try {
                        String routeId = routeSnapshot.getKey();
                        Route route = routeSnapshot.getValue(Route.class);

                        if (route != null) {
                            route.setId(routeId);

                            // Also fetch any stops if needed
                            if (routeSnapshot.hasChild("stops")) {
                                DataSnapshot stopsSnapshot = routeSnapshot.child("stops");
                                for (DataSnapshot stopEntry : stopsSnapshot.getChildren()) {
                                    String stopId = stopEntry.getKey();
                                    Boolean isActive = stopEntry.getValue(Boolean.class);

                                    if (Boolean.TRUE.equals(isActive)) {
                                        // We'll fetch actual stop data later if needed
                                        // For now, just keep track that this stop is part of the route
                                        route.getStopsMap().put(stopId, true);
                                    }
                                }
                            }

                            routeList.add(route);
                            Log.d(TAG, "Added route: " + route.getName());
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error parsing route data: " + e.getMessage());
                    }
                }

                // Apply current filter
                int selectedTabPosition = tabLayout.getSelectedTabPosition();
                filterRoutes(selectedTabPosition);

                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Error fetching routes: " + databaseError.getMessage());
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);
                updateEmptyView();
                emptyView.setText("Error loading routes. Please try again.");
            }
        });
    }

    private void updateEmptyView() {
        if (filteredRouteList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onRouteClick(Route route) {
        Intent intent = new Intent(this, EditRouteActivity.class);
        intent.putExtra("route_id", route.getId());
        startActivity(intent);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}