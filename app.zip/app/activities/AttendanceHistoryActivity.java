package com.schoolbus.app.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.adapters.AttendanceAdapter;
import com.schoolbus.app.models.Attendance;
import com.schoolbus.app.utils.Constants;
import com.schoolbus.app.firebase.FirebaseManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class AttendanceHistoryActivity extends AppCompatActivity {

    public static final String EXTRA_STUDENT_ID = "extra_student_id";
    public static final String EXTRA_STUDENT_NAME = "extra_student_name";

    private Toolbar toolbar;
    private TextView studentNameTextView;
    private RecyclerView attendanceRecyclerView;
    private ProgressBar progressBar;
    private TextView noRecordsTextView;
    private SwipeRefreshLayout swipeRefreshLayout;

    private FirebaseManager firebaseManager;
    private AttendanceAdapter attendanceAdapter;
    private List<Attendance> attendanceList;
    private String studentId;
    private String studentName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_history);

        firebaseManager = FirebaseManager.getInstance();

        // Get extras
        studentId = getIntent().getStringExtra(EXTRA_STUDENT_ID);
        studentName = getIntent().getStringExtra(EXTRA_STUDENT_NAME);

        if (studentId == null) {
            Toast.makeText(this, "Student ID not provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize views
        initViews();

        // Set up toolbar
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.attendance_history);
        }

        // Set student name
        studentNameTextView.setText(studentName);

        // Set up attendance list
        setupAttendanceList();

        // Set up SwipeRefreshLayout
        swipeRefreshLayout.setOnRefreshListener(this::loadAttendanceData);
        swipeRefreshLayout.setColorSchemeResources(
                R.color.primary,
                R.color.primary_dark,
                R.color.accent);

        // Load attendance data
        loadAttendanceData();
    }

    private void initViews() {
        toolbar = findViewById(R.id.toolbar);
        studentNameTextView = findViewById(R.id.studentNameTextView);
        attendanceRecyclerView = findViewById(R.id.attendanceRecyclerView);
        progressBar = findViewById(R.id.progressBar);
        noRecordsTextView = findViewById(R.id.noRecordsTextView);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
    }

    private void setupAttendanceList() {
        attendanceList = new ArrayList<>();
        attendanceAdapter = new AttendanceAdapter(attendanceList);
        attendanceRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        attendanceRecyclerView.setAdapter(attendanceAdapter);
    }

    private void loadAttendanceData() {
        if (!swipeRefreshLayout.isRefreshing()) {
            progressBar.setVisibility(View.VISIBLE);
        }
        noRecordsTextView.setVisibility(View.GONE);

        // Query attendance records for this student
        firebaseManager.getDatabaseReference(Constants.ATTENDANCE_PATH)
                .orderByChild("studentId")
                .equalTo(studentId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        attendanceList.clear();

                        if (dataSnapshot.exists()) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                Attendance attendance = snapshot.getValue(Attendance.class);
                                if (attendance != null) {
                                    attendance.setId(snapshot.getKey());
                                    attendanceList.add(attendance);
                                }
                            }

                            // Sort by timestamp (most recent first)
                            Collections.sort(attendanceList, new Comparator<Attendance>() {
                                @Override
                                public int compare(Attendance a1, Attendance a2) {
                                    return Long.compare(a2.getTimestamp(), a1.getTimestamp());
                                }
                            });

                            attendanceAdapter.notifyDataSetChanged();
                        }

                        progressBar.setVisibility(View.GONE);
                        swipeRefreshLayout.setRefreshing(false);

                        if (attendanceList.isEmpty()) {
                            noRecordsTextView.setVisibility(View.VISIBLE);
                            attendanceRecyclerView.setVisibility(View.GONE);
                        } else {
                            noRecordsTextView.setVisibility(View.GONE);
                            attendanceRecyclerView.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        progressBar.setVisibility(View.GONE);
                        swipeRefreshLayout.setRefreshing(false);
                        noRecordsTextView.setVisibility(View.VISIBLE);
                        attendanceRecyclerView.setVisibility(View.GONE);
                        Toast.makeText(AttendanceHistoryActivity.this,
                                "Error loading attendance: " + databaseError.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}