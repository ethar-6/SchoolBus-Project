package com.schoolbus.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.schoolbus.app.R;
import com.google.firebase.auth.FirebaseAuth;
import com.schoolbus.app.utils.PreferenceManager;

public class AdminDashboardActivity extends AppCompatActivity {
    private CardView cardManageDrivers;
    private CardView cardManageStudents;
    private CardView cardTrackBuses;
    private CardView cardReports;
    private CardView cardManageRoutes;
    private CardView cardLogout;
    private CardView cardManageParents;
    private CardView cardChats;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        // Initialize views
        initializeViews();
        // Set click listeners
        setClickListeners();
    }

    private void initializeViews() {
        cardManageDrivers = findViewById(R.id.cardManageDrivers);
        cardManageStudents = findViewById(R.id.cardManageStudents);
        cardTrackBuses = findViewById(R.id.cardTrackBuses);
        cardReports = findViewById(R.id.cardReports);
        cardManageRoutes = findViewById(R.id.cardManageRoutes);
        cardLogout = findViewById(R.id.cardLogout);
        cardManageParents = findViewById(R.id.cardManageParents);
        cardChats = findViewById(R.id.cardChats);
    }

    private void setClickListeners() {
        cardManageDrivers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AllDriversActivity
                Intent intent = new Intent(AdminDashboardActivity.this, AllDriversActivity.class);
                startActivity(intent);
            }
        });

        cardManageStudents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AllStudentsActivity
                Intent intent = new Intent(AdminDashboardActivity.this, AllStudentsActivity.class);
                startActivity(intent);
            }
        });

        cardTrackBuses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AllBusesActivity
                Intent intent = new Intent(AdminDashboardActivity.this, AllBusesActivity.class);
                startActivity(intent);
            }
        });

        cardReports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: Implement reports
                Toast.makeText(AdminDashboardActivity.this, "Reports Coming Soon", Toast.LENGTH_SHORT).show();
            }
        });

        cardManageRoutes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AllRoutesActivity
                Intent intent = new Intent(AdminDashboardActivity.this, AllRoutesActivity.class);
                startActivity(intent);
            }
        });

        cardManageParents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AllParentsActivity
                Intent intent = new Intent(AdminDashboardActivity.this, AllParentsActivity.class);
                startActivity(intent);
            }
        });

        cardChats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to ChatListActivity
                Intent intent = new Intent(AdminDashboardActivity.this, ChatListActivity.class);
                startActivity(intent);
            }
        });

        cardLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement proper logout
                // Clear Firebase Auth state
                FirebaseAuth.getInstance().signOut();

                // Clear preferences and navigate to login
                PreferenceManager preferenceManager = new PreferenceManager(AdminDashboardActivity.this);
                preferenceManager.clearAll();

                Intent intent = new Intent(AdminDashboardActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });
    }
}