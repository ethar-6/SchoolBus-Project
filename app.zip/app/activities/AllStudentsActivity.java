package com.schoolbus.app.activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.adapters.StudentAdapter;
import com.schoolbus.app.models.Student;

import java.util.ArrayList;
import java.util.List;

public class AllStudentsActivity extends AppCompatActivity implements StudentAdapter.OnStudentDeleteListener {
    private static final String TAG = "AllStudentsActivity";

    private RecyclerView recyclerView;
    private TextView emptyView;
    private ProgressBar progressBar;
    private StudentAdapter adapter;
    private List<Student> studentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_students);

        // Initialize views
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        recyclerView = findViewById(R.id.recyclerViewStudents);
        emptyView = findViewById(R.id.emptyView);
        progressBar = findViewById(R.id.progressBar);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        studentList = new ArrayList<>();
        adapter = new StudentAdapter(this, studentList);
        recyclerView.setAdapter(adapter);

        // Fetch all students from Firebase
        fetchAllStudents();
    }

    private void fetchAllStudents() {
        progressBar.setVisibility(View.VISIBLE);

        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users");
        usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                studentList.clear();
                Log.d(TAG, "Retrieved users data: " + dataSnapshot.toString());

                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    String userId = userSnapshot.getKey();
                    String userName = userSnapshot.child("name").getValue(String.class);

                    Log.d(TAG, "Checking user: " + userId);

                    // Check if user has children node
                    if (userSnapshot.hasChild("children")) {
                        Log.d(TAG, "User has children: " + userId);

                        // Get children of this user
                        DataSnapshot childrenSnapshot = userSnapshot.child("children");
                        for (DataSnapshot childSnapshot : childrenSnapshot.getChildren()) {
                            Log.d(TAG, "Child data: " + childSnapshot.toString());

                            try {
                                // Try to get child as Student object
                                Student student = new Student();
                                student.setId(childSnapshot.getKey());
                                student.setName(childSnapshot.child("name").getValue(String.class));
                                student.setGrade(childSnapshot.child("grade").getValue(String.class));
                                student.setBusId(childSnapshot.child("busId").getValue(String.class));
                                student.setParentId(userId);
                                student.setParentName(userName != null ? userName : userId);

                                studentList.add(student);
                                Log.d(TAG, "Added student: " + student.getName());
                            } catch (Exception e) {
                                Log.e(TAG, "Error parsing student data: " + e.getMessage());
                            }
                        }
                    }
                }

                adapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);

                // Show empty view if no students found
                if (studentList.isEmpty()) {
                    Log.d(TAG, "No students found");
                    recyclerView.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    Log.d(TAG, "Found " + studentList.size() + " students");
                    recyclerView.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Error fetching students: " + databaseError.getMessage());
                progressBar.setVisibility(View.GONE);
                recyclerView.setVisibility(View.GONE);
                emptyView.setVisibility(View.VISIBLE);
                emptyView.setText("Error loading students. Please try again.");
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        // We'll reload the data in onActivityResult instead of here to avoid
        // unnecessary reloads
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // If the student was edited successfully, reload the students list
        if (requestCode == 100 && resultCode == RESULT_OK) { // 100 is the EDIT_STUDENT_REQUEST_CODE from the adapter
            fetchAllStudents();
        }
    }

    @Override
    public void onStudentDeleted(int remainingCount) {
        // Update UI based on the remaining count of students
        if (remainingCount == 0) {
            recyclerView.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
        }
    }
}