package com.schoolbus.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.adapters.ParentAdapter;
import com.schoolbus.app.models.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AllParentsActivity extends AppCompatActivity implements ParentAdapter.OnParentClickListener {
    private static final String TAG = "AllParentsActivity";

    private RecyclerView recyclerView;
    private TextView emptyView;
    private ProgressBar progressBar;
    private ParentAdapter adapter;
    private List<User> parentsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_parents);

        // Initialize views
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        recyclerView = findViewById(R.id.recyclerViewParents);
        emptyView = findViewById(R.id.emptyView);
        progressBar = findViewById(R.id.progressBar);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        parentsList = new ArrayList<>();
        adapter = new ParentAdapter(this, parentsList, this);
        recyclerView.setAdapter(adapter);

        // Fetch all parents from Firebase
        fetchAllParents();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data when returning to this activity
        fetchAllParents();
    }

    private void fetchAllParents() {
        progressBar.setVisibility(View.VISIBLE);

        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users");
        Query parentsQuery = usersRef.orderByChild("type").equalTo("parent");

        parentsQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                parentsList.clear();
                Log.d(TAG, "Retrieved parents data: " + dataSnapshot.toString());

                for (DataSnapshot parentSnapshot : dataSnapshot.getChildren()) {
                    User parent = parentSnapshot.getValue(User.class);
                    if (parent != null) {
                        parent.setId(parentSnapshot.getKey());
                        parentsList.add(parent);
                        Log.d(TAG, "Added parent: " + parent.getName());
                    }
                }

                adapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);

                // Show empty view if no parents found
                if (parentsList.isEmpty()) {
                    Log.d(TAG, "No parents found");
                    recyclerView.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    Log.d(TAG, "Found " + parentsList.size() + " parents");
                    recyclerView.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Error fetching parents: " + databaseError.getMessage());
                progressBar.setVisibility(View.GONE);
                recyclerView.setVisibility(View.GONE);
                emptyView.setVisibility(View.VISIBLE);
                emptyView.setText("Error loading parents. Please try again.");
            }
        });
    }

    @Override
    public void onParentClick(User parent) {
        // Navigate to parent details activity
        Toast.makeText(this, "Parent details coming soon", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onEditClick(User parent) {
        // Navigate to edit parent activity
        Toast.makeText(this, "Edit parent feature coming soon", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onViewChildrenClick(User parent, int position) {
        // Get children for this parent and display them
        Map<String, User.Child> children = parent.getChildren();
        if (children != null && !children.isEmpty()) {
            adapter.displayChildrenForParent(position, children);
        }
    }

    @Override
    public void onDeleteClick(User parent, int position) {
        // Show a confirmation dialog before deleting
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_parent_title)
                .setMessage(R.string.delete_parent_confirmation)
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    deleteParent(parent);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void deleteParent(User parent) {
        progressBar.setVisibility(View.VISIBLE);

        // Get reference to the parent in Firebase
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(parent.getId());

        // Remove the parent
        userRef.removeValue().addOnCompleteListener(task -> {
            progressBar.setVisibility(View.GONE);

            if (task.isSuccessful()) {
                Toast.makeText(this, R.string.parent_deleted_success, Toast.LENGTH_SHORT).show();
                // Refresh the list
                fetchAllParents();
            } else {
                String errorMsg = task.getException() != null ? task.getException().getMessage() : "Unknown error";
                Toast.makeText(this,
                        getString(R.string.parent_delete_error, errorMsg),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}