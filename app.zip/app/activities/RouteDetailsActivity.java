package com.schoolbus.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.schoolbus.app.R;
import com.schoolbus.app.adapters.RouteStopAdapter;
import com.schoolbus.app.models.Route;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RouteDetailsActivity extends AppCompatActivity {
    private static final String TAG = "RouteDetailsActivity";

    // UI components
    private TextView toolbarTitle;
    private TextView routeNameTextView, routeIdTextView, busInfoTextView;
    private TextView descriptionTextView, scheduleTextView, daysTextView;
    private TextView statusTextView, stopsCountTextView, noStopsTextView;
    private Button editRouteButton, viewFullMapButton, manageStopsButton, deleteRouteButton;
    private RecyclerView stopsRecyclerView;
    private ProgressBar progressBar;

    // Data
    private String routeId;
    private Route currentRoute;
    private RouteStopAdapter stopAdapter;
    private List<Route.Stop> stopsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_route_details);

        // Get route ID from intent
        routeId = getIntent().getStringExtra("route_id");
        if (routeId == null) {
            Toast.makeText(this, "Error: Route ID not provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize views
        initializeViews();

        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // Set up RecyclerView
        stopsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        stopAdapter = new RouteStopAdapter(stopsList);
        stopsRecyclerView.setAdapter(stopAdapter);

        // Fetch route data
        fetchRouteData();

        // Set click listeners
        setClickListeners();
    }

    private void initializeViews() {
        // Toolbar
        toolbarTitle = findViewById(R.id.toolbarTitle);
        toolbarTitle.setText("Route Details");

        // Route info views
        routeNameTextView = findViewById(R.id.routeNameTextView);
        routeIdTextView = findViewById(R.id.routeIdTextView);
        busInfoTextView = findViewById(R.id.busInfoTextView);
        descriptionTextView = findViewById(R.id.descriptionTextView);
        scheduleTextView = findViewById(R.id.scheduleTextView);
        daysTextView = findViewById(R.id.daysTextView);
        statusTextView = findViewById(R.id.statusTextView);

        // Stops section
        stopsCountTextView = findViewById(R.id.stopsCountTextView);
        noStopsTextView = findViewById(R.id.noStopsTextView);
        stopsRecyclerView = findViewById(R.id.stopsRecyclerView);

        // Buttons
        editRouteButton = findViewById(R.id.editRouteButton);
        viewFullMapButton = findViewById(R.id.viewFullMapButton);
        manageStopsButton = findViewById(R.id.manageStopsButton);
        deleteRouteButton = findViewById(R.id.deleteRouteButton);

        // Progress indicator
        progressBar = findViewById(R.id.progressBar);
    }

    private void setClickListeners() {
        // Edit route button
        editRouteButton.setOnClickListener(v -> {
            Intent intent = new Intent(RouteDetailsActivity.this, EditRouteActivity.class);
            intent.putExtra("route_id", routeId);
            startActivity(intent);
        });

        // View full map button
        viewFullMapButton.setOnClickListener(v -> {
            Toast.makeText(this, "Full map view coming soon", Toast.LENGTH_SHORT).show();
        });

        // Manage stops button
        manageStopsButton.setOnClickListener(v -> {
            Toast.makeText(this, "Stops management coming soon", Toast.LENGTH_SHORT).show();
        });

        // Delete route button
        deleteRouteButton.setOnClickListener(v -> {
            confirmDeleteRoute();
        });
    }

    private void fetchRouteData() {
        progressBar.setVisibility(View.VISIBLE);

        DatabaseReference routeRef = FirebaseDatabase.getInstance().getReference("routes").child(routeId);
        routeRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressBar.setVisibility(View.GONE);

                if (snapshot.exists()) {
                    currentRoute = snapshot.getValue(Route.class);

                    if (currentRoute != null) {
                        currentRoute.setId(routeId);
                        displayRouteDetails();
                        fetchStopsData();
                    } else {
                        showError("Error loading route data");
                    }
                } else {
                    showError("Route not found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
                showError("Database error: " + error.getMessage());
            }
        });
    }

    private void displayRouteDetails() {
        // Route name and ID
        routeNameTextView.setText(currentRoute.getName());
        routeIdTextView.setText("Route ID: " + routeId);

        // Bus info
        if (currentRoute.getBusId() != null && !currentRoute.getBusId().isEmpty()) {
            busInfoTextView.setText("Bus ID: " + currentRoute.getBusId());
            busInfoTextView.setVisibility(View.VISIBLE);
        } else {
            busInfoTextView.setVisibility(View.GONE);
        }

        // Description
        if (currentRoute.getDescription() != null && !currentRoute.getDescription().isEmpty()) {
            descriptionTextView.setText(currentRoute.getDescription());
            descriptionTextView.setVisibility(View.VISIBLE);
        } else {
            descriptionTextView.setVisibility(View.GONE);
        }

        // Schedule
        if (currentRoute.getStartTime() != null && currentRoute.getEndTime() != null) {
            scheduleTextView.setText("Schedule: " + currentRoute.getStartTime() + " - " + currentRoute.getEndTime());
            scheduleTextView.setVisibility(View.VISIBLE);
        } else {
            scheduleTextView.setVisibility(View.GONE);
        }

        // Days
        if (currentRoute.getDays() != null && !currentRoute.getDays().isEmpty()) {
            StringBuilder daysText = new StringBuilder("Days: ");
            for (int i = 0; i < currentRoute.getDays().size(); i++) {
                if (i > 0)
                    daysText.append(", ");
                daysText.append(currentRoute.getDays().get(i));
            }
            daysTextView.setText(daysText.toString());
            daysTextView.setVisibility(View.VISIBLE);
        } else {
            daysTextView.setVisibility(View.GONE);
        }

        // Status
        boolean isActive = currentRoute.isActive();
        statusTextView.setText(isActive ? "Active" : "Inactive");
        statusTextView.setBackgroundResource(isActive ? R.drawable.bg_status_active : R.drawable.bg_status_inactive);
    }

    private void fetchStopsData() {
        // For demo, just check if the route has stops in its map
        if (currentRoute.getStopsMap() != null && !currentRoute.getStopsMap().isEmpty()) {
            // In a real implementation, we would fetch actual stop details from Firebase
            // For now, we'll create dummy stops based on the stop IDs
            stopsList.clear();
            int stopOrder = 1;

            for (String stopId : currentRoute.getStopsMap().keySet()) {
                if (Boolean.TRUE.equals(currentRoute.getStopsMap().get(stopId))) {
                    Route.Stop stop = new Route.Stop();
                    stop.setId(stopId);
                    stop.setName("Stop " + stopOrder);
                    stop.setOrder(stopOrder);
                    stop.setAddress("123 Demo Street, City");
                    stop.setScheduledTime(calculateTime(currentRoute.getStartTime(), stopOrder * 5));
                    stop.setArrivalTime(calculateTime(currentRoute.getStartTime(), stopOrder * 5));
                    stop.setDepartureTime(calculateTime(currentRoute.getStartTime(), stopOrder * 5 + 2));
                    stop.setLatitude(37.7749 + (stopOrder * 0.01));
                    stop.setLongitude(-122.4194 + (stopOrder * 0.01));
                    stop.setRouteId(routeId);

                    stopsList.add(stop);
                    stopOrder++;
                }
            }

            updateStopsUI();
        } else {
            // No stops found
            stopsCountTextView.setText("(0 total)");
            stopsRecyclerView.setVisibility(View.GONE);
            noStopsTextView.setVisibility(View.VISIBLE);
        }
    }

    private void updateStopsUI() {
        if (stopsList.isEmpty()) {
            stopsCountTextView.setText("(0 total)");
            stopsRecyclerView.setVisibility(View.GONE);
            noStopsTextView.setVisibility(View.VISIBLE);
        } else {
            stopsCountTextView.setText("(" + stopsList.size() + " total)");
            stopAdapter.notifyDataSetChanged();
            stopsRecyclerView.setVisibility(View.VISIBLE);
            noStopsTextView.setVisibility(View.GONE);
        }
    }

    private String calculateTime(String startTime, int minutesToAdd) {
        // This is a simplified version just for demonstration
        // In a real app, you would parse the startTime and add minutes properly
        return startTime;
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void confirmDeleteRoute() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Delete Route");
        builder.setMessage("Are you sure you want to delete this route? This action cannot be undone.");
        builder.setPositiveButton("Delete", (dialog, which) -> {
            deleteRoute();
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> {
            dialog.dismiss();
        });
        builder.show();
    }

    private void deleteRoute() {
        progressBar.setVisibility(View.VISIBLE);

        // First, find any buses assigned to this route
        updateBusesAssignedToRoute();
    }

    private void updateBusesAssignedToRoute() {
        DatabaseReference busesRef = FirebaseDatabase.getInstance().getReference("buses");

        busesRef.orderByChild("routeId").equalTo(routeId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            // Update all buses that have this route assigned
                            for (DataSnapshot busSnapshot : snapshot.getChildren()) {
                                String busId = busSnapshot.getKey();
                                if (busId != null) {
                                    // Update the bus to remove the route association
                                    // but keep the bus itself
                                    DatabaseReference busRef = busesRef.child(busId);
                                    Map<String, Object> busUpdates = new HashMap<>();
                                    busUpdates.put("routeId", "");
                                    busUpdates.put("routeName", "");

                                    busRef.updateChildren(busUpdates)
                                            .addOnSuccessListener(aVoid -> {
                                                Log.d(TAG, "Cleared route assignment from bus: " + busId);
                                            })
                                            .addOnFailureListener(e -> {
                                                Log.e(TAG, "Failed to clear route from bus: " + busId, e);
                                            });
                                }
                            }
                        }

                        // Now proceed with deleting the route
                        performRouteDelete();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        progressBar.setVisibility(View.GONE);
                        showError("Error updating buses: " + error.getMessage());
                    }
                });
    }

    private void performRouteDelete() {
        DatabaseReference routeRef = FirebaseDatabase.getInstance().getReference("routes").child(routeId);

        routeRef.removeValue().addOnCompleteListener(task -> {
            progressBar.setVisibility(View.GONE);

            if (task.isSuccessful()) {
                Toast.makeText(this, "Route deleted successfully", Toast.LENGTH_SHORT).show();
                finish(); // Close the activity and go back
            } else {
                showError("Failed to delete route: " + task.getException().getMessage());
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}